import json
import logging
import threading
from threading import Thread
from typing import Optional, Type

# noinspection PyUnresolvedReferences
from agent.modules import *

from devocollectorsdk.commons.collector_exceptions import SdkServiceInitializationError, SdkServiceRunningError
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.non_active_reasons import NonActiveReasons
from devocollectorsdk.commons.object_statuses import ObjectStatuses
from devocollectorsdk.persistence.persistence_factory_manager import PersistenceFactoryManager
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.ratelimiter.collector_rate_limiter_list import CollectorRateLimiterList

log = logging.getLogger(__name__)


NO_SUBMODULES_MARK: str = "-+#no_submodule#+-"


class ServiceThread(Thread):
    """Service that create all final input services"""
    def __init__(self,
                 parent_thread,
                 definition_globals: dict,
                 production_mode: bool,
                 execute_only_setup_and_exit: bool,
                 input_id: str,
                 input_name: str,
                 input_config: dict,
                 input_definition: dict,
                 input_wait_object: threading.Event,
                 service_name: str,
                 service_type: str,
                 service_config: dict,
                 service_definition: dict,
                 service_globals: dict,
                 persistence_factory_manager: PersistenceFactoryManager,
                 standard_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 internal_queue: CollectorMultiprocessingQueue,
                 rate_limiters_from_input: CollectorRateLimiterList) -> None:
        """

        :param parent_thread:
        :param definition_globals:
        :param production_mode:
        :param execute_only_setup_and_exit:
        :param input_id:
        :param input_name:
        :param input_config:
        :param input_definition:
        :param input_wait_object:
        :param service_name:
        :param service_type:
        :param service_config:
        :param service_definition:
        :param service_globals:
        :param persistence_factory_manager:
        :param standard_queue:
        :param lookup_queue:
        :param rate_limiters_from_input:
        """
        super().__init__()

        self.__object_status = ObjectStatuses.INITIALIZING

        self.name: str = \
            self.__class__.__name__ + \
            f"({input_name},{input_id},{service_name},{service_type})"

        self.parent_thread = parent_thread

        # Properties
        self.__definition_globals: dict = definition_globals
        self.__production_mode: bool = production_mode
        self.__execute_only_setup_and_exit: bool = execute_only_setup_and_exit
        self.input_id: str = input_id
        self.input_name: str = input_name
        self.input_config: dict = input_config
        self.input_definition: dict = input_definition
        self.input_wait_object: threading.Event = input_wait_object

        self.service_name: str = service_name
        self.service_type: str = service_type
        self.service_config: dict = service_config
        self.service_definition: dict = service_definition
        self.service_globals: dict = service_globals

        self.persistence_factory_manager: PersistenceFactoryManager = persistence_factory_manager

        self.standard_queue: CollectorMultiprocessingQueue = standard_queue
        self.lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.internal_queue: CollectorMultiprocessingQueue = internal_queue

        self.__rate_limiters: CollectorRateLimiterList = \
            CollectorRateLimiterList(rate_limiters_from_input.rate_limiters)

        self.service_thread_globals = input_definition.get("service_thread_globals")

        self.service_thread_execution_periods_in_seconds: int = 600

        if self.service_thread_globals:
            self.requests_limits = self.service_thread_globals.get("requests_limits")

            if self.requests_limits:
                self.__rate_limiters.add_rate_limiters_from_list(self.requests_limits)

            self.service_thread_execution_periods_in_seconds = \
                self.service_thread_globals.get("service_thread_execution_periods_in_seconds")

        self.module_threads: dict = {}

        # Variables related to run/pause/stop statuses
        self.__command_execution_lock: threading.Lock = threading.Lock()

        self.__thread_wait_object: threading.Event = threading.Event()
        self.__non_active_reason: Optional[str] = None

        self.__stop_thread: bool = False
        self.__wait_object_for_stop_method: threading.Event = threading.Event()
        self.__thread_is_stopped: bool = False

        self.__pause_thread: bool = False
        self.__wait_object_for_pause_run: threading.Event = threading.Event()
        self.__wait_object_for_pause_method: threading.Event = threading.Event()
        self.__thread_is_paused: bool = False

        self.__running_flag: bool = self.__create_module_threads()

        self.setup_and_exit_execution_result_global: Optional[bool] = None
        self.setup_and_exit_execution_result_details: Optional[dict] = None

        self.__object_status = ObjectStatuses.INITIALIZED

    def __create_module_threads(self) -> bool:
        """Create the module threads

        :return:
        """
        submodules_instantiated = 0
        total_submodules_amount = 0

        # Validate all settings
        if self.service_definition is None:
            raise SdkServiceInitializationError(
                10,
                f'Service definition does not exists'
            )

        modules = self.service_definition.get("modules")
        if modules is None:
            raise SdkServiceInitializationError(
                20,
                f'The definition for "{self.service_name}" service should have at least on module definition'
            )

        if not isinstance(modules, dict):
            raise SdkServiceInitializationError(
                30,
                f"The definition for <{self.service_name}> service should be a dict of modules"
            )

        # Read the modules and create them
        for module_name, module_definition in modules.items():

            # This new property is added for being compatible with future SDK versions
            module_definition["class_name"] = f'agent.modules.{module_name}'

            submodules_instantiated += self.__load_modules(module_definition)

        # Check if all modules have been created
        if total_submodules_amount > submodules_instantiated:

            self.log_debug(f'{self.name} -> Some modules were not created')

        if submodules_instantiated > 0:
            return True
        return False

    def __load_modules(self, module_definition: dict) -> int:
        """Read the module definitions and create the final input services

        :param module_definition:
        :return:
        """

        module_class_full_name = module_definition["class_name"]

        submodules_instantiated = 0

        module_enabled = self.__check_if_module_is_enabled(module_definition)

        if module_enabled is False:

            self.log_debug(f'Module "{module_class_full_name}" is not enabled')
            return submodules_instantiated

        submodules = self.__generate_submodules(module_definition)

        module_class, module_class_name = CollectorUtils.load_class_object(module_class_full_name)

        for submodule_name, submodule_value in submodules.items():
            if submodule_name == NO_SUBMODULES_MARK:
                submodule_name = None
            try:

                # TODO Fix module_config initialization
                module_config: dict = {}
                module_thread = module_class(
                    self,
                    self.__production_mode,
                    self.__execute_only_setup_and_exit,
                    self.__definition_globals,
                    self.input_id,
                    self.input_name,
                    self.input_config,
                    self.input_definition,
                    self.service_name,
                    self.service_type,
                    self.service_config,
                    self.service_definition,
                    module_class_name,
                    module_config,
                    module_definition,
                    self.persistence_factory_manager,
                    self.standard_queue,
                    self.lookup_queue,
                    self.internal_queue,
                    self.__rate_limiters,
                    submodule_name,
                    submodule_value
                )

                self.log_debug(f'{self.name} -> {module_thread.name} - Instance created')

                self.module_threads[module_thread.name] = module_thread
                submodules_instantiated += 1
            except Exception as ex:

                log_message = f"Error when creating class, " \
                              f"module_name: {module_class_full_name}, " \
                              f"module_definition: {module_definition}, " \
                              f"details: {ex}"
                raise SdkServiceInitializationError(
                    30,
                    log_message
                )

        return submodules_instantiated

    def __generate_submodules(self, module_definition):
        """In case of not existing any submodule this function should return the "module_definition" as "submodule"

        :param module_definition:
        :return:
        """

        submodules_property = module_definition.get("submodules_property")
        submodules_calculator_class_name = module_definition.get("submodule_calculator_class")
        detected_type: Optional[Type] = None
        submodules: dict = {}
        if submodules_calculator_class_name is not None:
            module_class = globals()[submodules_calculator_class_name]
            try:
                submodules = \
                    module_class.calculate_submodules(
                        self.service_name,
                        submodules_property,
                        self.input_config
                    )
            except Exception as e:
                exception = CollectorUtils.create_exception_msg_for_exception(e)
                self.log_error(json.dumps(exception))

        elif submodules_property is not None:

            if submodules_property in self.service_config:
                if isinstance(self.service_config[submodules_property], dict):
                    for submodule_name, submodule_value in self.service_config[submodules_property].items():
                        submodules[submodule_name] = submodule_value
                elif isinstance(self.service_config[submodules_property], list):
                    for submodule_value in self.service_config[submodules_property]:
                        if isinstance(submodule_value, str):
                            if detected_type is not None and detected_type != str:
                                raise SdkServiceInitializationError(
                                    10,
                                    f'The "{submodules_property}" property must have an aligned structure'
                                )
                            if detected_type is None:
                                detected_type = str
                            submodules[submodule_value] = submodule_value
                        elif isinstance(submodule_value, dict) and len(submodule_value) == 1:
                            if detected_type is not None and detected_type != dict:
                                raise SdkServiceInitializationError(
                                    20,
                                    f'The "{submodules_property}" property must have an aligned structure'
                                )
                            if detected_type is None:
                                detected_type = dict
                            submodules[list(submodule_value.keys())[0]] = list(submodule_value.values())[0]
                        else:

                            self.log_error(
                                f'Submodules definition is not having expected structure'
                            )

            else:
                submodules["all"] = None

                self.log_info(
                    f'There is not defined any submodule, using the default one with value "all"'
                )
        else:
            submodules[NO_SUBMODULES_MARK] = None
            log.debug(
                f'The submodule functionality is not used, '
                f'generating a dummy entry with "{NO_SUBMODULES_MARK}" as internal mark'
            )

        return submodules

    def __check_if_module_is_enabled(self, module_definition):
        """

        :param module_definition:
        :return:
        """

        module_enabled: bool = False
        mandatory_types_entry_in_config = self.service_definition.get("module_type_mandatory", False)
        module_type: str = module_definition.get("type")
        if module_type is None:
            raise SdkServiceInitializationError(
                2,
                f'Property "type" is missing in module definition'
            )

        module_enabled_by_default: bool = module_definition.get("default", True)
        if self.service_config is None and module_enabled_by_default is True:
            module_enabled = True
        else:
            type_entries_from_config = self.service_config.get("types")
            if mandatory_types_entry_in_config is True and type_entries_from_config is None:
                raise SdkServiceInitializationError(
                    101,
                    f'Configuration for service "{self.service_name}" must contain the entry "types"'
                )
            if type_entries_from_config is None:
                if module_enabled_by_default is True:
                    module_enabled = True
            else:
                if not isinstance(type_entries_from_config, list):
                    raise SdkServiceInitializationError(
                        1,
                        f'Property "types" is not a list (current type: "{type(type_entries_from_config)}")'
                    )

                for type_entry in type_entries_from_config:
                    if isinstance(type_entry, str):
                        if type_entry == module_type:
                            module_enabled = True
                            break
                    else:

                        self.log_error(
                            f'Property "types" is having a wrong format, '
                            f'each entry can be only "str" type'
                        )

        return module_enabled

    def wake_up(self) -> None:
        """Send a signal to the waiting object of current thread (service thread)

        :return:
        """

        if self.__thread_wait_object.is_set() is False:
            self.__thread_wait_object.set()

    def run(self) -> None:
        """Running section of the thread

        :return:
        """

        self.__object_status = ObjectStatuses.RUNNING

        while self.__running_flag:

            if self.__pause_thread is False \
                    and self.__stop_thread is False:

                self.log_debug(f'Entering in wait status')

                called: bool = self.__thread_wait_object.wait(
                    timeout=self.service_thread_execution_periods_in_seconds
                )
                if called is True:
                    self.__thread_wait_object.clear()

                self.log_debug(f'Waking up from wait status')

            self.__check_if_pause()

            self.__check_if_stop()

            self.__check_modules_status()

            if self._no_running_threads():
                self.__running_flag = False

        # self.log_info(
        #     f'Finalizing thread. '
        #     f'"Standard" and "Lookup" queues will be blocked because only module threads were using those queues'
        # )
        #
        # # Blocking the queues that will not be used anymore
        # self.standard_queue.block_input_queue()
        # self.lookup_queue.block_input_queue()

        self.__thread_is_stopped = True
        if self.__wait_object_for_stop_method.is_set() is False:
            self.__wait_object_for_stop_method.set()

        self.parent_thread.wake_up()

    def __check_if_pause(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is True:

            self.log_warning(f'Thread has been put in pause status, reason: "{self.__non_active_reason}')

            self.__thread_is_paused = True
            self.__pause_thread = False

            if self.__wait_object_for_pause_method.is_set() is False:
                self.__wait_object_for_pause_method.set()

            called: bool = self.__wait_object_for_pause_run.wait()
            if called is True:
                self.__wait_object_for_pause_run.clear()

            self.__thread_is_paused = False

            self.log_info(f'Thread has exited from pause status')

    def __check_if_stop(self) -> None:
        """

        :return:
        """

        if self.__stop_thread is True:
            self.__running_flag = False

    def start(self) -> None:
        """ Start descendant modules and then the current thread

        :return:
        """

        self.log_info(
            f'{self.name} - Starting thread (execution_period={self.service_thread_execution_periods_in_seconds}s)'
        )

        # Start all child threads
        if len(self.module_threads) > 0:
            for module in self.module_threads.values():
                module.start()
        super().start()

    def pause(self, wait: bool = None) -> None:
        """

        :param wait:
        :return:
        """

        if wait is None:
            raise SdkServiceRunningError(
                1,
                'The parameter "wait" is mandatory'
            )

        with self.__command_execution_lock:

            if self.__object_status != ObjectStatuses.RUNNING \
                    and self.__object_status != ObjectStatuses.PAUSING:

                self.log_warning(f'{self.name} -> Current thread is in a incompatible status for "pause" command')
                return

            if self.__object_status == ObjectStatuses.PAUSED:

                self.log_info(f'{self.name} -> Current thread was already in pause status')

                return

            self.__object_status = ObjectStatuses.PAUSING

            self.log_info(f'{self.name} -> Pausing current thread (wait={wait})')

            # self.pause_dependencies(wait=wait)

            self.__non_active_reason = NonActiveReasons.PAUSE_COMMAND_RECEIVED
            self.__pause_thread = True

            if self.__thread_wait_object.is_set() is False:
                self.__thread_wait_object.set()

            if wait is True:

                if self.__wait_object_for_pause_method.is_set() is True:
                    self.__wait_object_for_pause_method.clear()

                while self.__thread_is_paused is False:

                    self.log_debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_pause_method.clear()

                self.__object_status = ObjectStatuses.PAUSED

                self.log_info(f'{self.name} -> Thread has been paused after waiting (sync)')

            else:

                self.log_info(f'{self.name} -> Thread has been paused without waiting phase (async)')

    def pause_modules(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise SdkServiceRunningError(
                2,
                'The parameter "wait" is mandatory'
            )

        with self.__command_execution_lock:

            self.log_info(f'{self.name} -> Pausing all module threads (wait={wait})')

            if len(self.module_threads) > 0:
                for module_thread in self.module_threads.values():
                    module_thread.pause(wait=wait)

            self.log_info(f'{self.name} -> All module threads have been paused (wait={wait})')

    def stop(self) -> None:
        """

        :return:
        """

        if self.__thread_is_paused is False:
            self.log_error(f'{self.name} -> Is not in pause status')

        self.log_info(f'{self.name} -> Stopping thread')

        self.__non_active_reason = NonActiveReasons.STOP_COMMAND_RECEIVED
        self.__stop_thread = True

        self.__stop_dependencies()

        if self.__thread_wait_object.is_set() is False:
            self.__thread_wait_object.set()

        if self.__wait_object_for_pause_run.is_set() is False:
            self.__wait_object_for_pause_run.set()

        if self.__wait_object_for_stop_method.is_set() is True:
            self.__wait_object_for_stop_method.clear()

        while self.__thread_is_stopped is False:

            log.debug(f'{self.name} -> Waiting to be stopped')

            called: bool = self.__wait_object_for_stop_method.wait(timeout=10)
            if called is True:
                self.__wait_object_for_stop_method.clear()

        self.log_info(f'{self.name} -> Thread has been stopped')

    def __stop_dependencies(self) -> None:
        """

        :return:
        """

        self.log_info(f'{self.name} -> Stopping all dependent threads')

        if len(self.module_threads) > 0:
            for module_thread in self.module_threads.values():
                if isinstance(module_thread, str) is False:
                    module_thread.stop()

        self.log_info(f'{self.name} -> All dependent threads have been stopped')

    def __check_modules_status(self) -> None:
        """Update the REMOVED status of the current service threads

        :return:
        """

        # Detect dead threads
        module_threads_to_remove: list = []
        module_threads_setup_details: dict = {}
        for module_thread_name, module_thread in self.module_threads.items():

            if isinstance(module_thread, str) is False:
                if module_thread.is_alive() is False:
                    module_threads_to_remove.append(module_thread_name)
                elif self.__execute_only_setup_and_exit is True:
                    if module_thread.setup_execution_result is False:
                        self.log_error(f"An error happened validating module {module_thread_name}")
                    module_threads_setup_details[module_thread_name] = module_thread.setup_execution_result

        # If "None" value appears in the array means that some child thread has not finished yet
        if self.setup_and_exit_execution_result_details is None \
                and None not in module_threads_setup_details.values():

            self.setup_and_exit_execution_result_details = module_threads_setup_details

            self.log_debug(
                f"Finished the credentials check for all the children of {self.name}"
            )

            if False in module_threads_setup_details.values():
                self.setup_and_exit_execution_result_global = False
            else:
                self.setup_and_exit_execution_result_global = True

            self.parent_thread.wake_up()

        # Set all dead threads as REMOVED
        if len(module_threads_to_remove) > 0:
            for module_thread_name in module_threads_to_remove:
                internal_module_thread_name = self.module_threads[module_thread_name].getName()
                self.module_threads[module_thread_name] = "REMOVED"

                self.log_info(f'Removed finalized thread: {internal_module_thread_name}')

    def _no_running_threads(self) -> bool:
        """Check if all thread have been removed.

        :return: True if all threads have been removed. False if not.
        """

        # Get references
        number_of_setup_module_threads = len(self.module_threads)
        number_of_removed_threads = 0

        # Count how many threads have been removed
        for module_threads in self.module_threads.values():
            if module_threads == "REMOVED":
                number_of_removed_threads += 1

        # Check if all threads have been removed
        if number_of_setup_module_threads == number_of_removed_threads:
            return True
        else:

            log_message = "Still running {} of {} module threads: {}".format(
                number_of_setup_module_threads - number_of_removed_threads,
                number_of_setup_module_threads,
                [*self.module_threads.keys()]
            )
            self.log_debug(log_message)

            return False

    def send_internal_collector_message(self,
                                        message_content,
                                        level: str = None,
                                        shared_domain: bool = False) -> None:
        """

        :param message_content:
        :param level:
        :param shared_domain:
        :return:
        """

        CollectorUtils.send_internal_collector_message(
            self.internal_queue,
            message_content,
            input_name=self.input_name,
            service_name=self.service_name,
            level=level,
            shared_domain=shared_domain
        )

    def log_error(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.ERROR):
            log.error(message)
            self.send_internal_collector_message(message, level="error")

    def log_warning(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.WARNING):
            log.warning(message)
            self.send_internal_collector_message(message, level="warning")

    def log_info(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.INFO):
            log.info(message)
            self.send_internal_collector_message(message, level="info")

    def log_debug(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.DEBUG):
            log.debug(message)
            self.send_internal_collector_message(message, level="debug")
