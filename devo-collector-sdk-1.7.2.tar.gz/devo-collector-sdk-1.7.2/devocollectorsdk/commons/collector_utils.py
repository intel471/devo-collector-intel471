import importlib
import inspect
import json
import logging
import platform
import sys
from datetime import datetime
from typing import Union, Any

import pytz

from devocollectorsdk.commons.constants import Constants
from devocollectorsdk.configuration.configuration import CollectorConfiguration
from devocollectorsdk.message.message import Message
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue

log = logging.getLogger(__name__)


class CollectorUtils:

    collector_name: str = 'unknown'
    collector_id: str = 'unknown'
    collector_version: str = 'unknown'
    collector_owner: str = 'unknown'
    collector_recipe: str = 'unknown'

    @classmethod
    def set_collector_metadata_from_config(cls, conf: CollectorConfiguration):
        """Extract the collector metadata and load it on static properties"""

        collector_name: str = conf.get_collector_name()
        if collector_name:
            cls.collector_name = collector_name

        collector_id: str = conf.get_collector_id()
        if collector_id:
            cls.collector_id = collector_id

        collector_version: str = conf.get_collector_version()
        if collector_version:
            cls.collector_version = collector_version
        else:
            conf.collector_version = cls.collector_version

        collector_owner: str = conf.get_collector_owner()
        if collector_owner:
            cls.collector_owner = collector_owner

        collector_recipe: str = conf.get_collector_recipe()
        if collector_recipe:
            cls.collector_recipe = conf.get_collector_recipe()

        else:
            conf.collector_owner = cls.collector_owner

    @staticmethod
    def send_internal_collector_message(
            output_queue: CollectorMultiprocessingQueue,
            message_content: Union[str, dict],
            input_name: str = None,
            service_name: str = None,
            module_name: str = None,
            level: str = None,
            shared_domain: bool = False) -> None:
        """

        :param output_queue:
        :param message_content:
        :param input_name:
        :param service_name:
        :param module_name:
        :param level:
        :param shared_domain:
        :return:
        """

        if level is None:
            level = "default"

        message_timestamp = datetime.utcnow().replace(tzinfo=pytz.utc)

        message_tag = \
            "{base_tag}.{visibility}.{level}".format(
                base_tag=Constants.INTERNAL_MESSAGE_TAGGING_BASE,
                visibility="global" if shared_domain else "local",
                level=level.lower()
            )

        message_content_dict: dict = {}
        if isinstance(message_content, str):
            message_content_dict = {
                "msg": message_content
            }
        elif isinstance(message_content, dict):
            message_content_dict = message_content

        if "time" not in message_content_dict:
            message_content_dict["time"] = message_timestamp.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        if "level" not in message_content_dict:
            message_content_dict["level"] = level
        if "collector_name" not in message_content_dict:
            message_content_dict["collector_name"] = CollectorUtils.collector_name
        if "collector_version" not in message_content_dict:
            message_content_dict["collector_version"] = CollectorUtils.collector_version
        if "collector_image" not in message_content_dict:
            message_content_dict["collector_image"] = Constants.COLLECTOR_IMAGE
        if input_name and "input_name" not in message_content_dict:
            message_content_dict["input_name"] = input_name
        if service_name and "service_name" not in message_content_dict:
            message_content_dict["service_name"] = service_name
        if module_name and "module_name" not in message_content_dict:
            message_content_dict["module_name"] = module_name
        if shared_domain and "shared_domain" not in message_content_dict:
            message_content_dict["shared_domain"] = True

        output_queue.put(
            Message(
                message_timestamp,
                message_tag,
                json.dumps(message_content_dict),
                is_internal=True
            )
        )

    @staticmethod
    def load_class_object(module_class_name: str) -> (Any, str):
        """

        :param module_class_name:
        :return:
        """

        module_class_name_parts = module_class_name.rpartition(".")
        module_name = module_class_name_parts[0]
        class_name = module_class_name_parts[2]

        collector_module = importlib.import_module(module_name)
        module_class = getattr(collector_module, class_name)

        return module_class, class_name

    @staticmethod
    def create_exception_msg_for_exception(e: Exception) -> dict:
        """Creates a new exception message with all traceback

        :param e: Exception instance
        :return
        """

        exc_type, exc_value, exc_traceback = sys.exc_info()
        last_traceback = exc_traceback
        while last_traceback.tb_next is not None:
            last_traceback = last_traceback.tb_next
        exception_dict = {
            "msg": str(e),
            "file": last_traceback.tb_frame.f_code.co_filename,
            "line": str(last_traceback.tb_lineno),
            "function": last_traceback.tb_frame.f_code.co_name,
            "details": {
                "type": exc_type.__name__,
                "text": str(exc_value)
            }
        }
        return exception_dict

    @staticmethod
    def translate_human_to_secs(human_secs: str) -> int:
        """Calculate seconds from human string <int> [m|h|d|s|w]

        :param human_secs: Str instance with <int> [m|h|d|s|w] format
        :return: int instance with the results in seconds
        """
        seconds_per_unit = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
        seconds: int = int(human_secs[:-1]) * seconds_per_unit[human_secs[-1]]
        return seconds

    @staticmethod
    def human_readable_size(size, decimal_places=2) -> str:
        """Transform Bytes into human readable value

        :param size:
        :param decimal_places:
        :return:
        """
        for unit in ['B', 'KiB', 'MiB', 'GiB', 'TiB']:
            if size < 1024.0:
                break
            size /= 1024.0
        return f"{size:.{decimal_places}f}{unit}"

    @staticmethod
    def memory_info_to_human_dict(memory_info):
        """

        :param memory_info:
        :return:
        """
        memory_info_human_dict: dict = {}
        if memory_info is not None:
            for name in memory_info._fields:
                value = CollectorUtils.human_readable_size(getattr(memory_info, name))
                memory_info_human_dict[name] = value

        return memory_info_human_dict

    @staticmethod
    def get_size(obj, seen=None):
        """Recursively finds size of objects in bytes"""
        size = sys.getsizeof(obj)
        if seen is None:
            seen = set()
        obj_id = id(obj)
        if obj_id in seen:
            return 0
        # Important mark as seen *before* entering recursion to gracefully handle
        # self-referential objects
        seen.add(obj_id)
        if hasattr(obj, '__dict__'):
            for cls in obj.__class__.__mro__:
                if '__dict__' in cls.__dict__:
                    d = cls.__dict__['__dict__']
                    if inspect.isgetsetdescriptor(d) or inspect.ismemberdescriptor(d):
                        size += CollectorUtils.get_size(obj.__dict__, seen)
                    break
        if isinstance(obj, dict):
            size += sum((CollectorUtils.get_size(v, seen) for v in obj.values()))
            size += sum((CollectorUtils.get_size(k, seen) for k in obj.keys()))
        elif hasattr(obj, '__iter__') and not isinstance(obj, (str, bytes, bytearray)):
            try:
                size += sum((CollectorUtils.get_size(i, seen) for i in obj))
            except TypeError:
                log.exception(
                    "Unable to get size of %r. This may lead to incorrect sizes."
                    "Please report this error.", obj
                )
        if hasattr(obj, '__slots__'):  # can have __slots__ with __dict__
            size += sum(CollectorUtils.get_size(getattr(obj, s), seen) for s in obj.__slots__ if hasattr(obj, s))

        return size

    @staticmethod
    def memory_info_to_dict(memory_info: list):
        memory_info_dict: dict = {}
        if memory_info:
            current_os: str = platform.system()
            if current_os == 'Linux':
                memory_info_dict["rss"] = memory_info[0]
                memory_info_dict["vms"] = memory_info[1]
                memory_info_dict["shared"] = memory_info[2]
                memory_info_dict["text"] = memory_info[3]
                memory_info_dict["lib"] = memory_info[4]
                memory_info_dict["data"] = memory_info[5]
                memory_info_dict["dirty"] = memory_info[6]
            elif current_os == 'Darwin':
                memory_info_dict["rss"] = memory_info[0]
                memory_info_dict["vms"] = memory_info[1]
                memory_info_dict["pfaults"] = memory_info[2]
                memory_info_dict["pageins"] = memory_info[3]
            elif current_os == 'Windows':
                memory_info_dict["rss"] = memory_info[0]
                memory_info_dict["vms"] = memory_info[1]
                memory_info_dict["num_page_faults"] = memory_info[2]
                memory_info_dict["peak_wset"] = memory_info[3]
                memory_info_dict["wset"] = memory_info[4]
                memory_info_dict["peak_paged_pool"] = memory_info[5]
                memory_info_dict["paged_pool"] = memory_info[6]
                memory_info_dict["peak_nonpaged_pool"] = memory_info[7]
                memory_info_dict["nonpaged_pool"] = memory_info[8]
                memory_info_dict["pagefile"] = memory_info[9]
                memory_info_dict["peak_pagefile"] = memory_info[10]
                memory_info_dict["private"] = memory_info[11]

        return memory_info_dict
