import json
from datetime import datetime
from typing import Optional

import devocollectorsdk.commons.collector_utils as cs
from devocollectorsdk.message.message import Message
from devocollectorsdk.queues.content.collector_queue_item import CollectorQueueItem
from devocollectorsdk.queues.sender_manager_queue import SenderManagerQueue


class MetricBase:

    BASE_METRIC_TAG = "devo.collector.metric"

    def __init__(
            self,
            metric_queue: SenderManagerQueue
    ) -> None:
        self._col_id = cs.CollectorUtils.collector_id
        self._col_name = cs.CollectorUtils.collector_name
        self._col_version = cs.CollectorUtils.collector_version
        self._col_image = cs.CollectorUtils.collector_recipe
        self._metric_queue = metric_queue

        self._base_tag: str = self.BASE_METRIC_TAG
        self._tag: Optional[str] = None

    @property
    def tag(self):
        return self._tag

    def _to_dict(self) -> dict:
        metric_message = {
            'col_id': self._col_id,
            'col_name': self._col_name,
            'col_version': self._col_version,
            'col_image': self._col_image
        }
        return metric_message

    def __str__(self) -> str:
        return json.dumps(self._to_dict())

    def _build_message(self) -> Message:
        metric_message = Message(
            datetime.utcnow(),
            self.tag,
            str(self)
        )
        return metric_message

    def send_metric_message(self) -> None:
        item: CollectorQueueItem = CollectorQueueItem(self._build_message())
        self._metric_queue.put(item)


class MetricMessage(MetricBase):

    MESSAGE_TAG = 'message_sent'

    def __init__(self, queue: SenderManagerQueue, **kwargs) -> None:
        super().__init__(queue)
        self._msgs: int = kwargs["partial_msgs_sent"]
        self._bytes: int = kwargs["partial_bytes_sent"]
        self._ts: datetime = kwargs["last_snapshot_timestamp"]
        self._message_tag = self.MESSAGE_TAG

    @property
    def tag(self):
        return f'{self._base_tag}.{self._message_tag}'

    @property
    def ts(self):
        return int(self._ts.timestamp() * 1000)

    def _to_dict(self) -> dict:
        metric_base_dct = super()._to_dict()
        metric_base_dct.update({
            'msg_sent': {
                'part_counter': self._msgs,
                'part_bytes': self._bytes,
                'since_ts': self.ts
            }
        })
        return metric_base_dct
