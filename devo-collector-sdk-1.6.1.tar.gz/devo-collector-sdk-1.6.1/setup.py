from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

requires = [
    "cryptography==38.0.4",
    "Click==8.1.3",
    "requests==2.27.1",
    "ratelimiter==1.2.0.post0",
    "devo-sdk==3.6.4",
    "redis==4.3.5",
    "python-dateutil==2.8.2",
    "PyYAML==6.0",
    "pytz==2022.7.1",
    "syslog-py==0.2.5",
    "psutil==5.9.4",
    "jsonschema==4.17.3",
    "behave==1.2.6",
    "glom==22.1.0"

]

setup(
    name="devo-collector-sdk",
    version='1.6.1',
    author="Devo Inc.",
    author_email="integrations_factory@devo.com",
    maintainer="Felipe Conde",
    maintainer_email="felipe.conde@devo.com",
    description="Devo Collector SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://devoinc.github.com/devo-collector-sdk",
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6, <3.10',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
        "Operating System :: Microsoft :: Windows"
    ],
    setup_requires=['wheel'],
    install_requires=requires,
    entry_points={
        "console_scripts": ["devo-collector=devocollectorsdk.main:main"]
    }

)
