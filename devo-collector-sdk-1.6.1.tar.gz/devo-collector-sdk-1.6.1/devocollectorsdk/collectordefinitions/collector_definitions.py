import json
import os

import yaml

from devocollectorsdk.commons.collector_exceptions import SdkDefinitionsInitializationError


class CollectorDefinitions:
    """
    This class will contain all the collector definitions properties
    """
    COLLECTOR_DEFINITIONS_DIRECTORY = "config_internal"
    COLLECTOR_DEFINITIONS_FILENAME = "collector_definitions.yaml"

    def __init__(self) -> None:
        self.__definitions_filename: str = \
            CollectorDefinitions.__calculate_collector_definitions_filename()
        self.__definitions: dict = self.__load_collector_definitions_from_file()

    def get_collector_definitions(self) -> dict:
        """Return the variable that contains the collector definitions

        :return: A dictionary containing all collector definitions
        :rtype: dict
        """
        return self.__definitions

    @classmethod
    def __calculate_collector_definitions_filename(cls) -> str:
        return os.path.join(
                os.getcwd(),
                cls.COLLECTOR_DEFINITIONS_DIRECTORY,
                cls.COLLECTOR_DEFINITIONS_FILENAME
            )

    def get_collector_globals(self) -> dict:
        """

        :return:
        """
        return self.__definitions["collector_globals"]

    def get_input_definition(self, input_name: str) -> dict:
        """

        :param input_name:
        :return:
        """
        return self.__definitions["collector_inputs"].get(input_name)

    def __load_collector_definitions_from_file(self) -> dict:
        try:
            with open(self.__definitions_filename) as service_definitions_file:
                service_definitions_content = yaml.safe_load(service_definitions_file)
                return service_definitions_content
        except FileNotFoundError as ex:
            raise SdkDefinitionsInitializationError(
                1,
                f'Collector definitions were not loaded, '
                f'please check that file "{self.__definitions_filename}" already exists: {str(ex)}'
            )
        except yaml.constructor.ConstructorError as ex:
            raise SdkDefinitionsInitializationError(
                2,
                f'Collector definitions were not loaded, '
                f'the file "{self.__definitions_filename}" exists but maybe is having a '
                f'wrong YAML format: {str(ex)}'
            )
        except Exception as ex:
            raise SdkDefinitionsInitializationError(
                3,
                f'Collector definitions were not loaded, '
                f'the file "{self.__definitions_filename}" exists but is generating an error: {str(ex)}'
            )

    def get_status(self) -> dict:
        """

        :return:
        """
        status = {
            "definitions_filename": self.__definitions_filename if self.__definitions_filename else None,
            "definitions": self.__definitions if self.__definitions else None
        }
        return status

    def __str__(self):
        return json.dumps(self.get_status())

    def get_obfuscation_keys(self) -> dict:

        obfuscation_params: dict = {}

        for input_name, value in self.get_collector_definitions().get('collector_inputs').items():

            obfuscation_params['input'] = input_name
            obfuscation_params['config_obfuscation'] = value.get('config_obfuscation')

            if not obfuscation_params or not obfuscation_params.get('config_obfuscation'):
                raise SdkDefinitionsInitializationError(
                    4,
                    f"Error found in '{self.__definitions_filename}' file. 'config_obfuscation' is a mandatory field."
                )

        return obfuscation_params

    @staticmethod
    def is_obfuscation_needed(obfuscation_config):
        return obfuscation_config.get('config_obfuscation', {}).get('key_value_entries') or False
