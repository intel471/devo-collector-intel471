import ctypes
import gc
import inspect
import json
import logging
import multiprocessing
import os
import threading
from multiprocessing.connection import Connection
from typing import Union, Optional

import psutil

from devocollectorsdk.collectordefinitions.collector_definitions import CollectorDefinitions
from devocollectorsdk.commons.collector_exceptions import SdkInputInitializationError, SdkPersistenceConfigurationError
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.object_statuses import ObjectStatuses
from devocollectorsdk.configuration.configuration import CollectorConfiguration
from devocollectorsdk.inputs.input_thread import InputThread
from devocollectorsdk.persistence.persistence_factory_manager import PersistenceFactoryManager
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.queues.content.collector_notification import CollectorNotification
from devocollectorsdk.queues.content.collector_order import CollectorOrder
from devocollectorsdk.ratelimiter.collector_rate_limiter_list import CollectorRateLimiterList

# Globals
log = logging.getLogger(__name__)
log_level = logging.INFO


class InputMultiprocessingController(multiprocessing.Process):

    def __init__(self,
                 config: CollectorConfiguration,
                 definitions: CollectorDefinitions,
                 standard_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 internal_queue: CollectorMultiprocessingQueue,
                 controller_thread_wait_object: multiprocessing.Event = None,
                 controller_commands_connection: Connection = None,
                 production_mode: bool = None,
                 execute_only_setup_and_exit: bool = None):
        """This class creates all input services in an isolated multiprocessing process.

        It is in charge of puller and setup instances.
        :param config: a CollectorConfiguration object.
        :param standard_queue: An internal multiprocessing queue instance used for sending the standard messages.
        :param lookup_queue: An internal multiprocessing queue instance used for sending the lookup messages.
        :param internal_queue: An internal multiprocessing queue instance used for sending the internal messages.
        :param controller_thread_wait_object: multiprocessing.Event() from parent process
        :param controller_commands_connection:
        :param production_mode:
        :param execute_only_setup_and_exit:
        """
        super().__init__()

        self.__object_status = ObjectStatuses.INITIALIZING

        # Get the class and global properties
        self.name = "InputProcess"
        self.__debug_enabled = config.get_globals().get("debug", False)

        self.__configuration: CollectorConfiguration = config
        self.__definitions: CollectorDefinitions = definitions

        # Queue objects
        self.__standard_queue: CollectorMultiprocessingQueue = standard_queue
        self.__lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.__internal_queue: CollectorMultiprocessingQueue = internal_queue

        # Object to be used for waking up the parent process of its wait status
        self.__controller_thread_wait_object: multiprocessing.Event = controller_thread_wait_object
        self.__production_mode: bool = production_mode
        self.__execute_only_setup_and_exit: bool = execute_only_setup_and_exit
        self.__input_threads: Optional[dict] = None
        self.persistence_factory_manager: Optional[PersistenceFactoryManager] = None

        # Extract the configuration
        self.__configuration_inputs = config.get_inputs()
        if self.__configuration_inputs is None:
            raise SdkInputInitializationError(
                1000,
                "Required <inputs> entry not found in configuration"
            )

        # Extract some objects from collector definitions
        self.__definitions_globals = definitions.get_collector_globals()
        if self.__definitions_globals is None:
            raise SdkInputInitializationError(
                1010,
                'Required "collector_globals" entry not found in collector definitions'
            )

        self.__rate_limiters: Optional[CollectorRateLimiterList] = None

        self.__input_process_execution_periods_in_seconds: int = \
            self.__definitions_globals["input_process_execution_periods_in_seconds"]

        # Extract the required configuration objects
        self.configuration_globals: dict = config.get_globals()
        if self.configuration_globals is None:
            raise SdkInputInitializationError(
                1020,
                "Required <globals> entry not found in configuration."
            )

        # Communication channel between this process (input) and the parent one (collector)
        self.__controller_commands_connection: Connection = controller_commands_connection

        # The following variables must be shareable between multiprocessing objects
        self.__controller_process_wait_object: multiprocessing.Event = multiprocessing.Event()
        self.__running_flag: multiprocessing.Value = multiprocessing.Value(ctypes.c_bool, True)

        # Definitions incompatible with multiprocessing jump will be loaded into the execution method.
        self.initial_running_flag_state = None

        self.__object_status = ObjectStatuses.INITIALIZED

    def wake_up(self) -> None:
        """ Wake up the run method when it is waiting for an external input (while loop) """

        if self.__controller_process_wait_object.is_set() is False:
            self.__controller_process_wait_object.set()

    def run(self) -> None:
        """Once run() method is called, we can create objects in the new multiprocessing process"""

        self.__activate_logging()

        self.log_info(f"Process Started")

        self.__self_definitions()
        self.__start_threads()
        self.__watch_service()

        # self.__wait_until_all_threads_are_stopped()

        self.__send_notification_to_main_process(
            CollectorNotification.create_input_process_is_stopped_notification(
                "Due to order received"
            )
        )

        alive_thread_names = []
        for t in threading.enumerate():
            if t.is_alive() and t.name != "MainThread":
                alive_thread_names.append(t.name)

        if alive_thread_names:
            self.log_warning(
                f'Finalizing process, there are still some threads alive: {json.dumps(alive_thread_names)}'
            )
        else:
            self.log_info(
                "Finalizing process"
            )

        self.log_info(
            f'"Standard", "Lookup" and "Internal" queues will be blocked'
        )

        # Blocking the queues that will not be used anymore
        self.__standard_queue.block_input_queue()
        self.__lookup_queue.block_input_queue()

        self.log_debug(
            f'This is the last message from this thread, after this the "Internal" queue will be blocked'
        )

        # Since this point no messages will be allowed to be sent to the internal queue
        self.__internal_queue.block_input_queue()

    def __wait_until_all_threads_are_stopped(self) -> None:
        """

        :return:
        """

        still_threads_alive = True
        while still_threads_alive:
            alive_threads = []
            for t in threading.enumerate():
                if t.is_alive() and t.name != "MainThread":
                    alive_threads.append(t.name)

            if alive_threads:
                log.warning(f'There are some alive_threads: {json.dumps(alive_threads)}')
                called: bool = self.__controller_process_wait_object.wait(timeout=1)
                if called is True:
                    self.__controller_process_wait_object.clear()
            else:
                still_threads_alive = False

    def start(self) -> None:
        """

        :return:
        """

        self.log_info(
            f"{self.name} - Starting thread (executing_period={self.__input_process_execution_periods_in_seconds}s)"
        )

        super().start()

    def __create_input_threads(self) -> int:
        """Creates the threads in the tree.

        :return: Number of available input threads.
        """

        inputs_available = 0

        # Iterate inputs_configuration
        for input_name, input_config in self.__configuration_inputs.items():

            input_definition = self.__definitions.get_input_definition(input_name)
            if input_definition is None:
                raise SdkInputInitializationError(
                    1030,
                    f'The "input" configuration entry does not exist in the collector definitions'
                )

            if input_config is None:
                raise SdkInputInitializationError(
                    1040,
                    f'The "input" configuration entry is not having the proper structure'
                )

            enabled = input_config.get("enabled", True)
            if enabled is True:
                self.__create_input_thread(
                    input_name,
                    input_config,
                    input_definition
                )
                inputs_available += 1
            else:
                log.warning(f'The "input" configuration entry for {input_name} is not enabled')

        return inputs_available

    def __create_input_thread(self,
                              input_name: str,
                              input_config: dict,
                              input_definition: dict) -> None:
        """Creates a new thread with the given definition.

        :param input_config: Input config dict
        :param input_definition: Input definition
        :param input_name: Input name
        :param inputs_available: Available threads counter
        :return: Count of available threads
        """
        # Get the input_id for this thread
        input_id: str = \
            str(input_config["id"]) if "id" in input_config and len(str(input_config["id"])) > 0 else None
        input_config["id"] = input_id if input_id else None

        # Create thread
        input_thread = InputThread(
            self,
            self.__definitions_globals,
            self.__production_mode,
            self.__execute_only_setup_and_exit,
            input_id,
            input_name,
            input_config,
            input_definition,
            self.__standard_queue,
            self.__lookup_queue,
            self.__internal_queue,
            self.persistence_factory_manager,
            self.__rate_limiters
        )

        self.log_debug(
            f'{__class__.__name__}::{inspect.stack()[0][3]} -> {input_thread.name} - Instance created'
        )

        # Store new thread
        self.__input_threads[input_thread.name] = input_thread

    def __activate_logging(self):
        """This method config the logging for this multiprocessing process"""
        global log_level

        if self.__debug_enabled is True:
            log_level = logging.DEBUG

        logging.basicConfig(
            level=log_level,
            format='%(asctime)s.%(msecs)03d %(levelname)7s %(processName)s::%(threadName)s -> %(message)s',
            datefmt='%Y-%m-%dT%H:%M:%S'
        )

    def __self_definitions(self) -> None:
        """This method populate the self definitions with pickle-incompatible procedure

        :return:
        """

        self.log_debug(
            f'Instantiating pickle-incompatible properties'
        )

        self.__input_threads = {}
        self.persistence_factory_manager: PersistenceFactoryManager = self._create_persistence_factory_manager()

        self.__rate_limiters = CollectorRateLimiterList()

        requests_limits_inputs_global: list = self.__definitions_globals.get("requests_limits")

        self.__rate_limiters.add_rate_limiters_from_list(requests_limits_inputs_global)

        number_of_available_input_threads = self.__create_input_threads()

        self.initial_running_flag_state: bool = True if number_of_available_input_threads > 0 else False
        running_flag = True if self.initial_running_flag_state is True else False
        self.__running_flag: multiprocessing.Value = multiprocessing.Value(ctypes.c_bool, running_flag)

    def _create_persistence_factory_manager(self) -> PersistenceFactoryManager:
        """Create a new persistence factory manager

        :return: A PersistenceFactoryManager instance
        """

        collector_id: Optional[str, int] = self.configuration_globals.get("id")
        if collector_id is None:
            raise SdkPersistenceConfigurationError(
                10,
                'Required "globals.id" entry not found in configuration'
            )

        collector_name: Optional[str, int] = self.configuration_globals.get("name")
        if collector_name is None:
            raise SdkPersistenceConfigurationError(
                20,
                'Required "globals.name" entry not found in configuration'
            )

        persistence_config: dict = self.configuration_globals.get("persistence")
        if persistence_config is None:
            raise SdkPersistenceConfigurationError(
                30,
                'Required "globals.persistence" entry not found in configuration'
            )

        persistence_factory_manager: PersistenceFactoryManager = \
            PersistenceFactoryManager(
                collector_id=str(collector_id),
                collector_name=collector_name,
                persistence_config=persistence_config
            )

        self.log_debug(
            f'A new Persistence Factory Manager has been created'
        )

        return persistence_factory_manager

    def __start_threads(self) -> None:
        """This method starts all threads instances"""
        if len(self.__input_threads) > 0:
            for input_thread in self.__input_threads.values():
                input_thread.start()

    def __watch_service(self):
        """This method watches over related thread instances status while the running_flag is True."""

        while self.__running_flag.value:

            # Proceed to execute a memory garbage collection
            self.__cleaning_memory()

            log.info(
                f'global_status: {json.dumps(self.__get_summary_status())}'
            )

            self.log_debug(f'Entering in wait status')
            called: bool = \
                self.__controller_process_wait_object.wait(
                    timeout=self.__input_process_execution_periods_in_seconds
                )
            if called is True:
                self.__controller_process_wait_object.clear()

            self.log_debug(f'Waking up from wait status')

            self.__check_pending_orders()

            self._check_inputs_status()
            if self.__no_running_threads():
                self.__running_flag.value = False

        if self.initial_running_flag_state is True:
            self.log_info("Stopping process")
        else:
            self.log_info("Nothing to do, stopping process")

    def __check_pending_orders(self) -> None:
        """

        :return:
        """

        if self.__controller_commands_connection.poll():
            collector_order: CollectorOrder = self.__controller_commands_connection.recv()
            self.log_debug(f'Received order: {collector_order}')

            if collector_order == CollectorOrder.PAUSE_ALL_INPUTS_WITHOUT_WAITING:

                self.log_info(
                    f'All input threads will be put on pause status without waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause(wait=False)

                self.log_info(
                    f'All input threads have been paused without waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_inputs_are_paused_without_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(f'A notification will be sent to the InputControllerThread')

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.PAUSE_ALL_INPUTS_WAITING:

                self.log_info(
                    f'All input threads will be put on pause status waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause(wait=True)

                self.log_info(
                    f'All input threads have been paused waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_inputs_are_paused_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(f'A notification will be sent to the InputControllerThread')

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.PAUSE_ALL_SERVICES_WITHOUT_WAITING:

                self.log_info(
                    f'All service threads will be put on pause status without waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause_services(wait=False)

                self.log_info(
                    f'All service threads have been paused without waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_services_are_paused_without_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(
                    f'A notification will be sent to the InputControllerThread'
                )

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.PAUSE_ALL_SERVICES_WAITING:

                self.log_info(
                    f'All service threads will be put on pause status waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause_services(wait=True)

                self.log_info(
                    f'All service threads have been paused waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_service_are_paused_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(
                    f'A notification will be sent to the InputControllerThread'
                )

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.PAUSE_ALL_MODULES_WITHOUT_WAITING:

                self.log_info(
                    f'All module threads will be put on pause status without waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause_modules(wait=False)

                self.log_info(
                    f'All module threads have been paused without waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_modules_are_paused_without_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(f'A notification will be sent to the InputControllerThread')

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.PAUSE_ALL_MODULES_WAITING:

                self.log_info(
                    f'All module threads will be put on pause status waiting until the command to be completed'
                )

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        input_thread: InputThread
                        input_thread.pause_modules(wait=True)

                self.log_info(
                    f'All module threads have been paused waiting until the underlying commands to be completed'
                )

                notification = \
                    CollectorNotification.create_all_modules_are_paused_waiting_notification(
                        f'Done due to order: {collector_order}'
                    )
                self.log_debug(f'A notification will be sent to the InputControllerThread')

                self.__send_notification_to_main_process(notification)

            elif collector_order == CollectorOrder.STOP_INPUT_CONTROLLER:

                if len(self.__input_threads) > 0:
                    for input_thread in self.__input_threads.values():
                        if isinstance(input_thread, InputThread):
                            input_thread.stop()

                self.log_info(f'All input threads have been stopped')

                self.log_debug(f'A notification will be sent to the InputControllerThread')

                self.__running_flag.value = False

            else:
                log.error(f'Received an unknown order: {collector_order}')

    def __cleaning_memory(self) -> None:
        """They will be cleaned all the "dead" objects

        :return:
        """

        current_process = psutil.Process(os.getpid())

        memory_usage_mb_before_rss = current_process.memory_info().rss
        memory_usage_mb_before_vms = current_process.memory_info().vms
        memory_usage_info_before = psutil.virtual_memory()
        gc.collect()
        memory_usage_mb_after_rss = current_process.memory_info().rss
        memory_usage_mb_after_vms = current_process.memory_info().vms
        memory_usage_info_after = psutil.virtual_memory()

        log_message = \
            f'[GC] ' \
            f'global: ' \
            f'{memory_usage_info_before.percent}% -> ' \
            f'{memory_usage_info_after.percent}%, ' \
            f'process: RSS({CollectorUtils.human_readable_size(memory_usage_mb_before_rss)} -> ' \
            f'{CollectorUtils.human_readable_size(memory_usage_mb_after_rss)}), ' \
            f'VMS({CollectorUtils.human_readable_size(memory_usage_mb_before_vms)} -> ' \
            f'{CollectorUtils.human_readable_size(memory_usage_mb_after_vms)})'

        self.log_info(log_message)

        log_message = \
            f'[GC] ' \
            f'memory_before(' \
            f'total: {CollectorUtils.human_readable_size(memory_usage_info_before.total)}, ' \
            f'used: {CollectorUtils.human_readable_size(memory_usage_info_before.used)}' \
            f'), ' \
            f'memory_after(' \
            f'total: {CollectorUtils.human_readable_size(memory_usage_info_after.total)}, ' \
            f'used: {CollectorUtils.human_readable_size(memory_usage_info_after.used)}' \
            f')'
        self.log_debug(log_message)

    def _check_inputs_status(self):
        """Detects dead threads and mark them as removed

        :return:
        """

        input_threads_to_remove: list = []

        # Detect the dead threads
        for input_thread_name, input_thread in self.__input_threads.items():
            if isinstance(input_thread, str) is False and input_thread.is_alive() is False:
                input_threads_to_remove.append(input_thread_name)

        # Execute only if there are threads to remove
        if len(input_threads_to_remove) > 0:
            for input_thread_name in input_threads_to_remove:
                # Mark thread as removed
                internal_input_thread_name = self.__input_threads[input_thread_name].getName()
                self.__input_threads[input_thread_name] = "REMOVED"

                self.log_info(f'Removed finalized thread: {internal_input_thread_name}')

    def __no_running_threads(self) -> bool:
        """Checks if all the input_threads are successfully removed.

        :return: True if yes, False if not.
        """
        number_of_setup_input_threads = len(self.__input_threads)
        number_of_removed_threads = 0

        # Count the removed threads
        for input_thread in self.__input_threads.values():
            if input_thread == "REMOVED":
                number_of_removed_threads += 1

        # Execute the checking
        if number_of_setup_input_threads != number_of_removed_threads:

            log_message = "Still running {} of {} input threads: {}".format(
                number_of_setup_input_threads - number_of_removed_threads,
                number_of_setup_input_threads,
                [*self.__input_threads]
            )
            self.log_debug(log_message)

            return False

        return True

    def __send_notification_to_main_process(self, notification: CollectorNotification):
        """

        :return:
        """
        self.__controller_commands_connection.send(notification)
        if self.__controller_thread_wait_object.is_set() is False:
            self.__controller_thread_wait_object.set()

    def send_internal_collector_message(self,
                                        message_content: Union[str, dict],
                                        level: str = None,
                                        shared_domain: bool = False):
        """This function add a new message to the internal collector.

        :param message_content: Message to be sent to Devo.
        :param level: Severity of the message.
        :param shared_domain: True if the message has <shared_domain> property to be
        watched by IF Devo Team for monitoring purposes.
        """

        CollectorUtils.send_internal_collector_message(
            self.__internal_queue,
            message_content,
            level=level,
            shared_domain=shared_domain
        )
        # pass

    def log_error(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.ERROR):
            log.error(message)
            self.send_internal_collector_message(message, level="error")

    def log_warning(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.WARNING):
            log.warning(message)
            self.send_internal_collector_message(message, level="warning")

    def log_info(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.INFO):
            log.info(message)
            self.send_internal_collector_message(message, level="info")

    def log_debug(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.DEBUG):
            log.debug(message)
            self.send_internal_collector_message(message, level="debug")

    def __get_summary_status(self) -> dict:
        """

        :return:
        """
        input_statuses: list = []
        for input_thread in self.__input_threads.values():
            input_thread: InputThread
            input_status = input_thread.get_summary_status()
            input_statuses.append(input_status)

        thread_names: list = []
        for t in threading.enumerate():
            thread_names.append(t.name)

        current_process = psutil.Process(pid=self.pid)
        with current_process.oneshot():
            process_status = current_process.status()
            process_num_threads = current_process.num_threads()
            process_memory_info = current_process.memory_info()

            status: dict = {
                "input_process": {
                    "process_id": current_process.pid,
                    "process_status": process_status,
                    "thread_counter": process_num_threads,
                    "thread_names": thread_names,
                    "memory_info": CollectorUtils.memory_info_to_human_dict(process_memory_info),
                    "input_threads": input_statuses,
                    "running_flag": self.__running_flag.value,
                    "message_queues": {
                        "standard": self.__standard_queue.get_summary_status(),
                        "lookup": self.__lookup_queue.get_summary_status(),
                        "internal": self.__internal_queue.get_summary_status()
                    }
                }
            }
            return status
