import collections
import inspect
import json
import logging
import threading
import time
from datetime import timedelta

log = logging.getLogger(__name__)


def rate_limit_callback(until: time, rate_limiter_name: str):
    """
    Execute the default RateLimiter callbacks

    :param until: (time) timestamp indicating how long to wait
    :param rate_limiter_name:
    """
    duration: float = until - time.time()
    threading.current_thread().name = f"{rate_limiter_name} -> Ratelimiter"
    log_message: str = \
        f'Local rate limit is blocking new calls for {duration:.5f} seconds ' \
        f'(DEBUG < 1 sec < INFO)'
    if timedelta(seconds=duration) > timedelta(seconds=1):
        log.info(log_message)
    else:
        log.debug(log_message)


class CollectorRateLimiter:

    def __init__(self, period_in_seconds: int, number_of_requests: int, caller_class_name: str = None):

        if period_in_seconds < 1:
            raise ValueError('Rate limit period in seconds should be >= 1')
        if number_of_requests <= 0:
            raise ValueError('Rate limit number of request should be > 0')

        self.__rate_limiter_name: str = f'{period_in_seconds}/{number_of_requests}'

        self.__period_in_seconds: int = period_in_seconds
        self.__number_of_requests: int = number_of_requests

        self.__calls: collections.deque = collections.deque()
        self.__lock = threading.Lock()

        self.__caller_class_name: str = caller_class_name

    def __enter__(self):
        with self.__lock:
            # We want to ensure that no more than number_of_requests were run in the allowed
            # period. For this, we store the last timestamps of each call and run
            # the rate verification upon each __enter__ call.
            if len(self.__calls) >= self.__number_of_requests:
                until = time.time() + self.__period_in_seconds - self.__timespan
                t = threading.Thread(target=rate_limit_callback, args=(until, self.__rate_limiter_name))
                t.daemon = True
                t.start()
                sleep_time = until - time.time()

                if sleep_time > 0:
                    time.sleep(sleep_time)
            return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with self.__lock:
            # Store the last operation timestamp.
            self.__calls.append(time.time())

            # Pop the timestamp list front (ie: the older calls) until the sum goes
            # back below the period. This is our 'sliding period' window.
            while self.__timespan >= self.__period_in_seconds:
                self.__calls.popleft()

    @property
    def __timespan(self):
        return self.__calls[-1] - self.__calls[0]

    def __str__(self):
        rate_limiter_dict = {
            "name": self.__rate_limiter_name,
            "period_in_seconds": self.__period_in_seconds,
            "number_of_requests": self.__number_of_requests,
            "caller_class_name": self.__caller_class_name
        }
        return json.dumps(rate_limiter_dict)

    def __repr__(self):
        return f'{self.__class__.__name__}(' \
               f'name="{self.__rate_limiter_name}", ' \
               f'periods_in_seconds={self.__period_in_seconds}, ' \
               f'number_of_requests={self.__number_of_requests}' \
               f') <id={self.__hash__()}, caller="{self.__caller_class_name}">'

    @property
    def name(self) -> str:
        return self.__rate_limiter_name

    def _test_reference(self, value: int):
        self.__number_of_requests = value

    @property
    def period_in_seconds(self) -> int:
        return self.__period_in_seconds

    @property
    def number_of_requests(self) -> int:
        return self.__number_of_requests
