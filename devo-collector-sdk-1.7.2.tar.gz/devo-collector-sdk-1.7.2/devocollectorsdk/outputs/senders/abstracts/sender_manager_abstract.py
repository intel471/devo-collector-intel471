import inspect
import json
import logging
import threading
from abc import ABC, abstractmethod
from datetime import datetime
from queue import Empty
from threading import Thread
from typing import Union, Mapping, Any, Optional

from devocollectorsdk.commons.collector_exceptions import SdkSenderManagerAbstractError
from devocollectorsdk.commons.non_active_reasons import NonActiveReasons
from devocollectorsdk.controllers.statuses.component_status import ComponentStatus
from devocollectorsdk.controllers.statuses.status_enum import StatusEnum
from devocollectorsdk.outputs.senders.abstracts.sender_abstract import SenderAbstract
from devocollectorsdk.outputs.senders.console_sender import ConsoleSender
from devocollectorsdk.outputs.senders.console_sender_manager_monitor import ConsoleSenderManagerMonitor
from devocollectorsdk.outputs.senders.console_senders import ConsoleSenders
from devocollectorsdk.outputs.senders.devo_sender import DevoSender
from devocollectorsdk.outputs.senders.devo_sender_manager_monitor import DevoSenderManagerMonitor
from devocollectorsdk.outputs.senders.devo_senders import DevoSenders
from devocollectorsdk.outputs.senders.syslog_sender import SyslogSender
from devocollectorsdk.outputs.senders.syslog_sender_manager_monitor import SyslogSenderManagerMonitor
from devocollectorsdk.outputs.senders.syslog_senders import SyslogSenders
from devocollectorsdk.persistence.emergency.emergency_persistence_system import EmergencyPersistenceSystem
from devocollectorsdk.queues.content.collector_notification import CollectorNotification
from devocollectorsdk.queues.content.collector_queue_item import CollectorQueueItem
from devocollectorsdk.queues.one_to_many_communication_queue import OneToManyCommunicationQueue
from devocollectorsdk.queues.sender_manager_queue import SenderManagerQueue

SenderType = Union[ConsoleSender, DevoSender, SyslogSender]
SendersType = Union[ConsoleSenders, DevoSenders, SyslogSenders]
ManagerMonitorType = Union[ConsoleSenderManagerMonitor, DevoSenderManagerMonitor, SyslogSenderManagerMonitor]

log = logging.getLogger(__name__)


class SenderManagerAbstract(ABC, Thread):
    """ Sender Manager abstract Class to be used as a base """

    def __init__(self, **kwargs: Optional[Any]):
        """Builder.

        :param kwargs:  -> group_name (str): Group name
                        -> content_type: Type of content [internal|lookup|standard]
                        -> instance_name (str): Name of the instance
                        -> configuration (dict): Dictionary with the configuration
                        -> generate_collector_details (bool) Defines if the collector details must be generated
        """
        super().__init__()

        # Force the initialization of internal vars in the __init__ method
        self._concurrent_connections = None

        self._validate_kwargs_for_method__init__(kwargs)

        # Kwargs loading
        oc_communication_channel: OneToManyCommunicationQueue = kwargs['output_controller_communication_channel']
        oc_instance = kwargs['output_controller_instance']
        group_name: str = kwargs['group_name']
        content_type: str = kwargs['content_type']
        instance_name: str = kwargs['instance_name']
        configuration: dict = kwargs['configuration']
        generate_collector_details: bool = kwargs.get('generate_collector_details', False)

        self._output_controller_communication_channel: OneToManyCommunicationQueue = oc_communication_channel
        self._output_controller_process = oc_instance

        self.content_type: str = content_type

        # Id settings
        self.internal_name: str = 'SenderManagerAbstract'
        self.group_name: str = group_name
        self.instance_name: str = instance_name

        # Stats settings
        self._generate_collector_details: bool = generate_collector_details

        # Renaming of thread object
        self.name: str = self.__class__.__name__ + f"({group_name},manager,{instance_name})"

        # Settings extraction
        server_configuration: dict = configuration.get("config")
        if not server_configuration:
            raise SdkSenderManagerAbstractError(
                1,
                'Required "config" entry not found in configuration'
            )

        # Request the custom configuration settings
        self._server_configuration(server_configuration)

        # Sender stats and performance
        self._period_sender_stats_in_seconds: int = server_configuration["period_sender_stats_in_seconds"]
        self._generate_metrics: bool = server_configuration["generate_metrics"]
        self._activate_final_queue: bool = server_configuration["activate_final_queue"]

        # Internal properties
        self._sender_manager_queue: SenderManagerQueue = \
            SenderManagerQueue(
                self.name,
                generate_metrics=self._generate_metrics,
                maxsize=10
            )

        # Variables related to run/pause/stop statuses
        self.__command_execution_lock: threading.Lock = threading.Lock()

        self.__thread_waiting_object: threading.Event = threading.Event()
        self.__component_status: ComponentStatus = ComponentStatus(self.name)
        self.__non_active_reason: Optional[str] = None

        self.__pause_thread: bool = False
        self.__wait_object_for_pause_run: threading.Event = threading.Event()
        self.__wait_object_for_pause_method: threading.Event = threading.Event()
        self.__wait_object_for_unpause_method: threading.Event = threading.Event()
        self.__thread_is_paused: bool = False

        self.__flush_to_persistence_system: bool = False
        self.__wait_object_for_flush_method: threading.Event = threading.Event()
        self.__thread_has_been_flushed: bool = False

        self.__stop_thread: bool = False
        self.__wait_object_for_stop_method: threading.Event = threading.Event()
        self.__thread_is_stopped: bool = False

        self.__running_flag: bool = True

        # Request the senders dependencies
        self.senders: SendersType = self._senders_constructor()
        self._create_senders(self._get_concurrent_connections())
        self._senders_monitor = self._senders_monitor_constructor()

        self.__emergency_persistence_system: EmergencyPersistenceSystem = EmergencyPersistenceSystem(self.name)

    @property
    def sender_manager_queue(self) -> SenderManagerQueue:
        return self._sender_manager_queue

    @property
    def non_active_reason(self) -> str:
        """

        :return:
        """
        return self.__non_active_reason

    @staticmethod
    def _validate_kwargs_for_method__init__(kwargs: Mapping[str, Any]):
        """Method that raises exceptions when the kwargs are invalid.

        :param kwargs:  -> group_name (str): Group name
                        -> instance_name (str): Name of the instance
                        -> configuration (dict): Dictionary with the configuration
                        -> generate_collector_details (bool) Defines if the collector details must be generated
        :raises: SdkSenderManagerAbstractError.
        :return:
        """
        error_msg = f"{__class__.__name__}::{inspect.stack()[0][3]} ->"

        # Validate group_name

        val_str = 'group_name'
        if val_str not in kwargs:
            raise SdkSenderManagerAbstractError(
                50,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, str):
            raise SdkSenderManagerAbstractError(
                51,
                f'{error_msg} The <{val_str}> must be an instance of <str> type not <{type(val_value)}>'
            )

        if len(val_value) < 1 or len(val_value) > 50:
            raise SdkSenderManagerAbstractError(
                52,
                f'{error_msg} The <{val_str}> length must be between 1 and 50 not <{len(val_value)}>'
            )

        # Validate instance_name

        val_str = 'instance_name'
        if val_str not in kwargs:
            raise SdkSenderManagerAbstractError(
                53,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, str):
            raise SdkSenderManagerAbstractError(
                54,
                f'{error_msg} The <{val_str}> must be an instance of <str> type not <{type(val_value)}>'
            )

        if len(val_value) < 1 or len(val_value) > 50:
            raise SdkSenderManagerAbstractError(
                55,
                f'{error_msg} The <{val_str}> length must be between 1 and 50 not <{len(val_value)}>'
            )

        # Validate configuration

        val_str = 'configuration'
        if val_str not in kwargs:
            raise SdkSenderManagerAbstractError(
                56,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, dict):
            raise SdkSenderManagerAbstractError(
                57,
                f'{error_msg} The <{val_str}> must be an instance of <dict> type not <{type(val_value)}>'
            )

        if len(val_value) == 0:
            raise SdkSenderManagerAbstractError(
                58,
                f'{error_msg} The <{val_str}> cannot be empty'
            )

        # Validate generate_collector_details

        val_str = 'generate_collector_details'
        if val_str in kwargs:
            val_value = kwargs[val_str]

            if not isinstance(val_value, bool):
                raise SdkSenderManagerAbstractError(
                    59,
                    f'{error_msg} The <{val_str}> must be an instance of <bool> type not <{type(val_value)}>'
                )

    def _get_concurrent_connections(self) -> int:
        """Abstract method that returns the number of concurrent connections that
        will be used by the __create_senders() method.

        :return:
        """
        to_return = 1
        # Return concurrent_connections if defined

        # TODO Commented for having only one sender
        # if 'self._concurrent_connections' in locals():
        #     to_return = self._concurrent_connections

        return to_return

    def _create_senders(self, number_of_sender_instances: int):
        """Method that creates the senders in the senders instance.

        :param number_of_sender_instances: Number of senders to be instantiated.
        :return:
        """

        # Create as many senders as indicated
        for sender_id in range(number_of_sender_instances):
            sender_instance_name = f"{self._build_sender_instance_name(sender_id)}"

            # Instantiate the sender
            self.senders.add_sender(
                self._sender_constructor(
                    self._sender_manager_queue,
                    sender_instance_name,
                    sender_manager_instance=self
                )
            )

    def add_output_object(self, queue_item: CollectorQueueItem) -> int:
        """Add a new output object to the sender manager queue

        :param queue_item:
        :return:
        """
        self._sender_manager_queue.put(queue_item)
        if self._generate_collector_details:
            return self.internal_queue_size()

    def _create_collector_details(self,
                                  final_sender_queue_size: int,
                                  sender: SenderType,
                                  start_time_local: datetime) -> None:
        """Method that creates the collector details when a new item is received.

        :param final_sender_queue_size: Actual number of items (size) in the queue.
        :param sender: Selected sender that will be used to send the queue item.
        :param start_time_local: Start time of the run() method.
        """

        if self._generate_collector_details and final_sender_queue_size:
            elapsed_seconds_adding_to_final_sender = (
                    datetime.utcnow() - start_time_local).total_seconds()
            if final_sender_queue_size > (sender.get_max_content_queue_size() * 0.9) and \
                    elapsed_seconds_adding_to_final_sender > 1:
                log.info(
                    f"elapsed_seconds_adding_to_final_sender: {elapsed_seconds_adding_to_final_sender:0.3f}, "
                    f"final_sender_queue_size: {final_sender_queue_size}, "
                    f"max_final_sender_queue_size: {sender.get_max_content_queue_size()}"
                )

    def internal_queue_size(self) -> int:
        """ Method that returns the size of the sender manager queue """
        return self._sender_manager_queue.sending_queue_size()

    def start(self) -> None:
        """Method that starts the thread execution

        :return:
        """

        self.senders.start_instances()
        self._senders_monitor.start()
        log.info(f"{self.name} -> Starting thread")
        super().start()

    def pause(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_execution_lock:

            log.info(f'{self.name} -> Pausing current thread (wait={wait})')

            if self.__thread_is_paused is True:
                log.info(f'Thread is already in pause status')
                return

            self.__non_active_reason = NonActiveReasons.PAUSE_COMMAND_RECEIVED
            self.__pause_thread = True

            if self.__thread_waiting_object.is_set() is False:
                self.__thread_waiting_object.set()

            if wait is True:

                if self.__wait_object_for_pause_method.is_set() is True:
                    self.__wait_object_for_pause_method.clear()

                while self.__thread_is_paused is False:

                    log.debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_pause_method.clear()

                log.info(f'{self.name} -> Thread has been paused after waiting (sync)')

            else:

                log.info(f'{self.name} -> Thread has been paused without waiting phase (async)')

    def __pause_dependencies(self) -> None:
        """

        :return:
        """

        log.info(f'{self.name} -> Pausing all dependent threads')

        self.senders.pause_instances()
        self._senders_monitor.pause()

        log.info(f'{self.name} -> All dependent threads have been paused')

    def unpause(self) -> None:
        """

        :return:
        """
        if self.__thread_is_paused is True:
            log.info(f'{self.name} -> Un-pausing')

            self.__non_active_reason = None
            self.__pause_thread = False

            if self.__wait_object_for_pause_run.is_set() is False:
                self.__wait_object_for_pause_run.set()

            while self.__thread_is_paused is True:

                log.debug(f'{self.name} -> Waiting to be un-paused')

                called: bool = self.__wait_object_for_unpause_method.wait(timeout=10)
                if called is True:
                    self.__wait_object_for_unpause_method.clear()

            log.debug(f'{self.name} -> Thread has been un-paused')

    def stop(self) -> None:
        """Method that stops the thread execution

        :return:
        """

        log.info(f'{self.name} -> Stopping thread')

        self.__non_active_reason = NonActiveReasons.STOP_COMMAND_RECEIVED
        self.__stop_thread = True

        if self.__wait_object_for_pause_run.is_set() is False:
            self.__wait_object_for_pause_run.set()

        if self.__thread_waiting_object.is_set() is False:
            self.__thread_waiting_object.set()

        if self.__wait_object_for_stop_method.is_set() is True:
            self.__wait_object_for_stop_method.clear()

        while self.__thread_is_stopped is False:

            log.debug(f'{self.name} -> Waiting to be stopped')

            called: bool = self.__wait_object_for_stop_method.wait(timeout=10)
            if called is True:
                self.__wait_object_for_stop_method.clear()

        log.info(f'{self.name} -> Thread has been stopped')

    def __stop_dependencies(self) -> None:
        """

        :return:
        """

        log.info(f'{self.name} -> Stopping all dependent threads')

        self._senders_monitor.stop()
        self.senders.stop_instances()

        log.info(f'{self.name} -> All dependent threads have been stopped')

    def wake_up(self):
        """Make the thread to exit from "main" waiting status

        :return:
        """

        if self.__thread_waiting_object.is_set() is False:
            self.__thread_waiting_object.set()

    def is_running(self) -> bool:
        """Method that returns the status of running_flag

        :return:
        """
        return self.__running_flag

    def is_paused(self) -> bool:
        """

        :return:
        """
        return self.__thread_is_paused

    def has_been_flushed(self) -> bool:
        """

        :return:
        """

        return self.__thread_has_been_flushed

    def run(self) -> None:
        """Method that contains the code that will be executed by the thread

        :return:
        """
        self.__component_status.status = StatusEnum.RUNNING

        while self.__running_flag:

            self.__wait_doing_nothing()

            self.__check_if_pause()

            self.__check_if_flush()

            self.__check_if_stop()

            if self.__running_flag is True:
                self.__check_senders_statuses()

        # If the following code only will be executed if the sender manager is dying
        self.__thread_is_stopped = True
        self.__component_status.status = StatusEnum.STOPPED

        if self.__wait_object_for_stop_method.is_set() is False:
            self.__wait_object_for_stop_method.set()

        log.info("Thread finalized")

    def __wait_doing_nothing(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is False \
                and self.__flush_to_persistence_system is False \
                and self.__stop_thread is False:

            log.debug("Entering in wait status (doing nothing)")
            called: bool = self.__thread_waiting_object.wait(timeout=60)
            if called is True:
                self.__thread_waiting_object.clear()
            log.debug("Waking up from wait status (doing nothing)")

    def __check_if_flush(self) -> None:
        """

        :return:
        """
        if self.__flush_to_persistence_system is True:

            log.info('Flushing thread')

            self.__flush_to_persistence_system = False

            start_time = datetime.utcnow()
            # self._sender_manager_queue.block_sending_queue()

            # while self._sender_manager_queue.is_closed_and_empty() is False:
            while self._sender_manager_queue.is_empty() is False:
                try:
                    queue_item: CollectorQueueItem = self._sender_manager_queue.get(timeout=5)
                    if queue_item:
                        self.__emergency_persistence_system.send(queue_item)
                    self._sender_manager_queue.task_done()
                except Empty:
                    log.debug(f'It seems that the queue is empty')

            self.__thread_has_been_flushed = True

            elapsed_time_in_seconds: float = (datetime.utcnow() - start_time).total_seconds()
            log.debug(
                f'[EMERGENCY PERSISTENCE SYSTEM] '
                f'{self.__emergency_persistence_system.output_component_name} '
                f'Persisted {self.__emergency_persistence_system.items_persisted} items '
                f'(elapsed_seconds: {elapsed_time_in_seconds:.3f})'
            )

            if self.__wait_object_for_flush_method.is_set() is False:
                self.__wait_object_for_flush_method.set()

            log.info(
                f'Thread has been totally flushed '
                f'({self.__emergency_persistence_system.items_persisted})'
            )

    def __check_if_pause(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is True:

            log.info('Pausing thread')

            self.__pause_dependencies()

            self.__thread_is_paused = True
            self.__pause_thread = False

            if self.__non_active_reason == NonActiveReasons.FINAL_SENDER_IS_NOT_WORKING:
                self.__component_status.status = StatusEnum.PAUSED_FAILING
                self._output_controller_communication_channel.send_notification(
                    CollectorNotification.create_final_sender_is_not_working_notification(
                        f'{self.name} is failing'
                    )
                )
                self._output_controller_process.wake_up()
            else:
                self.__component_status.status = StatusEnum.PAUSED

            log.info(
                f'SenderManager has been put in pause status, '
                f'reason: "{self.__non_active_reason}", '
                f'status: {self.__component_status.status}'
            )

            self.__wake_up_wait_object_for_pause_method()

            self.__wait_in_pause_status()

            self.__component_status.status = StatusEnum.RUNNING
            self.__thread_is_paused = False

            log.info("Thread has exited from pause status")

    def __wait_in_pause_status(self):
        """

        :return:
        """

        # Initialize the wait object to the default state
        if self.__wait_object_for_pause_run.is_set() is True:
            self.__wait_object_for_pause_run.clear()

        log.debug(f'Putting thread in pause status')
        called: bool = self.__wait_object_for_pause_run.wait()
        if called is True:
            self.__wait_object_for_pause_run.clear()

    def __check_if_stop(self) -> None:
        """

        :return:
        """

        if self.__stop_thread is True:
            self.__running_flag = False

            self.__stop_dependencies()
            self.__stop_thread = False

    def __check_senders_statuses(self):
        """

        :return:
        """

        self.__check_if_there_are_rejected_messages()

        pause_sender_manager: bool = False
        most_relevant_non_active_reason: Optional[str] = None
        for sender_instance in self.senders.get_senders():
            sender_instance: SenderAbstract
            non_active_reason = sender_instance.get_non_active_reason()
            if non_active_reason == NonActiveReasons.FINAL_SENDER_IS_NOT_WORKING:
                most_relevant_non_active_reason = non_active_reason
                pause_sender_manager = True
                break
            elif non_active_reason == NonActiveReasons.PAUSE_COMMAND_RECEIVED:
                most_relevant_non_active_reason = non_active_reason
                pause_sender_manager = True

        self.__non_active_reason = most_relevant_non_active_reason
        self.__pause_thread = pause_sender_manager

    def __check_if_there_are_rejected_messages(self):
        """

        :return:
        """

        active_instances: list[SenderAbstract] = self.senders.get_active_senders()
        all_messages_resent: bool = True
        secondary_sender: Optional[SenderAbstract] = None

        if active_instances:
            secondary_sender = active_instances[0]

        while self._sender_manager_queue.rejected_queue_size() > 0:
            try:
                rejected_queue_item: CollectorQueueItem = self._sender_manager_queue.get_rejected(block=False)
                if secondary_sender:
                    # TODO This should never be executed because it supposed that only exists one sender
                    secondary_sender.add_queue_item_to_final_sender(rejected_queue_item)
                else:
                    all_messages_resent = False
                    log.info(
                        f'No other sender is available, so pending content will be sent to '
                        f'the emergency persistence system'
                    )
                    self.__emergency_persistence_system.send(rejected_queue_item)

                # Mark rejected item as processed
                self._sender_manager_queue.rejected_task_done()

            except Empty:
                log.debug(f'It seems that the queue is empty')

        if all_messages_resent is False:
            for active_instance in active_instances:
                active_instance.pause()

    @abstractmethod
    def _server_configuration(self, server_configuration: dict):
        """Abstract method where the custom server configuration settings are extracted and stored.

        :param server_configuration: Dict from where the configuration settings are extracted
        :return:
        """
        pass

    @abstractmethod
    def _senders_constructor(self) -> SendersType:
        """Abstract where the senders' object is built.

        :return: An instance of ConsoleSenders, DevoSenders or SyslogSenders.
        """
        pass

    @abstractmethod
    def _senders_monitor_constructor(self) -> ManagerMonitorType:
        """Abstract method where the senders' monitor object is built.

        :return: An instance of ConsoleSenderManagerMonitor, DevoSenderManagerMonitor or SyslogSenderManagerMonitor.
        """
        pass

    @abstractmethod
    def _sender_constructor(self,
                            queue: SenderManagerQueue,
                            sender_name: str,
                            sender_manager_instance=None) -> SenderType:
        """Abstract method where the sender objects are built.

        :param sender_manager_instance: Sender Manager instance for waking up when errors.
        :param queue: QueueType that will be injected to the sender.
        :param sender_name: Name given to the sender instance.
        :return: An instance of ConsoleSender, DevoSender or SyslogSender.
        :rtype: SenderType
        :Example:

            return ConsoleSender(
                self.group_name,
                instance_name,
                self.destination,
                queue,
                self._generate_collector_details
            )
        """
        pass

    @abstractmethod
    def _build_sender_instance_name(self, sender_id: int) -> str:
        """Method that returns the base-name to be used by the senders.

        :param sender_id: Sender number or id. Example: 4
        :return: Base-name in string format. Example: 'console_sender_1'
        :Example:

            return f"my_sender_{sender_id}"
        """
        pass

    def flush_to_emergency_persistence_system(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_execution_lock:

            if self.__thread_is_paused is False:

                log.warning(f"{self.name} -> Is not in pause status, waiting first to be paused")
                log.debug(f'{self.name} -> Current object status:{str(self)}')

                while self.__thread_is_paused is False:

                    log.debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        log.debug(
                            f'flush_to_emergency_persistence_system::__wait_object_for_pause_method has been called'
                        )
                        self.__wait_object_for_pause_method.clear()

            log.info(f'{self.name} -> Enabling flushing mechanism (wait={wait})')

            self.__non_active_reason = NonActiveReasons.FLUSH_COMMAND_RECEIVED
            self.__flush_to_persistence_system = True

            self.__wake_up_wait_object_for_pause_method()

            if self.__wait_object_for_pause_run.is_set() is False:
                self.__wait_object_for_pause_run.set()

            if self.__thread_waiting_object.is_set() is False:
                self.__thread_waiting_object.set()

            log.debug(f'{self.name} -> Starting to flush the queue')

            if wait is True:

                if self.__wait_object_for_flush_method.is_set() is True:
                    self.__wait_object_for_flush_method.clear()

                while self.__thread_has_been_flushed is False:

                    log.debug(f'{self.name} -> Waiting to be flushed')

                    called: bool = self.__wait_object_for_flush_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_flush_method.clear()

                log.info(f'{self.name} -> Thread has been flushed (sync)')

            else:

                log.debug(f'{self.name} -> Thread has been put in flushing mode without waiting phase (async)')

    def __wake_up_wait_object_for_pause_method(self):
        """

        :return:
        """

        if self.__wait_object_for_pause_method.is_set() is False:
            self.__wait_object_for_pause_method.set()

    def __str__(self):
        """ Method that returns a str representation of the class """

        return json.dumps(self.get_summary_status())

    def get_summary_status(self) -> dict:
        status: dict = {
            "name": self.name,
            "status": str(self.__component_status.status),
            "non_active_reason": self.__non_active_reason,
            "is_pausing": self.__pause_thread,
            "is_paused": self.__thread_is_paused,
            "is_flushing": self.__flush_to_persistence_system,
            "is_flushed": self.__thread_has_been_flushed,
            "is_stopping": self.__stop_thread,
            "is_stopped": self.__thread_is_stopped,
            "internal_queue_size": self.internal_queue_size(),
            "senders": self.senders.get_summary_status(),
        }
        return status
