# -*- coding: utf-8 -*-
"""
Main module for the collector, contains the "entrypoint" method (main())
"""
import copy
import json
import logging
import os
import platform
import signal
import sys
import threading
import types
from datetime import datetime
from pathlib import Path
from typing import Union

import click as click

from devocollectorsdk.collector_thread import CollectorThread
from devocollectorsdk.collectordefinitions.collector_definitions import CollectorDefinitions
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.constants import Constants
from devocollectorsdk.commons.obfuscation_utils import ObfuscationUtils
from devocollectorsdk.configuration.configuration import CollectorConfiguration, CollectorConfigurationException
from devocollectorsdk.logging_handlers.logging_setup import setup_logging_with_basic_configuration
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue

APPNAME = 'devo-collector-base'
FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S.%f'
FLAG_FORMAT = "YYYY-MM-DD HH:MM:SS.nnnnnnnnn"
FLAG_REGEX = r"[0-9]{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2][0-9]|3[0-1]) " \
             r"(?:2[0-3]|[01][0-9]):[0-5][0-9](?::[0-5][0-9])?(?:\.\d{1,9})?"

# Global definitions
log = logging.getLogger(__name__)

exit_code: int = -1


def add_system_signal_management(internal_queue: CollectorMultiprocessingQueue = None):

    if internal_queue is None:
        raise Exception(f'The "internal_queue" parameter is mandatory')

    def sigterm_handler(signal_number: int, stack_frame: types.FrameType):
        signal_name = signal.strsignal(signal_number)
        local_items = stack_frame.f_locals
        running_object = local_items.get("self")

        if isinstance(running_object, CollectorThread) is False:
            log.debug(f'Received the "{signal_name}" system signal, it will be ignored due to I\'m a secondary process')
            return

        if log.isEnabledFor(logging.WARNING):
            log_message = \
                f'Received the "{signal_name}" system signal (code: {signal_number}), ' \
                f'all the processes will be gracefully stopped'
            log.warning(log_message)
            send_internal_collector_message(internal_queue, log_message, level="warning")

        if signal_number == 2:
            global exit_code
            exit_code = 0

        running_object.graceful_shutdown()

    signal.signal(signal.SIGTERM, sigterm_handler)
    signal.signal(signal.SIGINT, sigterm_handler)


def send_internal_collector_message(internal_queue: CollectorMultiprocessingQueue,
                                    message_content: Union[str, dict],
                                    level: str = None,
                                    shared_domain: bool = False):
    """
    This function add a new message to the internal collector.
    :param internal_queue: transport message queue
    :param message_content: Message to be sent to Devo.
    :param level: Severity of the message.
    :param shared_domain: True if the message has <shared_domain> property to be watched by IF Devo Team for monitoring
        purposes.
    """

    CollectorUtils.send_internal_collector_message(
        internal_queue,
        message_content,
        level=level,
        shared_domain=shared_domain
    )


def wait_until_all_threads_are_stopped() -> None:
    """

    :return:
    """

    wait_object: threading.Event = threading.Event()
    still_threads_alive = True
    while still_threads_alive:
        alive_thread_names = []
        debug_thread_names = []
        debug_threads = []
        for t in threading.enumerate():
            if t.is_alive() and t.name.startswith("pydevd") is False and t.name != "MainThread":
                alive_thread_names.append(t.name)
            if t.is_alive() and t.name.startswith("pydevd"):
                debug_thread_names.append(t.name)
                debug_threads.append(t)

        if debug_threads:
            log.warning(
                f'There are some alive threads because of the execution in debugging mode: '
                f'{json.dumps(debug_thread_names)}, '
                f'waiting until all of them will be finished'
            )

        if alive_thread_names:
            log.warning(
                f'There are some alive threads: {json.dumps(alive_thread_names)}, '
                f'waiting until all of them will be finished'
            )
            called: bool = wait_object.wait(timeout=1)
            if called is True:
                wait_object.clear()
        else:
            still_threads_alive = False


def show_devo_banner() -> None:
    """Show the Devo Marketing banner"""
    print(Constants.BANNER_4, flush=True)
    sys.stdout.flush()


def add_required_directories_to_python_path() -> None:
    """Add all required directories to python path

    Adds "config_internal" and current directories to the Python path,
    this is required for being able to load "external" classes/resources dynamically
    """

    current_dir_absolute = os.getcwd()
    sys.path.append(current_dir_absolute)
    log.info(f'Added "{current_dir_absolute}" directory to the Python path')

    config_internal_dir: str = "config_internal"
    config_internal_dir_absolute: str = os.path.join(current_dir_absolute, config_internal_dir)
    sys.path.append(config_internal_dir_absolute)
    log.info(f'Added "{config_internal_dir_absolute}" directory to the Python path')

    schemas_dir: str = "schemas"
    schemas_dir_absolute: str = os.path.join(current_dir_absolute, schemas_dir)
    sys.path.append(schemas_dir_absolute)
    log.info(f'Added "{schemas_dir_absolute}" directory to the Python path')


def show_execution_environment(production_mode: bool, execute_only_setup_and_exit: bool) -> None:
    """Show some properties about the runtime environment

    :param production_mode: True if the production mode is enabled. False if not.
    :param execute_only_setup_and_exit:
    """
    current_dir = os.getcwd()
    directories_in_current_location = \
        [dir_item for dir_item in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, dir_item))]
    exists_certs_dir = True if 'certs' in directories_in_current_location else False
    exists_config_dir = True if 'config' in directories_in_current_location else False
    exists_config_internal_dir = True if 'config_internal' in directories_in_current_location else False
    exists_schemas_dir = True if 'schemas' in directories_in_current_location else False
    exists_credentials_dir = True if 'credentials' in directories_in_current_location else False
    python_version = sys.version.replace("\n", "")

    environment_status = \
        f'Production mode: {production_mode}, ' \
        f'execute only setup and exit: {execute_only_setup_and_exit}, ' \
        f'Python version: "{python_version}", ' \
        f'current dir: "{current_dir}", ' \
        f'exists "config" dir: {exists_config_dir}, ' \
        f'exists "config_internal" dir: {exists_config_internal_dir}, ' \
        f'exists "certs" dir: {exists_certs_dir}, ' \
        f'exists "schemas" dir: {exists_schemas_dir}, ' \
        f'exists "credentials" dir: {exists_credentials_dir}'

    log.info(environment_status)


@click.command()
@click.option(
    '--config',
    'config_full_filename',
    help='Path to full structured configuration file (with sections "globals", "inputs" and "outputs" inside)'
)
@click.option(
    '--job_config_loc',
    'config_inputs_filename',
    help='Path to collector "local" configuration file for being used with the Collector Server'
)
@click.option(
    '--collector_config_loc',
    'config_global_filename',
    help='Path to collector "internal" configuration file for being used with the Collector Server'
)
@click.option(
    '--no-save-state',
    default=False,
    is_flag=True,
    help='Do not persist the state (use only memory)'
)
@click.option(
    '--prod-mode',
    default=False,
    is_flag=True,
    help='Forces not to be in the development mode'
)
@click.option(
    '--validate',
    'execute_only_setup_and_exit',
    default=False,
    is_flag=True,
    help='Forces to execute only the credential checking'
)
def main(config_inputs_filename: str,
         config_global_filename: str,
         config_full_filename: str,
         no_save_state: bool,
         prod_mode: bool,
         execute_only_setup_and_exit: bool) -> None:
    """

    :param config_inputs_filename:
    :param config_global_filename:
    :param config_full_filename:
    :param no_save_state:
    :param prod_mode:
    :param execute_only_setup_and_exit:
    :return:
    """

    # Shows Devo collector banner (only in the local console)
    show_devo_banner()

    try:

        # Initializes logging system with default format/level
        setup_logging_with_basic_configuration()

        # Adds the current directory to the Python path, necessary for being able to load "external" modules/classes
        add_required_directories_to_python_path()

        # Shows execution environment
        show_execution_environment(prod_mode, execute_only_setup_and_exit)

        collector_definitions: CollectorDefinitions = CollectorDefinitions()

        # Create configuration object
        config: CollectorConfiguration = CollectorConfiguration(
            config_full_filename,
            config_inputs_filename,
            config_global_filename,
            no_save_state
        )
        debug_enabled: bool = config.get_globals().get("debug", False)
        if debug_enabled is True:
            logging.getLogger().setLevel(logging.DEBUG)
        CollectorUtils.set_collector_metadata_from_config(config)

        # Build the internal queues <output and lookup> arguments and builders

        standard_queue = create_standard_queue(config)

        lookup_queue = create_lookup_queue(config)

        internal_queue = create_internal_queue(config)

        build_time_file = Path("build_time.txt")
        build_time: str = "UNKNOWN"
        if build_time_file.is_file():
            try:
                with open("build_time.txt", "r") as build_time_file:
                    build_time = build_time_file.read().splitlines()[-1]
            except Exception as ex:
                log.warning(f'Problems reading "build_time.txt" file: {str(ex)}')

        now_utc = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        if log.isEnabledFor(logging.INFO):
            log_message = \
                f'Build time: "{build_time}", ' \
                f'OS: "{platform.platform()}", ' \
                f'collector(name:version): "{CollectorUtils.collector_name}:{CollectorUtils.collector_version}", ' \
                f'owner: "{CollectorUtils.collector_owner}", ' \
                f'started at: "{now_utc}"'
            log.info(log_message)
            send_internal_collector_message(internal_queue, log_message, level="info", shared_domain=True)

        # Say <hello world!>
        log.debug(standard_queue)
        log.debug(lookup_queue)
        log.debug(internal_queue)

        obfuscation_config: dict = collector_definitions.get_obfuscation_keys()
        config_copy_str: str = str(copy.deepcopy(config))

        for input_name, value in obfuscation_config.items():

            if input_name not in config.get_inputs():
                continue

            if not value.get('key_value_entries'):
                log.debug(
                    "No 'key_value_entries' provided into 'config_obfuscation' section. "
                    "Asumed tha obfuscation is not needed"
                )
                continue

            config_copy_str = ObfuscationUtils.process_json(
                    config_copy_str,
                    value['key_value_entries'],
                    custom_mask_values=value.get('mask_values'),
                    check_types=False,
                    as_str=True
            )

        log.debug(f'Configuration content: {config_copy_str}')

        # Instantiate the collector instance
        collector: CollectorThread = \
            CollectorThread(
                config=config,
                definitions=collector_definitions,
                standard_queue=standard_queue,
                lookup_queue=lookup_queue,
                internal_queue=internal_queue,
                production_mode=prod_mode,
                execute_only_setup_and_exit=execute_only_setup_and_exit
            )

        add_system_signal_management(internal_queue=internal_queue)

        log.info(f'Initialized all object from "MainProcess" process')

        collector.start()

        log.info(f'Started all object from "MainProcess" process')

        collector.join()

        # Log trace
        now_utc = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        log.info('Finalizing the whole collector')

        log_message = \
            {
                "collector_name": CollectorUtils.collector_name,
                "collector_version": CollectorUtils.collector_version,
                "collector_owner": CollectorUtils.collector_owner,
                "stopped_at": now_utc
            }
        log.info(json.dumps(log_message))

        wait_until_all_threads_are_stopped()

        exit_message: str = f'[EXIT] Process "MainProcess" completely terminated'

        shutdown_datetime_start = collector.shutdown_datetime_start
        if shutdown_datetime_start:
            elapsed_time_in_seconds: float = (datetime.utcnow()-shutdown_datetime_start).total_seconds()
            exit_message += f' (elapsed time since the system signal was received: {elapsed_time_in_seconds:.3f}s)'

        log.info(exit_message)

    except CollectorConfigurationException as ex:
        log.error(ex)
        sys.exit(-1)

    sys.exit(exit_code)


def create_internal_queue(config):
    """Build internal queue

    :param config:
    :return:
    """

    queue_arguments: dict = config.get_queue_building_standard_arguments()
    queue_arguments['queue_name'] = 'internal_queue'
    queue_arguments['unlimited_privileges'] = False
    queue_arguments["max_size_in_messages"] = 10000
    queue_arguments["max_wrap_size_in_messages"] = 100
    internal_queue = CollectorMultiprocessingQueue(**queue_arguments)
    internal_queue.cancel_join_thread()
    return internal_queue


def create_lookup_queue(config):
    """Build lookup queue

    :param config:
    :return:
    """

    queue_arguments: dict = config.get_queue_building_standard_arguments()
    queue_arguments['queue_name'] = 'lookup_queue'
    queue_arguments['unlimited_privileges'] = True
    lookup_queue = CollectorMultiprocessingQueue(**queue_arguments)
    lookup_queue.cancel_join_thread()
    return lookup_queue


def create_standard_queue(config):
    """Build standard queue

    :param config:
    :return:
    """

    queue_arguments: dict = config.get_queue_building_standard_arguments()
    queue_arguments['queue_name'] = 'standard_queue'
    standard_queue = CollectorMultiprocessingQueue(**queue_arguments)
    standard_queue.cancel_join_thread()
    return standard_queue


if __name__ == "__main__":
    main()
