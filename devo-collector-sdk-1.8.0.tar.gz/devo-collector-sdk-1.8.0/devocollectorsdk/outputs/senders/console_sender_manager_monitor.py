from devocollectorsdk.outputs.senders.abstracts.sender_manager_monitor_abstract import SenderManagerMonitorAbstract


class ConsoleSenderManagerMonitor(SenderManagerMonitorAbstract):
    """ Monitor for Console Sender Monitor """

    def custom_hook_01(self):
        """ Method not required for this class """
        pass
