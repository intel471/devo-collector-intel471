import logging
import threading
from threading import Thread

from devocollectorsdk.commons.collector_exceptions import SdkInputThreadError
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.object_statuses import ObjectStatuses
from devocollectorsdk.inputs.service_thread import ServiceThread
from devocollectorsdk.persistence.persistence_factory_manager import PersistenceFactoryManager
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.ratelimiter.collector_rate_limiter_list import CollectorRateLimiterList

log = logging.getLogger(__name__)


class InputThread(Thread):
    """There will be one instance of this thread per each input enabled from the configuration file"""

    def __init__(self,
                 parent_thread,
                 definitions_globals: dict,
                 production_mode: bool,
                 execute_only_setup_and_exit: bool,
                 input_id: str,
                 input_name: str,
                 input_config: dict,
                 input_definition: dict,
                 output_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 internal_queue: CollectorMultiprocessingQueue,
                 persistence_factory_manager: PersistenceFactoryManager,
                 rate_limiters_from_controller: CollectorRateLimiterList) -> None:
        """

        :param parent_thread:
        :param definitions_globals:
        :param production_mode:
        :param execute_only_setup_and_exit:
        :param input_id:
        :param input_name:
        :param input_config:
        :param input_definition:
        :param output_queue:
        :param lookup_queue:
        :param internal_queue:
        :param persistence_factory_manager:
        """
        super().__init__()

        self.name = \
            self.__class__.__name__ + f'({input_name},{input_id})'

        self.__object_status = ObjectStatuses.INITIALIZING

        # Load main properties
        self.parent_thread = parent_thread
        self.__definitions_globals: dict = definitions_globals
        self.__production_mode: bool = production_mode
        self.__execute_only_setup_and_exit: bool = execute_only_setup_and_exit
        self.input_id: str = input_id
        self.input_name: str = input_name
        self.input_config: dict = input_config
        self.input_definition: dict = input_definition

        self.__output_queue: CollectorMultiprocessingQueue = output_queue
        self.__lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.__internal_queue: CollectorMultiprocessingQueue = internal_queue

        self.__rate_limiters: CollectorRateLimiterList = \
            CollectorRateLimiterList(rate_limiters_from_controller.rate_limiters)

        self.input_thread_execution_periods_in_seconds: int = 600

        self.requests_limits: list = input_config.get('requests_limits')

        self.input_thread_globals = input_definition.get("input_thread_globals")

        if self.input_thread_globals:
            self.input_thread_globals_requests_limits = self.input_thread_globals.get("requests_limits")

            if not self.requests_limits and self.input_thread_globals_requests_limits:
                self.requests_limits = self.input_thread_globals_requests_limits

            self.input_thread_execution_periods_in_seconds = \
                self.input_thread_globals.get("input_thread_execution_periods_in_seconds")

        self.__rate_limiters.add_rate_limiters_from_list(self.requests_limits)

        self.persistence_factory_manager = persistence_factory_manager

        # Variables related to run/pause/stop statuses
        self.__command_execution_lock: threading.Lock = threading.Lock()

        self.__thread_wait_object: threading.Event = threading.Event()

        self.__stop_thread: bool = False
        self.__wait_object_for_stop_method: threading.Event = threading.Event()
        self.__thread_is_stopped: bool = False

        self.__pause_thread: bool = False
        self.__wait_object_for_pause_run: threading.Event = threading.Event()
        self.__wait_object_for_pause_method: threading.Event = threading.Event()
        self.__thread_is_paused: bool = False

        self.service_threads: dict = {}
        self.initial_running_flag_state: bool = self.__create_service_threads()
        self.__running_flag: bool = True if self.initial_running_flag_state is True else False

        self.__object_status = ObjectStatuses.INITIALIZED

    def __create_service_threads(self) -> bool:
        """Create all service threads

        :return:
        """

        services_available = 0
        services_config = self.input_config.get("services")

        if services_config is None:
            raise SdkInputThreadError(
                50,
                f'{self.name} - At least one service must be defined in the configuration file')

        # Create the services
        for service_name, service_config in services_config.items():
            service_definition = self._get_service_definition(service_name)
            service_globals = self.input_definition.get("globals")

            if service_definition is None or len(service_definition) == 0:
                raise SdkInputThreadError(
                    51,
                    f'{self.name} - No service definitions found for service name: {service_name}'
                )

            service_type = service_definition.get("type")
            if service_type is None:
                raise SdkInputThreadError(
                    51,
                    f'{self.name} - <type> property in service definition is missing'
                )

            service_thread = ServiceThread(
                self,
                self.__definitions_globals,
                self.__production_mode,
                self.__execute_only_setup_and_exit,
                self.input_id,
                self.input_name,
                self.input_config,
                self.input_definition,
                self.__thread_wait_object,
                service_name,
                service_type,
                service_config,
                service_definition,
                service_globals,
                self.persistence_factory_manager,
                self.__output_queue,
                self.__lookup_queue,
                self.__internal_queue,
                self.__rate_limiters
            )

            self.log_debug(f'{self.name} -> {service_thread.name} - Instance created')

            self.service_threads[service_thread.name] = service_thread
            services_available += 1

        if services_available > 0:
            return True
        return False

    def wake_up(self) -> None:
        """Wakeup action

        :return:
        """

        if self.__thread_wait_object.is_set() is False:
            self.__thread_wait_object.set()

    def run(self) -> None:
        """Running section of the thread

        :return:
        """

        self.__object_status = ObjectStatuses.RUNNING

        while self.__running_flag:

            if self.__pause_thread is False \
                    and self.__stop_thread is False:

                self.log_debug("Entering in wait status")

                called: bool = self.__thread_wait_object.wait(
                    timeout=self.input_thread_execution_periods_in_seconds
                )
                if called is True:
                    self.__thread_wait_object.clear()

                self.log_debug("Waking up from wait status")

            self.__check_if_pause()

            self.__check_if_stop()

            # Detect broken threads
            self.__update_services_status()

            if self._no_running_threads():
                self.__running_flag = False

        self.log_info("Finalizing thread")

        self.__thread_is_stopped = True
        if self.__wait_object_for_stop_method.is_set() is False:
            self.__wait_object_for_stop_method.set()

    def __check_if_pause(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is True:

            self.log_warning(f'Thread has been put in pause status')

            self.__thread_is_paused = True
            self.__pause_thread = False

            if self.__wait_object_for_pause_method.is_set() is False:
                self.__wait_object_for_pause_method.set()

            called: bool = self.__wait_object_for_pause_run.wait()
            if called is True:
                self.__wait_object_for_pause_run.clear()

            self.__thread_is_paused = False

            self.log_info("Thread has exited from pause status")

    def __check_if_stop(self) -> None:
        """

        :return:
        """

        if self.__stop_thread is True:
            self.__running_flag = False

    def start(self) -> None:
        """Start the thread

        :return:
        """

        self.log_info(
            f'{self.name} - Starting thread (execution_period={self.input_thread_execution_periods_in_seconds}s)'
        )
        # Start all child threads
        if len(self.service_threads) > 0:
            for service_thread in self.service_threads.values():
                service_thread.start()
        super().start()

    def pause(self, wait: bool = None) -> None:
        """

        :param wait:
        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_execution_lock:

            if self.__object_status != ObjectStatuses.RUNNING \
                    and self.__object_status != ObjectStatuses.PAUSING:
                self.log_warning(
                    f'{self.name} -> Current thread is in a incompatible status for "pause" command'
                )
                return

            if self.__object_status == ObjectStatuses.PAUSED:
                self.log_info(
                    f'{self.name} -> Current thread was already in pause status'
                )
                return

            self.__object_status = ObjectStatuses.PAUSING

            self.log_info(f'{self.name} -> Pausing current thread (wait={wait})')

            # self.pause_dependencies(wait)

            self.__pause_thread = True

            if self.__thread_wait_object.is_set() is False:
                self.__thread_wait_object.set()

            if self.__wait_object_for_pause_method.is_set() is True:
                self.__wait_object_for_pause_method.clear()

            if wait is True:

                while self.__thread_is_paused is False:

                    self.log_debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_pause_method.clear()

                self.__object_status = ObjectStatuses.PAUSED

                self.log_info(f'{self.name} -> Thread has been paused after waiting (sync)')

            else:

                self.log_debug(f'{self.name} -> Thread has been paused without waiting phase (async)')

    def pause_services(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        self.log_info(f'{self.name} -> Pausing all service threads (wait={wait})')

        if len(self.service_threads) > 0:
            for service_thread in self.service_threads.values():
                service_thread: ServiceThread
                service_thread.pause(wait)

        self.log_info(f'{self.name} -> All service threads have been paused (wait={wait})')

    def pause_modules(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        self.log_info(f'{self.name} -> Pausing all module threads (wait={wait})')

        if len(self.service_threads) > 0:
            for service_thread in self.service_threads.values():
                service_thread: ServiceThread
                service_thread.pause_modules(wait)

        self.log_info(f'{self.name} -> All module threads have been paused (wait={wait})')

    def stop(self) -> None:
        """

        :return:
        """

        with self.__command_execution_lock:

            if self.__thread_is_paused is False:
                print(f"{self.name} -> Is not in pause status")

            self.log_info(f'{self.name} -> Stopping thread')

            self.__stop_thread = True

            self.__stop_dependencies()

            if self.__thread_wait_object.is_set() is False:
                self.__thread_wait_object.set()

            if self.__wait_object_for_pause_run.is_set() is False:
                self.__wait_object_for_pause_run.set()

            if self.__wait_object_for_stop_method.is_set() is True:
                self.__wait_object_for_stop_method.clear()

            while self.__thread_is_stopped is False:

                log.debug(f'{self.name} -> Waiting to be stopped')

                called: bool = self.__wait_object_for_stop_method.wait(timeout=10)
                if called is True:
                    self.__wait_object_for_stop_method.clear()

            self.log_info(f'{self.name} -> Thread has been stopped')

    def __stop_dependencies(self) -> None:
        """

        :return:
        """

        self.log_info(f'{self.name} -> Stopping all dependent threads')

        if len(self.service_threads) > 0:
            for service_thread in self.service_threads.values():
                if isinstance(service_thread, ServiceThread):
                    service_thread.stop()

        self.log_info(f'{self.name} -> All dependent threads have been stopped')

    def __update_services_status(self) -> None:
        """Update the REMOVED status of the current service threads

        :return:
        """

        # Detect dead threads
        service_threads_to_remove: list = []
        for service_thread_name, service_thread in self.service_threads.items():
            if isinstance(service_thread, str) is False and service_thread.is_alive() is False:
                service_threads_to_remove.append(service_thread_name)

        # Set all dead threads as REMOVED
        if len(service_threads_to_remove) > 0:
            for service_thread_name in service_threads_to_remove:
                internal_service_thread_name = self.service_threads[service_thread_name].getName()
                self.service_threads[service_thread_name] = "REMOVED"

                self.log_info(f'Removed finalized thread: {internal_service_thread_name}')

    def _no_running_threads(self) -> bool:
        """Check if all thread have been removed.

        :return: True if all threads have been removed. False if not.
        """
        # Get references
        number_of_setup_service_threads = len(self.service_threads)
        number_of_removed_threads = 0

        # Count how many threads have been removed
        for setup_service_threads in self.service_threads.values():
            if setup_service_threads == "REMOVED":
                number_of_removed_threads += 1

        # Check if all threads have been removed
        if number_of_setup_service_threads == number_of_removed_threads:
            return True
        else:
            self.log_debug(
                "Still running {} of {} service threads: {}".format(
                    number_of_setup_service_threads - number_of_removed_threads,
                    number_of_setup_service_threads,
                    [*self.service_threads.keys()]
                )
            )
            return False

    def _get_service_definition(self, service_name: str) -> dict:
        """Return the service definition

        :param service_name: Name of the service
        :return: A dict instance with the service definition
        """
        services: dict = self.input_definition.get("services")
        if service_name in services and services[service_name]["type"] == "predefined":
            return services[service_name]
        else:
            if "custom_service" in services:
                return services["custom_service"]

    def send_internal_collector_message(self,
                                        message_content,
                                        level: str = None,
                                        shared_domain: bool = False) -> None:
        """

        :param message_content:
        :param level:
        :param shared_domain:
        :return:
        """

        CollectorUtils.send_internal_collector_message(
            self.__internal_queue,
            message_content,
            input_name=self.input_name,
            level=level,
            shared_domain=shared_domain
        )

    def log_error(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.ERROR):
            log.error(message)
            self.send_internal_collector_message(message, level="error")

    def log_warning(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.WARNING):
            log.warning(message)
            self.send_internal_collector_message(message, level="warning")

    def log_info(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.INFO):
            log.info(message)
            self.send_internal_collector_message(message, level="info")

    def log_debug(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.DEBUG):
            log.debug(message)
            self.send_internal_collector_message(message, level="debug")

    def get_summary_status(self) -> list:
        status: list = []
        return status
