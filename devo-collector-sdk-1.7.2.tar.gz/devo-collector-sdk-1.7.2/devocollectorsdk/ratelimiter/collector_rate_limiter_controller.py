import logging

from devocollectorsdk.ratelimiter.collector_rate_limiter import CollectorRateLimiter

log = logging.getLogger(__name__)


class CollectorRateLimiterController:

    def __init__(self, rate_limiters):
        self.__rate_limiters: dict[int, CollectorRateLimiter] = rate_limiters

    def __enter__(self):
        for rate_limiter in self.__rate_limiters.values():
            rate_limiter.__enter__()

    def __exit__(self, exc_type, exc_val, exc_tb):
        for rate_limiter in self.__rate_limiters.values():
            rate_limiter.__exit__(exc_type, exc_val, exc_tb)

    @property
    def rate_limiters(self):
        return self.__rate_limiters
