""" Module that contains all used exceptions """

SDK_UNCATEGORIZED_ERROR: int = 1

SDK_DEFINITIONS_INITIALIZATION_ERROR: int = 2

SDK_CONFIGURATION_ERROR: int = 3
SDK_CONFIGURATION_FILE_ERROR: int = 4

SDK_COLLECTOR_UTILS_ERROR: int = 5

SDK_DEVO_LOGGER_ERROR: int = 6

SDK_DEVO_OBFUSCATION_ERROR: int = 7

SDK_INPUT_INIT_ERROR: int = 20
SDK_INPUT_RUNNING_ERROR: int = 22
SDK_INPUT_THREAD_ERROR: int = 24

SDK_SERVICE_INIT_ERROR: int = 30
SDK_SERVICE_RUNNING_ERROR: int = 32
SDK_SERVICE_THREAD_ERROR: int = 34

SDK_MODULE_INIT_ERROR: int = 40
SDK_MODULE_RUNNING_ERROR: int = 42
SDK_MODULE_THREAD_ERROR: int = 44

SDK_PULLER_ABSTRACT_ERROR: int = 50
SDK_PULLER_SETUP_ABSTRACT_ERROR: int = 55

SDK_LISTENER_ABSTRACT_ERROR: int = 60
SDK_LISTENER_SETUP_ABSTRACT_ERROR: int = 65

SDK_PULL_STATISTICS_ERROR: int = 70

SDK_PERSISTENCE_FACTORY_ERROR: int = 80
SDK_PERSISTENCE_SERVICE_ERROR: int = 82
SDK_PERSISTENCE_CONFIG_ERROR: int = 84
SDK_PERSISTENCE_INTERFACE_ERROR: int = 86

SDK_LOOKUP_FACTORY_ERROR: int = 38

SDK_OUTPUT_INIT_ERROR: int = 60
SDK_OUTPUT_RUNNING_ERROR: int = 61
SDK_LOOKUP_SERVICE_ERROR: int = 62
SDK_SENDER_MANAGER_ABSTRACT_ERROR: int = 63
SDK_SENDER_MANAGER_MONITOR_ABSTRACT_ERROR: int = 64
SDK_SENDER_ABSTRACT_ERROR: int = 65
SDK_SENDERS_ABSTRACT_ERROR: int = 66
SDK_SYSLOG_SENDER_MANAGER_ERROR: int = 67
SDK_SYSLOG_SENDER_ERROR: int = 68
SDK_CONSOLE_SENDER_MANAGER_ERROR: int = 69
SDK_CONSOLE_SENDER_ERROR: int = 70
SDK_DEVO_SENDER_MANAGER_ERROR: int = 71
SDK_DEVO_SENDER_ERROR: int = 72

PULLER_INIT_VAR_ERROR: int = 90
PULLER_SETUP_ERROR: int = 91
PULLER_PRE_PULL_ERROR: int = 92
PULLER_PULL_ERROR: int = 93

CUSTOM_ERRORS_RANGE: [int] = [94, 99]


class CollectorBaseException(Exception):

    def __init__(self, code: int, sub_code: int, cause: str, cause_title: str = None) -> None:
        self.exception_class_name = self.__class__.__name__
        self.code: int = code
        self.sub_code: int = sub_code
        self.cause_title: str = cause_title
        self.cause: str = cause
        if type(self) == CollectorBaseException:
            raise TypeError("<CollectorBaseException> class may not be instantiated")

    # def __new__(cls, code: int, sub_code: int, cause: str):
    #     if cls is CollectorBaseException:
    #         raise TypeError("CollectorBaseException class may not be instantiated")
    #     return super().__new__(cls, code, sub_code, cause)

    def __str__(self) -> str:
        return \
            f'{self.exception_class_name}' \
            f'[CODE:{self.code:04d}-{self.sub_code:02d}] ' \
            f'{self.cause_title}: {self.cause}'


class BaseModelError(Exception):
    """ Used as Base Model for other exceptions """

    def __init__(self, code: int, sub_code: int, cause: str, cause_title: str = None) -> None:
        """
        Build the Model.
        :param code: Error Code, for identifying the service.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        :param cause_title: Error tittle.
        """
        self.exception_class_name = self.__class__.__name__
        self.code: int = code
        self.sub_code: int = sub_code
        self.cause_title: str = cause_title
        self.cause: str = cause
        if type(self) == BaseModelError:
            raise TypeError("<CollectorBaseException> class may not be instantiated")

        official_exceptions = [
            SdkUncategorizedError,

            SdkConfigurationError,
            SdkConfigurationFileError,
            SdkDefinitionsInitializationError,
            SdkCollectorUtilsError,
            SdkDevoLoggerError,

            SdkInputInitializationError,
            SdkInputRunningError,
            SdkInputThreadError,

            SdkServiceInitializationError,
            SdkServiceRunningError,

            SdkPersistenceFactoryError,
            SdkPersistenceServiceError,
            SdkPersistenceConfigurationError,
            SdkPersistenceInterfaceError,

            SdkLookupFactoryError,
            SdkPullerAbstractError,
            SdkPullStatisticsError,
            SdkPullerSetupAbstractError,

            SdkOutputInitializationError,
            SdkOutputRunningError,
            SdkLookupServiceError,
            SdkSenderManagerAbstractError,
            SdkSenderManagerMonitorAbstractError,
            SdkSenderAbstractError,
            SdkSendersAbstractError,
            SdkSyslogSenderManagerError,
            SdkSyslogSenderError,
            SdkConsoleSenderManagerError,
            SdkConsoleSenderError,
            SdkDevoSenderManagerError,
            SdkDevoSenderError,

            PullerInitVariablesError,
            PullerSetupError,
            PullerPrePullError,
            PullerPullError,

            SdkManagementProcessInitializationError,

            SdkObfuscationError,
        ]

        if type(self) not in official_exceptions \
                and (code < CUSTOM_ERRORS_RANGE[0] or code > CUSTOM_ERRORS_RANGE[1]):
            raise SdkUncategorizedError(
                sub_code=1,
                cause=f'Used code <{code}> by the Custom Exception {type(self)} is out of the valid range '
                      f'<{CUSTOM_ERRORS_RANGE[0]} to {CUSTOM_ERRORS_RANGE[1]}>'
            )

    def __str__(self) -> str:
        return \
            f'{self.exception_class_name}' \
            f'[CODE:{self.code:02d}-{self.sub_code:04d}] ' \
            f'{self.cause_title}: {self.cause}'


# SDK Exceptions
class SdkUncategorizedError(BaseModelError):
    """ Used by SDK main phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed by an uncategorized exception"
        super().__init__(code=SDK_UNCATEGORIZED_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkConfigurationError(BaseModelError):
    """ Used by CollectorConfiguration class """

    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed loading the initial configuration"
        super().__init__(code=SDK_CONFIGURATION_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkConfigurationFileError(BaseModelError):
    """ Used by CollectorConfiguration class when the configuration files are read """

    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed validating the configuration files"
        super().__init__(code=SDK_CONFIGURATION_FILE_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkCollectorUtilsError(BaseModelError):
    """ Used by CollectorUtils class """

    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running CollectorUtils service"
        super().__init__(code=SDK_COLLECTOR_UTILS_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkDevoLoggerError(BaseModelError):
    """ Used by DevoLogger class """

    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running DevoLogger service"
        super().__init__(code=SDK_DEVO_LOGGER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkDefinitionsInitializationError(BaseModelError):
    """ Used by CollectorDefinitions class when the configuration structure is validated """

    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed initializing the definitions"
        super().__init__(code=SDK_DEFINITIONS_INITIALIZATION_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkInputInitializationError(BaseModelError):
    """ Used by SDK input initialization phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed initializing one <input> service"
        super().__init__(code=SDK_INPUT_INIT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkInputRunningError(BaseModelError):
    """ Used by sdk input running phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running one <input> service"
        super().__init__(code=SDK_INPUT_RUNNING_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkInputThreadError(BaseModelError):
    """ Used by sdk Input Thread phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Input Thread module"
        super().__init__(code=SDK_INPUT_THREAD_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkServiceInitializationError(BaseModelError):
    """ Used by sdk Service Thread creation phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Service Thread module"
        super().__init__(code=SDK_SERVICE_INIT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkServiceRunningError(BaseModelError):
    """ Used by sdk Service Thread execution phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Service Thread module"
        super().__init__(code=SDK_SERVICE_RUNNING_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPersistenceFactoryError(BaseModelError):
    """ Used by sdk Persistence Factory """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Persistence Factory"
        super().__init__(code=SDK_PERSISTENCE_FACTORY_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPersistenceServiceError(BaseModelError):
    """ Used by sdk Persistence Service """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Persistence Service"
        super().__init__(code=SDK_PERSISTENCE_SERVICE_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPersistenceConfigurationError(BaseModelError):
    """ Used by sdk when working with Persistence Service Configuration """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed working with the Persistence Service Configuration"
        super().__init__(code=SDK_PERSISTENCE_CONFIG_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPersistenceInterfaceError(BaseModelError):
    """ Used by sdk when using the persistence interface"""
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running with the Persistence Interface"
        super().__init__(code=SDK_PERSISTENCE_INTERFACE_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkLookupFactoryError(BaseModelError):
    """ Used by Lookup Factory class """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Lookup Factory"
        super().__init__(code=SDK_LOOKUP_FACTORY_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPullerAbstractError(BaseModelError):
    """ Used by Collector Puller Abstract class """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running a CollectorPullerAbstract based instance"
        super().__init__(code=SDK_PULLER_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPullStatisticsError(BaseModelError):
    """ Used by Puller Statistics class """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running a PullStatistics instance"
        super().__init__(code=SDK_PULL_STATISTICS_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkPullerSetupAbstractError(BaseModelError):
    """ Used by Puller Statistics class """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running a PullerSetupAbstract based instance"
        super().__init__(code=SDK_PULLER_SETUP_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkOutputInitializationError(BaseModelError):
    """ Used by SDK output initialization phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed initializing one <output> service"
        super().__init__(code=SDK_OUTPUT_INIT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkOutputRunningError(BaseModelError):
    """ Used by sdk output running phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running one <output> service"
        super().__init__(code=SDK_OUTPUT_RUNNING_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkLookupServiceError(BaseModelError):
    """ Used by Lookup Service class """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the Lookup Service"
        super().__init__(code=SDK_LOOKUP_SERVICE_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSenderManagerAbstractError(BaseModelError):
    """ Used by sdk sender manager abstract """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running a SenderManagerAbstract based instance"
        super().__init__(code=SDK_SENDER_MANAGER_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSenderManagerMonitorAbstractError(BaseModelError):
    """ Used by sdk SenderManagerMonitorAbstract """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the SenderManagerMonitor based instance"
        super().__init__(
            code=SDK_SENDER_MANAGER_MONITOR_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSenderAbstractError(BaseModelError):
    """ Used by sdk sender abstract """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running a SenderAbstract based instance"
        super().__init__(code=SDK_SENDER_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSendersAbstractError(BaseModelError):
    """ Used by sdk sender(s) abstract """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the SendersAbstract based instance"
        super().__init__(code=SDK_SENDERS_ABSTRACT_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSyslogSenderManagerError(BaseModelError):
    """ Used by sdk SyslogSenderManager """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the SyslogSenderManager service"
        super().__init__(code=SDK_SYSLOG_SENDER_MANAGER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkSyslogSenderError(BaseModelError):
    """ Used by sdk syslog sender """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the SyslogSender service"
        super().__init__(code=SDK_SYSLOG_SENDER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkConsoleSenderManagerError(BaseModelError):
    """ Used by sdk SyslogSenderManager """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the ConsoleSenderManager service"
        super().__init__(code=SDK_CONSOLE_SENDER_MANAGER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkConsoleSenderError(BaseModelError):
    """ Used by sdk Console sender """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the ConsoleSender service"
        super().__init__(code=SDK_CONSOLE_SENDER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkDevoSenderManagerError(BaseModelError):
    """ Used by sdk DevoSDK sender manager """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the DevoSenderManager service"
        super().__init__(code=SDK_DEVO_SENDER_MANAGER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkDevoSenderError(BaseModelError):
    """ Used by sdk DevoSDK sender """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed running the DevoSender service"
        super().__init__(code=SDK_DEVO_SENDER_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class SdkManagementProcessInitializationError(BaseModelError):
    """ Used by SDK management process initialization phase """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed initializing management process"
        super().__init__(code=SDK_CONFIGURATION_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


# Puller Exceptions
class PullerInitVariablesError(BaseModelError):
    """ Used by pullers init_variables methods """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Puller crashed running the <init_variables> method"
        super().__init__(code=PULLER_INIT_VAR_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class PullerSetupError(BaseModelError):
    """ Used by pullers setup methods """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Puller crashed running the <setup> method"
        super().__init__(code=PULLER_SETUP_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class PullerPrePullError(BaseModelError):
    """ Used by pullers pre_pull methods """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Puller crashed running the <pre_pull> method"
        super().__init__(code=PULLER_PRE_PULL_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


class PullerPullError(BaseModelError):
    """ Used by pullers pull methods """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Puller crashed running the <pull> method"
        super().__init__(code=PULLER_PULL_ERROR, sub_code=sub_code, cause=cause, cause_title=title)


# Obfuscation Exceptions
class SdkObfuscationError(BaseModelError):
    """ Used by SDK obfuscation methods """
    def __init__(self, sub_code: int, cause: str) -> None:
        """
        Build the exception.
        :param sub_code: Error sub code, for identifying the service exception.
        :param cause: Error message with the exception reason/cause.
        """
        title: str = "Collector crashed trying to obfuscate sensitive data"
        super().__init__(code=SDK_DEVO_OBFUSCATION_ERROR, sub_code=sub_code, cause=cause, cause_title=title)
