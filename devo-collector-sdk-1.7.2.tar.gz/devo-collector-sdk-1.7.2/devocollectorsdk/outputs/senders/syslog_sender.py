import inspect
import json
import logging
import socket
import threading
from datetime import datetime
from queue import Empty
from typing import Any, Mapping, Optional

import pysyslogclient
from devo.sender import Lookup

from devocollectorsdk.commons.collector_exceptions import SdkSyslogSenderError
from devocollectorsdk.message.collector_lookup import CollectorLookup
from devocollectorsdk.message.lookup_job_factory import LookupJob
from devocollectorsdk.message.message import Message
from devocollectorsdk.outputs.commons.CustomSyslogClientRFC3164 import CustomSyslogClientRFC3164
from devocollectorsdk.outputs.senders.abstracts.sender_abstract import SenderAbstract

log = logging.getLogger(__name__)


class SyslogSender(SenderAbstract):
    """ Console Sender Class that send the msg by syslog """

    def __init__(self, **kwargs: Optional[Any]):
        """
        Builder - Abstract-base mandatory arguments are marked with (*)
        :param kwargs:  -> group_name (str): Group name
                        -> instance_name (str): Name of the instance
                        -> content_queue (SenderManagerQueue): Internal Queue used by the sender
                        -> generate_collector_details (bool): Defines if the collector details must be generated
                        -> address (str): IP address
                        -> port (int): Port number

                        -> connecting_retries (int): Max number of connection retries
                        -> connecting_wait_between_retries_in_seconds (int): Wait time between connection attempts (sec)

                        -> sending_timeout (int): Timeout for sending process
                        -> sending_retries (int): Max number of sending retires
                        -> sending_max_wait_in_seconds (int): (sec)
                        -> sending_initial_wait_in_seconds (int): (sec)
        """
        super(SyslogSender, self).__init__(**kwargs)

        # Kwargs loading
        address: str = kwargs['address']
        port: int = kwargs['port']

        connecting_retries: int = kwargs['connecting_retries']
        connecting_max_wait_in_seconds: int = kwargs['connecting_max_wait_in_seconds']
        connecting_initial_wait_in_seconds: int = kwargs['connecting_initial_wait_in_seconds']

        sending_timeout: int = kwargs['sending_timeout']
        sending_retries: int = kwargs['sending_retries']
        sending_max_wait_in_seconds: int = kwargs['sending_max_wait_in_seconds']
        sending_initial_wait_in_seconds: int = kwargs['sending_initial_wait_in_seconds']

        # Sender properties
        self._address: str = address
        self._port: int = port

        # Connection properties
        self._connecting_retries: int = connecting_retries
        self._connecting_max_wait_in_seconds: int = connecting_max_wait_in_seconds
        self._connecting_initial_wait_in_seconds: int = connecting_initial_wait_in_seconds
        self._connecting_retry_wait_object: threading.Event = threading.Event()

        # Sending properties
        self._sending_timeout: int = sending_timeout
        self._sending_retries: int = sending_retries
        self._sending_max_wait_in_seconds: int = sending_max_wait_in_seconds
        self._sending_initial_wait_in_seconds: int = sending_initial_wait_in_seconds
        self._sending_retry_wait_object: threading.Event = threading.Event()

        # Id settings
        self.internal_name: str = 'syslog_sender'

        # Sender
        self.sender: Optional[pysyslogclient.SyslogClientRFC3164] = None

    def _validate_kwargs_for_method__init__(self, kwargs: Mapping[str, Any]):
        """
        Method that raises exceptions when the kwargs are invalid.
        :param kwargs:  -> address (str): IP address
                        -> port (int): Port number

                        -> connecting_retries (int): Max number of connection retries
                        -> connecting_max_wait_in_seconds (int): Maximum wait time to be used in connection attempts (sec)
                        -> connecting_initial_wait_in_seconds (int): Initial wait time in seconds

                        -> sending_timeout (int): Timeout for sending process
                        -> sending_retries (int): Max number of sending retires
                        -> sending_max_wait_in_seconds (int): (sec)
                        -> sending_initial_wait_in_seconds (int): (sec)

        :raise: SdkSyslogSenderError
        """
        super(SyslogSender, self)._validate_kwargs_for_method__init__(kwargs)

        error_msg: str = f"{__class__.__name__}::{inspect.stack()[0][3]} ->"

        # Validate address

        val_str = 'address'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                50,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, str):
            raise SdkSyslogSenderError(
                51,
                f'{error_msg} The <{val_str}> must be an instance of <str> type not <{type(val_value)}>'
            )

        try:
            socket.inet_aton(val_value)
        except socket.error as error:
            log.warning(
                f'{error_msg} '
                f'The <{val_str}> does not appear to be an IP address and cannot be verified: "{val_value}", '
                f'details: {str(error)}'
            )

        # Validate port

        val_str = 'port'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                53,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]
        
        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                54,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )
        
        if val_value < 1 or val_value > 65535:
            raise SdkSyslogSenderError(
                55,
                f'{error_msg} The <{val_str}> must be a valid port (1-65535)'
            )

        # Validate connecting_retries

        val_str = 'connecting_retries'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                56,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]
        
        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                57,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 10:
            raise SdkSyslogSenderError(
                58,
                f'{error_msg} The <{val_str}> value must be between 1 and 10'
            )

        # Validate connecting_max_wait_in_seconds

        val_str = 'connecting_max_wait_in_seconds'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                59,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                60,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 60:
            raise SdkSyslogSenderError(
                61,
                f'{error_msg} The <{val_str}> value must be between 1 and 60'
            )

        # Validate connecting_initial_wait_in_seconds

        val_str = 'connecting_initial_wait_in_seconds'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                62,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                63,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 60:
            raise SdkSyslogSenderError(
                64,
                f'{error_msg} The <{val_str}> value must be between 1 and 60'
            )

        # Validate sending_timeout

        val_str = 'sending_timeout'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                65,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                66,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 10:
            raise SdkSyslogSenderError(
                67,
                f'{error_msg} The <{val_str}> value must be between 1 and 10'
            )

        # Validate sending_retries

        val_str = 'sending_retries'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                68,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                69,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 10:
            raise SdkSyslogSenderError(
                70,
                f'{error_msg} The <{val_str}> value must be between 1 and 10'
            )

        # Validate sending_max_wait_in_seconds
        val_str = 'sending_max_wait_in_seconds'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                71,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                72,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 60:
            raise SdkSyslogSenderError(
                73,
                f'{error_msg} The <{val_str}> value must be between 1 and 60'
            )

        # Validate sending_initial_wait_in_seconds
        
        val_str = 'sending_initial_wait_in_seconds'
        if val_str not in kwargs:
            raise SdkSyslogSenderError(
                74,
                f'{error_msg} The <{val_str}> argument is mandatory'
            )
        val_value = kwargs[val_str]

        if not isinstance(val_value, int):
            raise SdkSyslogSenderError(
                75,
                f'{error_msg} The <{val_str}> must be an instance of <int> type not <{type(val_value)}>'
            )

        if val_value < 1 or val_value > 10:
            raise SdkSyslogSenderError(
                76,
                f'{error_msg} The <{val_str}> value must be between 1 and 10'
            )

    def _run_try_catch(self) -> None:
        """Method that contains the try & catch structure to be abstracted.

        :example:

            try:
                self._run_execution()
            except Empty:
                pass
            except Exception as ex:
                log.error(f'An error has happen, details: {ex}')
                self._running_flag = False
        """

        try:
            self._run_execution()

        # This exception is raised when no message is coming to the SenderManager
        # queue by the established timeout
        except Empty:
            pass
        except Exception as ex:
            log.error(f'An error has happen, details: {ex}')
            self._running_flag = False

    def _run_finalization(self) -> None:
        """Method used to execute actions when the <finalizing thread status> is reached

        :example:

            if self.sender:
                log.info(f"Closing connection to Syslog server")
                self.sender.close()
                self.sender = None
        """

        if self.sender:
            log.info(f"Closing connection to Syslog server")
            try:
                self.sender.close()
            except:
                pass

            self.sender = None

    def _get_connection_status(self) -> bool:
        """
        Method that returns the sender connection status.
        :return: True if the connection is working. False if not.
        :example:
        is_connection_open = True if self.sender else False
        return is_connection_open
        """
        is_connection_open = True if self.sender else False
        return is_connection_open

    def _process_message(self, message: Message, start_time: datetime) -> bool:
        """Method that processes the general types of messages

        :param message: Message to be processed.
        :param start_time: Time when the process was initialized.
        """

        message_has_been_sent, bytes_already_sent = self._send_standard_message(message)
        self.last_usage_timestamp = datetime.utcnow()
        if message_has_been_sent is True:
            if message.is_internal is True:
                self._sender_stats.increase_internal_messages_bytes_counter(
                    (datetime.utcnow() - start_time).total_seconds(),
                    bytes_already_sent
                )
            else:
                self._sender_stats.increase_standard_messages_bytes_counter(
                    (datetime.utcnow() - start_time).total_seconds(),
                    bytes_already_sent
                )

        return message_has_been_sent

    def _process_lookup(self, lookup: LookupJob, start_time: datetime) -> bool:
        """Method that processes the lookup type messages. Drop all messages. Syslog cannot send Lookups.

        :param lookup: Lookup to be processed.
        :param start_time: Time when the process was initialized.
        """
        log.error(f"Message dropped: {lookup}")
        return False

    def _send_standard_message(self, message: Message) -> (bool, int):
        """Method that sends a new standard message by syslog

        :param message: message object
        :return: True if the message is sent properly. Nothing if not.
        """

        message_has_been_sent: bool = False
        bytes_already_sent: int = 0

        try:
            if self.sender is None:
                self.sender = self._create_sender()

            if self.sender:
                message_has_been_sent, bytes_already_sent = self._transmit_standard_message(message)

        except Exception as ex:
            log.error(ex)

        return message_has_been_sent, bytes_already_sent

    def _create_sender(self) -> pysyslogclient.SyslogClientRFC3164:
        """Method that creates a new real sender.

        :return: Sender object.
        """
        client: pysyslogclient.SyslogClientRFC3164 = CustomSyslogClientRFC3164(self._address, self._port)
        log.info(f"{self.instance_name} -> Created sender: {client}")

        return client

    def _transmit_standard_message(self, message: Message) -> (bool, int):
        """Send the given message object by syslog through the created sender.

        :param message: message object
        :param message:
        :return:
        """

        # Required settings
        message_has_been_sent: bool = False
        number_of_sent_items: int = 0
        current_retry_counter: int = 0
        previous_wait_time_in_seconds: int = 0
        last_exception = None
        number_of_bytes_sent: int = 0
        bytes_already_sent: int = 0

        # Send the message
        while current_retry_counter < self._sending_retries \
                and message_has_been_sent is False:
            try:
                msg_content = message.content
                self.sender.log(msg_content, program=message.tag)
                bytes_already_sent = message.syslog_size_in_bytes()
                message_has_been_sent = True
                current_retry_counter = 0

            except Exception as ex:
                last_exception = ex
                exception_dict: dict = {
                    "exception_type": str(type(ex)),
                    "exception": str(ex)
                }
                log.debug(f'Error sending: {json.dumps(exception_dict)}')

                current_retry_counter += 1

            # Troubleshooting
            if message_has_been_sent is False:
                if previous_wait_time_in_seconds == 0:
                    wait_time = self._sending_initial_wait_in_seconds
                else:
                    wait_time = previous_wait_time_in_seconds * 2
                self._sending_retry_wait_object.wait(timeout=wait_time)
                previous_wait_time_in_seconds = wait_time

        # Troubleshooting
        if current_retry_counter == self._sending_retries \
                and message_has_been_sent is False:
            exception_dict: dict = {
                "max_retries": self._sending_retries,
                "exception_type": str(type(last_exception)),
                "exception": str(last_exception)
            }
            log.error(
                f'Sending retries limit reached, message was not sent, '
                f'details: {json.dumps(exception_dict)}'
            )

        return message_has_been_sent, bytes_already_sent

    @staticmethod
    def _run_lookup_logic(collector_lookup: CollectorLookup, devo_lookup: Lookup):
        """Method that runs the lookup logic called from _send_lookup_to_syslog_server and created to reduce the
        cyclomatic complexity of this.

        :param collector_lookup: Lookup object from the queue.
        :param devo_lookup: Lookup object ready to be sent to Devo Relay.
        """
        if collector_lookup.executed_start is False:
            log.debug("LU -> Sending \"START\"")
            devo_lookup.send_control(event="START", headers=collector_lookup.headers,
                                     action=collector_lookup.action_type)
            collector_lookup.executed_start = True
            log.debug("LU -> \"START\" sent")

        if collector_lookup.executed_end is False and collector_lookup.is_empty() is False:
            while collector_lookup.is_empty() is False:
                lookup_rows, lookup_row_is_delete_action = collector_lookup.get_next_data_group()
                for lookup_row in lookup_rows:
                    devo_lookup.send_data(row=lookup_row, delete=lookup_row_is_delete_action)
                    log.debug(f"LU -> Row: delete: {lookup_row_is_delete_action}, data_sent: [{lookup_row}]")

        if collector_lookup.execute_end is True and collector_lookup.executed_end is False:
            while collector_lookup.is_empty() is False:
                lookup_rows, lookup_row_is_delete_action = collector_lookup.get_next_data_group()
                for lookup_row in lookup_rows:
                    devo_lookup.send_data(row=lookup_row, delete=lookup_row_is_delete_action)
                    log.debug(f"LU -> Row: delete: {lookup_row_is_delete_action}, data_sent: [{lookup_row}]")

            log.debug("LU -> Sending \"END\"")
            devo_lookup.send_control(event="END", headers=collector_lookup.headers, action=collector_lookup.action_type)
            collector_lookup.executed_end = True
            log.debug("LU -> \"END\" sent")

    def create_sender_if_not_exists(self) -> None:
        """ Method that creates new senders if not exist """

        if self.sender is None:
            log.debug(f"{self.name} -> Sender connection was not existing")
            self.sender = self._create_sender()

    def __str__(self):
        """ Returns a string representation of the class """

        return json.dumps(self.get_status_dict())

    def get_status_dict(self) -> dict:
        """

        :return:
        """

        socker_status: Optional[str] = None
        if self.sender:

            socket_timeout: Optional[str] = None
            socket_type: Optional[str] = None

            socket_obj = self.sender.socket
            if socket_obj is not None:
                socket_timeout = socket_obj.timeout
                socket_type = socket_obj.type

            socker_status: dict = {
                "client_name": self.sender.client_name,
                "type": socket_type,
                "timeout": socket_timeout,
                "rfc": self.sender.rfc,
                "max_message_length": self.sender.max_message_length,
                "line_trailer": self.sender.trailer,
                "details": str(socket_obj)
            }

        last_usage_timestamp_status: Optional[str] = None
        if self.last_usage_timestamp:
            last_usage_timestamp_status = self.last_usage_timestamp.isoformat()

        status: dict = {
            "name": self.name,
            "url": f'{self._address}:{self._port}',
            "connecting": {
                "retries": self._connecting_retries,
                "max_wait_in_seconds": self._connecting_max_wait_in_seconds,
                "initial_wait_in_seconds": self._connecting_initial_wait_in_seconds
            },
            "sending": {
                "timeout": self._sending_timeout,
                "retries": self._sending_retries,
                "max_wait_in_seconds": self._sending_max_wait_in_seconds,
                "initial_wait_in_seconds": self._sending_initial_wait_in_seconds
            },
            "last_usage_timestamp": last_usage_timestamp_status,
            "socket_status": socker_status
        }
        return status
