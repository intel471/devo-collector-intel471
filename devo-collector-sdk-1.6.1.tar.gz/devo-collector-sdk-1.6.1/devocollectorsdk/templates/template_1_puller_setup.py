import abc
import logging
from datetime import datetime, timezone

from devocollectorsdk.inputs.collector_puller_setup_abstract import CollectorPullerSetupAbstract
from devocollectorsdk.templates.exceptions.exceptions import SetupError

log = logging.getLogger(__name__)


class Template1CollectorPullerSetup(CollectorPullerSetupAbstract):

    def setup(self, execution_timestamp: datetime) -> None:
        """Manage the setup logic

        :param execution_timestamp: when the service were triggered
        """
        self.log_debug("Starting the execution of setup()")

        self.setup_variables["execution_timestamp_utc"]: datetime = execution_timestamp.replace(tzinfo=timezone.utc)

        # Block pull API requests
        with self.parent_thread.rate_limiter:
            self.auth_creation_step()
            self.auth_refreshing_step()

        self.log_debug("Finalizing the execution of setup()")

    def auth_creation_step(self) -> None:
        """Detect if the token/headers/authentication needs to be created"""
        if not self.service_auth_is_defined():
            self.log_warning("The token/header/authentication has not been created yet")

            log.debug('Building the token/header/authentication content (started)')
            self.build_authentication()
            log.debug('Building the token/header/authentication content (completed)')

        if not self.remote_source_is_pullable():
            raise SetupError(
                code=100,
                cause="The remote data is not pullable with the given credentials. "
                      "Check the error traces for details."
            )
        self.log_debug("The token/header/authentication is defined")

    def auth_refreshing_step(self) -> None:
        """Detect if the token/header/authentication needs to be refreshed"""
        if not self.service_auth_is_valid():
            self.log_warning("The token/header/authentication is expired and it needs to be refreshed")

            log.debug('Building the token/header/authentication content (started)')
            self.refresh_auth()
            log.debug('Building the token/header/authentication content (completed)')

        if not self.service_auth_is_valid():
            raise SetupError(
                code=101,
                cause="The token/header/authentication was refreshed but is still expired. "
                      "Check the error traces for details."
            )
        self.log_debug("The token/header/authentication is valid")

    @abc.abstractmethod
    def service_auth_is_defined(self) -> bool:
        """Returns the status of the token/header/authentication data

        Define the process to follow here

        :returns: a bool instance   -> True     When authentication is already created
                                    -> False    When authentication needs to be created (first execution)
        """
        return True

    @abc.abstractmethod
    def build_authentication(self) -> None:
        """Build the token/header/authentication data required to pull data and stores it in the collector_variables

        Define the process to follow here
        """
        pass

    @abc.abstractmethod
    def service_auth_is_valid(self) -> bool:
        """Returns if token/header/authentication data is valid or expired

        Define the process to follow here

        :returns: a bool instance   -> True     When authentication is valid
                                    -> False    When authentication is expired and needs to be refreshed
        """
        return True

    @abc.abstractmethod
    def refresh_auth(self) -> None:
        """Refresh the token/header/authentication data required to pull data

        Define the process to follow here
        """
        pass

    @abc.abstractmethod
    def remote_source_is_pullable(self) -> bool:
        """Returns if the remote source is pullable using the given credentials

        ** Unit test required ** Define the process to follow here

        :returns: a bool instance   -> True     The credentials have enough permission to pull data
                                    -> False    The credentials have not the required access
        """
        return True
