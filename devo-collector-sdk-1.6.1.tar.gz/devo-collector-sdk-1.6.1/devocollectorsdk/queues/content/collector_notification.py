from devocollectorsdk.queues.content.communication_queue_notification import CommunicationQueueNotification


class CollectorNotification(CommunicationQueueNotification):
    """
    This class will represent a notification
    """

    # Global
    GRACEFUL_SHUTDOWN: str = "graceful_shutdown"

    # Related to Input
    ERROR_WHEN_INITIALIZING_INPUT_PROCESS: str = "error_when_initializing_input_process"
    SUBMODULE_IS_NOT_WORKING: str = "submodule_is_not_working"
    MODULE_IS_NOT_WORKING: str = "module_is_not_working"
    SERVICE_IS_NOT_WORKING: str = "service_is_not_working"
    INPUT_IS_NOT_WORKING: str = "input_is_not_working"

    ALL_INPUTS_ARE_PAUSED_WAITING: str = "all_inputs_are_paused_waiting"
    ALL_INPUTS_ARE_PAUSED_WITHOUT_WAITING: str = "all_inputs_are_paused_without_waiting"
    ALL_SERVICES_ARE_PAUSED_WAITING: str = "all_services_are_paused_waiting"
    ALL_SERVICES_ARE_PAUSED_WITHOUT_WAITING: str = "all_services_are_paused_without_waiting"
    ALL_MODULES_ARE_PAUSED_WAITING: str = "all_modules_are_paused_waiting"
    ALL_MODULES_ARE_PAUSED_WITHOUT_WAITING: str = "all_modules_are_paused_without_waiting"

    ALL_INPUT_OBJECTS_ARE_STOPPED: str = "all_input_objects_are_stopped"
    ALL_SERVICE_OBJECTS_ARE_STOPPED: str = "all_service_objects_are_stopped"
    ALL_MODULE_OBJECTS_ARE_STOPPED: str = "all_module_objects_are_stopped"

    INPUT_PROCESS_IS_STOPPED: str = "input_process_is_stopped"

    # Related to Output
    FINAL_SENDER_IS_NOT_WORKING: str = "final_sender_is_not_working"

    ALL_SENDER_MANAGERS_ARE_PAUSED_WITHOUT_WAITING: str = "all_sender_managers_are_paused_without_waiting"
    ALL_SENDER_MANAGERS_ARE_PAUSED_WAITING: str = "all_sender_managers_are_paused_waiting"
    ALL_SENDER_MANAGERS_ARE_FLUSHED_WITHOUT_WAITING: str = "all_sender_managers_are_flushed_without_waiting"
    ALL_SENDER_MANAGERS_ARE_FLUSHED_WAITING: str = "all_sender_managers_are_flushed_waiting"
    ALL_SENDER_MANAGERS_ARE_STOPPED: str = "all_sender_managers_are_stopped"

    ALL_CONSUMERS_ARE_PAUSED_WITHOUT_WAITING: str = "all_consumers_are_paused_without_waiting"
    ALL_CONSUMERS_ARE_PAUSED_WAITING: str = "all_consumers_are_paused_waiting"
    ALL_CONSUMERS_ARE_FLUSHED_WITHOUT_WAITING: str = "all_consumers_are_flushed_without_waiting"
    ALL_CONSUMERS_ARE_STOPPED: str = "all_consumers_are_stopped"

    OUTPUT_PROCESS_IS_STOPPED: str = "output_process_is_stopped"

    def __init__(self, notification_id: str = None, details: str = None):
        super().__init__(notification_id=notification_id, details=details)

    # Input notifications

    @staticmethod
    def create_graceful_shutdown_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.GRACEFUL_SHUTDOWN,
            details=details
        )

    @staticmethod
    def create_error_when_initializing_input_process_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ERROR_WHEN_INITIALIZING_INPUT_PROCESS,
            details=details
        )

    @staticmethod
    def create_submodule_is_not_working_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.SUBMODULE_IS_NOT_WORKING,
            details=details
        )

    @staticmethod
    def create_module_is_not_working_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.MODULE_IS_NOT_WORKING,
            details=details
        )

    @staticmethod
    def create_service_is_not_working_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.SERVICE_IS_NOT_WORKING,
            details=details
        )

    @staticmethod
    def create_input_is_not_working_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.INPUT_IS_NOT_WORKING,
            details=details
        )

    @staticmethod
    def create_all_inputs_are_paused_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_INPUTS_ARE_PAUSED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_inputs_are_paused_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_INPUTS_ARE_PAUSED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_service_are_paused_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SERVICES_ARE_PAUSED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_services_are_paused_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SERVICES_ARE_PAUSED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_modules_are_paused_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_MODULES_ARE_PAUSED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_modules_are_paused_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_MODULES_ARE_PAUSED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_inputs_are_stopped_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_INPUT_OBJECTS_ARE_STOPPED,
            details=details
        )

    @staticmethod
    def create_input_process_is_stopped_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.INPUT_PROCESS_IS_STOPPED,
            details=details
        )

    # Output notifications

    @staticmethod
    def create_final_sender_is_not_working_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.FINAL_SENDER_IS_NOT_WORKING,
            details=details
        )

    @staticmethod
    def create_all_sender_managers_are_paused_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_sender_managers_are_paused_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_sender_managers_are_flushed_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_sender_managers_are_flushed_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_sender_managers_are_stopped_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_SENDER_MANAGERS_ARE_STOPPED,
            details=details
        )

    @staticmethod
    def create_all_consumers_are_paused_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_consumers_are_paused_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WAITING,
            details=details
        )

    @staticmethod
    def create_all_consumers_are_flushed_without_waiting_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_CONSUMERS_ARE_FLUSHED_WITHOUT_WAITING,
            details=details
        )

    @staticmethod
    def create_all_consumers_are_stopped_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.ALL_CONSUMERS_ARE_STOPPED,
            details=details
        )

    @staticmethod
    def create_output_process_is_stopped_notification(details: str):
        """

        :return:
        """
        return CollectorNotification(
            notification_id=CollectorNotification.OUTPUT_PROCESS_IS_STOPPED,
            details=details
        )
