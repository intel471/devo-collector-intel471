# -*- coding: utf-8 -*-
import json
import logging
import multiprocessing
import os
import queue
import sys
import threading
from collections import deque
from datetime import datetime
from typing import Optional, Deque

import psutil

from devocollectorsdk.collectordefinitions.collector_definitions import CollectorDefinitions
from devocollectorsdk.commons.collector_exceptions import SdkManagementProcessInitializationError
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.configuration.configuration import CollectorConfiguration
from devocollectorsdk.controllers.input_controller_thread import InputControllerThread
from devocollectorsdk.controllers.multiprocessing.management_controller_process import \
    ManagementMultiprocessingController
from devocollectorsdk.controllers.output_controller_thread import OutputControllerThread
from devocollectorsdk.controllers.statuses.component_group_status import ComponentGroupStatus
from devocollectorsdk.controllers.statuses.component_status import ComponentStatus
from devocollectorsdk.controllers.statuses.status_enum import StatusEnum
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.queues.communication_queue import CommunicationQueue
from devocollectorsdk.queues.content.collector_notification import CollectorNotification
from devocollectorsdk.queues.content.collector_order import CollectorOrder
from devocollectorsdk.queues.content.communication_queue_notification import CommunicationQueueNotification

APPNAME = 'devo-collector-unknown'
FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S.%f'
FLAG_FORMAT = "YYYY-MM-DD HH:MM:SS.nnnnnnnnn"
FLAG_REGEX = r"[0-9]{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2][0-9]|3[0-1]) " \
             r"(?:2[0-3]|[01][0-9]):[0-5][0-9](?::[0-5][0-9])?(?:\.\d{1,9})?"

# Global definitions
log = logging.getLogger(__name__)
log_level = logging.INFO


class CollectorThread(threading.Thread):
    """
    This class represents the whole collector
    """

    def __init__(self,
                 config: CollectorConfiguration = None,
                 definitions: CollectorDefinitions = None,
                 standard_queue: CollectorMultiprocessingQueue = None,
                 lookup_queue: CollectorMultiprocessingQueue = None,
                 internal_queue: CollectorMultiprocessingQueue = None,
                 production_mode: bool = None,
                 execute_only_setup_and_exit: bool = None,
                 validation_executed_with_errors: multiprocessing.Value = None):

        super().__init__()

        self.name = self.__class__.__name__
        self.__definitions: CollectorDefinitions = definitions
        self.__configurations: CollectorConfiguration = config

        self.__standard_queue: CollectorMultiprocessingQueue = standard_queue
        self.__lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.__internal_queue: CollectorMultiprocessingQueue = internal_queue

        self.__output_command_queue: CommunicationQueue = CommunicationQueue()
        self.__input_command_queue: CommunicationQueue = CommunicationQueue()

        self.validation_executed_with_errors: multiprocessing.Value = validation_executed_with_errors
        self.execute_only_setup_and_exit: bool = execute_only_setup_and_exit

        self.__output_controller_thread = \
            OutputControllerThread(
                self,
                production_mode,
                config,
                definitions,
                standard_queue,
                lookup_queue,
                internal_queue,
                self.__output_command_queue
            )

        self.__input_controller_thread = \
            InputControllerThread(
                self,
                production_mode,
                config,
                definitions,
                standard_queue,
                lookup_queue,
                internal_queue,
                self.__input_command_queue,
                execute_only_setup_and_exit,
                self.validation_executed_with_errors
            )

        self.__management_controller: Optional[ManagementMultiprocessingController] = None

        self.__production_mode: bool = production_mode

        self.__running_flag = True
        self.__main_wait_object: threading.Event = threading.Event()

        self.__component_status: ComponentStatus = ComponentStatus(self.name)

        self.__component_statuses: ComponentGroupStatus = ComponentGroupStatus(name=self.name)
        self.__component_statuses.add_component_to_group(self.__component_status)

        self.__all_data_inputs_paused: bool = False
        self.__all_data_inputs_totally_flushed: bool = False
        self.__all_senders_flushing_data_to_emergency_persistence_system: bool = False
        self.__all_senders_totally_flushed: bool = False

        self.__orders_queue = queue.Queue()
        self.__notifications_queue: Deque = deque()
        self.__current_order: Optional[CollectorOrder] = None
        self.__current_order_start_time: Optional[datetime] = None
        self.__already_processed_error_notifications: list = []
        self.__shutdown_datetime_start: Optional[datetime] = None

        self.__definitions_globals: dict = definitions.get_collector_globals()

        if self.__definitions_globals is None:
            raise SdkManagementProcessInitializationError(
                1100,
                'Required "collector_globals" entry not found in collector definitions'
            )

        management_process_execution_period_in_seconds = self.__definitions_globals.get('management_process_execution_period_in_seconds')
        if management_process_execution_period_in_seconds is None:
            raise SdkManagementProcessInitializationError(
                1101,
                'Required "collector_globals.management_process_execution_period_in_seconds" '
                'mandatory property not found in collector definitions'
            )
        if not isinstance(management_process_execution_period_in_seconds, int):
            raise SdkManagementProcessInitializationError(
                1102,
                'The "collector_globals.management_process_execution_period_in_seconds" '
                'property is not an integer'
            )
        if management_process_execution_period_in_seconds < 1:
            raise SdkManagementProcessInitializationError(
                1103,
                'The "collector_globals.management_process_execution_period_in_seconds" '
                'property is not having a valid integer value (it must be greater than 0)'
            )

        self.__management_process_execution_period_in_seconds: int = management_process_execution_period_in_seconds

    def is_production_mode(self) -> bool:
        """For knowing if the collector is in production mode

        :return:
        :rtype: bool
        """
        return self.__production_mode

    def start(self) -> None:
        """

        :return:
        """

        self.__output_controller_thread.start()
        output_controller_status: ComponentStatus = self.__output_controller_thread.get_status()
        self.__component_statuses.add_component_to_group(output_controller_status)

        self.__input_controller_thread.start()
        input_controller_status: ComponentStatus = self.__input_controller_thread.get_status()
        self.__component_statuses.add_component_to_group(input_controller_status)

        super().start()

    def stop(self) -> None:
        """

        :return:
        """
        self.__running_flag = False

    def run(self) -> None:
        """

        :return:
        """

        while self.__running_flag:

            self.__component_status.status = StatusEnum.RUNNING

            if self.__output_command_queue.has_pending_notification() is False \
                    and self.__input_command_queue.has_pending_notification() is False:

                log.info(
                    f'global_status: {json.dumps(self.__get_summary_status())}'
                )

                log.info(
                    f'environment_status: {json.dumps(self.__get_execution_environment_status())}'
                )

                log.debug("Entering in wait status")

                called: bool = self.__main_wait_object.wait(
                    timeout=self.__management_process_execution_period_in_seconds
                )
                if called is True:
                    self.__main_wait_object.clear()

                log.debug("Waking up from wait status")

            collector_must_exit: bool = self.check_collector_must_exit()
            if collector_must_exit is True:
                self.stop()
                continue

            # Checks if any notification has been received from output process
            while self.__output_command_queue.has_pending_notification():
                notification: CommunicationQueueNotification = self.__output_command_queue.get_notification()
                log.debug(f'Received notification: {notification}')
                if notification in self.__already_processed_error_notifications:
                    log.debug(f'Discarding already processed notification type, notification: {notification}')
                else:
                    self.__notifications_queue.append(notification)

            # Checks if any notification has been received from input process
            while self.__input_command_queue.has_pending_notification():
                notification: CommunicationQueueNotification = self.__input_command_queue.get_notification()
                log.debug(f'Received notification: {notification}')
                if notification in self.__already_processed_error_notifications:
                    log.debug(f'Discarding already processed notification type, notification: {notification}')
                else:
                    self.__notifications_queue.append(notification)

            # Besides the notifications that can be coming from the input and output processes,
            # there is an extra notification that can arrive from the "graceful_shutdown" function
            if len(self.__notifications_queue) > 0:
                # Check if received notification is caused by current order
                if self.__current_order:
                    self.__check_if_notifications_are_valid_for_current_order()
                elif len(self.__notifications_queue) > 0:
                    notification_for_being_used = self.__notifications_queue.popleft()
                    log.debug(
                        f'There is no pending order, '
                        f'so some decisions will be made based on the notification: {notification_for_being_used}'
                    )
                    decisions: list[CollectorOrder] = self.__make_decisions(notification_for_being_used)
                    for index, decision in enumerate(decisions, start=1):
                        log.debug(f'Decision #{index}: {decision}')
                        self.__orders_queue.put(decision)

            if self.__orders_queue.qsize() > 0 and self.__current_order is None:

                self.__current_order = self.__orders_queue.get(block=False)
                self.__current_order_start_time = datetime.utcnow()
                log.info(f'Processing order: {self.__current_order}')

                if self.__current_order.is_output():
                    self.__output_command_queue.send_order(self.__current_order)
                    self.__output_controller_thread.wake_up()

                if self.__current_order.is_input():
                    self.__input_command_queue.send_order(self.__current_order)
                    self.__input_controller_thread.wake_up()

        log.info(f'Finalizing thread')

        self.__standard_queue.close()
        self.__lookup_queue.close()
        self.__internal_queue.close()

        log.info(
            f'global_status: {json.dumps(self.__get_summary_status())}'
        )
        log.info(
            f'environment_status: {json.dumps(self.__get_execution_environment_status())}'
        )

    def __check_if_notifications_are_valid_for_current_order(self) -> None:
        """

        :return:
        """

        log.debug(f'There is an order waiting to be finished, id: "{self.__current_order.id}"')
        if len(self.__notifications_queue) == 0:
            log.debug(f'The notification queue is empty')
        else:
            order_completed: bool = False
            if self.__current_order == CollectorOrder.PAUSE_ALL_INPUTS_WITHOUT_WAITING \
                    and CollectorNotification.ALL_INPUTS_ARE_PAUSED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_INPUTS_ARE_PAUSED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_INPUTS_WAITING \
                    and CollectorNotification.ALL_INPUTS_ARE_PAUSED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_INPUTS_ARE_PAUSED_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_SERVICES_WITHOUT_WAITING \
                    and CollectorNotification.ALL_SERVICES_ARE_PAUSED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SERVICES_ARE_PAUSED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_SERVICES_WAITING \
                    and CollectorNotification.ALL_SERVICES_ARE_PAUSED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SERVICES_ARE_PAUSED_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_MODULES_WITHOUT_WAITING \
                    and CollectorNotification.ALL_MODULES_ARE_PAUSED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_MODULES_ARE_PAUSED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_MODULES_WAITING \
                    and CollectorNotification.ALL_MODULES_ARE_PAUSED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_MODULES_ARE_PAUSED_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.STOP_ALL_INPUT_OBJECTS \
                    and CollectorNotification.ALL_INPUT_OBJECTS_ARE_STOPPED in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_INPUT_OBJECTS_ARE_STOPPED)
                order_completed = True

            elif self.__current_order == CollectorOrder.STOP_INPUT_CONTROLLER \
                    and CollectorNotification.INPUT_PROCESS_IS_STOPPED in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.INPUT_PROCESS_IS_STOPPED)
                self.__input_controller_thread.stop()
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_SENDER_MANAGERS_WITHOUT_WAITING \
                    and CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_SENDER_MANAGERS_WAITING \
                    and CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SENDER_MANAGERS_ARE_PAUSED_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_CONSUMERS_WITHOUT_WAITING \
                    and CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.PAUSE_ALL_CONSUMERS_WAITING \
                    and CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_CONSUMERS_ARE_PAUSED_WAITING)
                order_completed = True
            elif self.__current_order == CollectorOrder.FLUSH_ALL_SENDER_MANAGERS_WITHOUT_WAITING \
                    and CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.FLUSH_ALL_SENDER_MANAGERS_WAITING \
                    and CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_SENDER_MANAGERS_ARE_FLUSHED_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.FLUSH_ALL_CONSUMERS_WITHOUT_WAITING \
                    and CollectorNotification.ALL_CONSUMERS_ARE_FLUSHED_WITHOUT_WAITING in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.ALL_CONSUMERS_ARE_FLUSHED_WITHOUT_WAITING)
                order_completed = True

            elif self.__current_order == CollectorOrder.STOP_OUTPUT_CONTROLLER \
                    and CollectorNotification.OUTPUT_PROCESS_IS_STOPPED in self.__notifications_queue:

                self.__notifications_queue.remove(CollectorNotification.OUTPUT_PROCESS_IS_STOPPED)
                self.__output_controller_thread.stop()
                order_completed = True

            else:
                log.debug(f'The current order will not use the received notification')

            if order_completed is True:
                elapsed_time_in_seconds: float = (datetime.utcnow()-self.__current_order_start_time).total_seconds()
                log.info(
                    f'Order completely executed: {self.__current_order} '
                    f'(elapsed_time_in_seconds: {elapsed_time_in_seconds:.3f})'
                )
                self.__current_order = None

    def check_collector_must_exit(self) -> bool:
        """

        :return:
        """
        if self.__input_controller_thread.is_alive() is False \
                and self.__output_controller_thread.is_alive() is False:
            return True

    def wake_up(self) -> None:
        """Forces the exit from the wait state

        :return:
        """
        if self.__main_wait_object.is_set() is False:
            self.__main_wait_object.set()

    @property
    def shutdown_datetime_start(self):
        return self.__shutdown_datetime_start

    def __make_decisions(self, notification: CollectorNotification) -> list:

        decisions: list[CollectorOrder] = []

        if notification in (
                CollectorNotification.FINAL_SENDER_IS_NOT_WORKING,
                CollectorNotification.GRACEFUL_SHUTDOWN,
                CollectorNotification.SETUP_VALIDATION_EXECUTED
        ):

            self.__shutdown_datetime_start = datetime.utcnow()

            if notification not in self.__already_processed_error_notifications:
                self.__already_processed_error_notifications.append(notification)

            log.info(
                f'It has been received a notification that will cause a '
                f'controlled stop of the whole collector: {notification}')

            decisions.append(
                CollectorOrder.create_pause_all_modules_order_without_waiting(
                    f'All the modules will be paused (async), details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_pause_all_services_order_waiting(
                    f'All the services will be paused (sync), details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_pause_all_inputs_order_waiting(
                    f'All the inputs will be paused (sync), details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_pause_all_consumers_order_without_waiting(
                    f'All consumers will be paused, details: {notification.details}'
                )
            )
            # decisions.append(
            #     CollectorOrder.create_pause_all_sender_managers_order_without_waiting(
            #         f'All sender managers will be paused, details: {notification.details}'
            #     )
            # )
            decisions.append(
                CollectorOrder.create_pause_all_sender_managers_order_waiting(
                    f'All sender managers will be paused, details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_flush_all_sender_managers_order(
                    f'All sender managers will be flushed, details: {notification.details}'
                )
            )
            # decisions.append(
            #     CollectorOrder.create_pause_all_consumers_order_waiting(
            #         f'All consumers will be paused, details: {notification.details}'
            #     )
            # )
            decisions.append(
                CollectorOrder.create_flush_all_consumers_order(
                    f'All consumers will be flushed, details: {notification.details}'
                )
            )

            decisions.append(
                CollectorOrder.create_pause_all_modules_order_waiting(
                    f'All the modules will be paused (sync), details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_stop_input_controller_order(
                    f'All the inputs will be stopped, details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_stop_output_controller_order(
                    f'All the inputs will be stopped, details: {notification.details}'
                )
            )

        elif notification == CollectorNotification.ERROR_WHEN_INITIALIZING_INPUT_PROCESS:

            self.__shutdown_datetime_start = datetime.utcnow()

            if notification not in self.__already_processed_error_notifications:
                self.__already_processed_error_notifications.append(notification)

            log.info(
                f'It has been received a notification that will cause a '
                f'controlled stop of the whole collector: {notification}')

            decisions.append(
                CollectorOrder.create_pause_all_consumers_order_without_waiting(
                    f'All consumers will be paused, details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_pause_all_sender_managers_order_without_waiting(
                    f'All sender managers will be paused, details: {notification.details}'
                )
            )

            decisions.append(
                CollectorOrder.create_flush_all_consumers_order(
                    f'All consumers will be flushed, details: {notification.details}'
                )
            )

            decisions.append(
                CollectorOrder.create_flush_all_sender_managers_order(
                    f'All sender managers will be flushed, details: {notification.details}'
                )
            )

            decisions.append(
                CollectorOrder.create_stop_input_controller_order(
                    f'All the inputs will be stopped, details: {notification.details}'
                )
            )
            decisions.append(
                CollectorOrder.create_stop_output_controller_order(
                    f'All the inputs will be stopped, details: {notification.details}'
                )
            )

        else:

            log.warning(
                f"The notification received will not generate any decision, "
                f"notification: {notification}"
            )

        return decisions

    def graceful_shutdown(self):
        """

        :return:
        """

        log.info(f'{self.name} -> The graceful shutdown notification will be sent')

        notification = CollectorNotification.create_graceful_shutdown_notification(
                    'Received the GRACEFUL_SHUTDOWN command'
                )
        self.__notifications_queue.append(notification)
        self.wake_up()

    def __get_summary_status(self) -> dict:
        """

        :return:
        """

        thread_names: list = []
        for t in threading.enumerate():
            thread_names.append(t.name)

        process = psutil.Process(pid=os.getpid())
        with process.oneshot():
            process_status = process.status()
            process_num_threads = process.num_threads()
            process_memory_info = process.memory_info()

            status: dict = {
                "main_process": {
                    "process_id": process.pid,
                    "process_status": process_status,
                    "thread_counter": process_num_threads,
                    "thread_names": thread_names,
                    "memory_info": CollectorUtils.memory_info_to_human_dict(process_memory_info),
                    "CollectorThread": {
                        "running_flag": self.__running_flag,
                        "status": str(self.__component_status.status),
                        "shutdown_timestamp": str(self.__shutdown_datetime_start),
                        "message_queues": {
                            "standard": self.__standard_queue.get_summary_status(),
                            "lookup": self.__lookup_queue.get_summary_status(),
                            "internal": self.__internal_queue.get_summary_status()
                        },
                        # "command_queues": {
                        #     "input": str(self.__input_command_queue),
                        #     "output": str(self.__output_command_queue)
                        # },
                        "controllers": {
                            "InputControllerThread": self.__input_controller_thread.get_summary_status(),
                            "OutputControllerThread": self.__output_controller_thread.get_summary_status()
                        }
                    }

                }
            }
            return status

    def __get_execution_environment_status(self) -> dict:
        """

        :return:
        """

        if self.__operating_system_allows_system_info() is True:
            # CPU usage
            cpu_usage: Optional[str] = None
            try:
                load_avg: tuple[float, float, float] = psutil.getloadavg()
                cpu_usage = f'1:{load_avg[0]:0.2f}, 5:{load_avg[1]:0.2f}, 15:{load_avg[2]:0.2f}, '
            except Exception as ex:
                log.warning(f'The "load_average" function is not available for this OS, details: {str(ex)}')

            # Disk usage
            partition_info = {}
            for partition in psutil.disk_partitions():
                partition_info[partition.mountpoint] = psutil.disk_usage(partition.mountpoint).percent

            # Process info
            processes_info = []
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'cmdline']):
                try:
                    proc_pid = proc.pid
                    proc_ppid = 'it_does_not_exist'
                    try:
                        proc_ppid = proc.ppid()
                    except Exception as ex:
                        log.warning(
                            f'The parent process for process id "{proc_pid}" does not exists now'
                        )

                    processes_info.append(
                        {
                            "pid": proc_pid,
                            "ppid": proc_ppid,
                            "process_name": proc.name(),
                            "process_cmd": " ".join(proc.cmdline()),
                            "memory_usage": CollectorUtils.memory_info_to_human_dict(proc.memory_info())
                        }
                    )
                except Exception as ex:
                    log.warning(f"There is a process that now it doesn't exists")

            virtual_memory = {}
            virtual_memory_object = psutil.virtual_memory()
            if virtual_memory_object is not None:
                for name in virtual_memory_object._fields:
                    value = getattr(virtual_memory_object, name)
                    if name != 'percent':
                        value = CollectorUtils.human_readable_size(value)
                    virtual_memory[name] = value

            status = {
                "cpu_count": psutil.cpu_count(),
                "cpu_usage": cpu_usage,
                "virtual_memory": virtual_memory,
                "disk_usage": partition_info,
                "processes_info": processes_info
            }
        else:
            status = {
                "message": "Operating System is not having enough permissions for showing system info"
            }

        return status

    @staticmethod
    def __operating_system_allows_system_info() -> bool:
        """

        :return:
        """

        current_os = sys.platform
        if current_os == "linux":
            return True
        elif current_os == "darwin":
            return False
        elif current_os == "win32":
            return False
