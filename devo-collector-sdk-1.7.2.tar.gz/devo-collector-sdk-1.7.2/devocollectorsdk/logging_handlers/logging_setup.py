import logging


def setup_logging_with_basic_configuration() -> None:
    """Set up the current logging_handlers module with the standard configuration

    :return:
    """

    # Config logging service
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s.%(msecs)03d %(levelname)7s %(processName)s::%(threadName)s -> %(message)s',
        datefmt='%Y-%m-%dT%H:%M:%S'
    )
