from devocollectorsdk.queues.content.collector_order import CollectorOrder


class CollectorCommand:

    def __init__(self,
                 method_name_to_execute: str,
                 controller_type: str,
                 details: str,
                 wait_for_complete: bool = False):
        """

        :param method_name_to_execute:
        :param controller_type:
        :param details:
        :param wait_for_complete:
        """

        self.method_name_to_execute: str = method_name_to_execute
        self.controller_type: str = controller_type
        self.details: str = details
        self.wait_for_complete: bool = wait_for_complete

        self.__check_command_values()

    def __check_command_values(self) -> None:
        if self.controller_type not in [CollectorOrder.INPUT_TYPE, CollectorOrder.OUTPUT_TYPE]:
            raise Exception("The controller type is having a wrong value")
