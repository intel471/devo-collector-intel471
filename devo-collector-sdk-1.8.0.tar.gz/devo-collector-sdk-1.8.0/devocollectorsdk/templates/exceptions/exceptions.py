class BaseModelError(Exception):

    def __init__(self, code: int, cause: str) -> None:
        self.code: int = code
        self.cause: str = cause

    def __str__(self) -> str:
        return \
            "{exception_name} [CODE:{code:04d}] reason: {cause}".format(
                exception_name=self.__class__.__name__,
                code=self.code,
                cause=self.cause
            )

    def _validate_code(self, code, minimum, maximum):
        """Validates the code given to the exception"""
        if code < minimum or code > maximum:
            raise AssertionError(
                f'Unauthorized code for a {self.__class__} exception. {code} is out of range: {minimum} to {maximum}'
            )


class InitVariablesError(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=0, maximum=99)
        super().__init__(code, cause)


class SetupError(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=100, maximum=199)
        super().__init__(code, cause)


class PrePullError(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=200, maximum=299)
        super().__init__(code, cause)


class PullError(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=300, maximum=399)
        super().__init__(code, cause)


class ApiError(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=400, maximum=499)
        super().__init__(code, cause)


class YourCustomError1(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=500, maximum=599)
        super().__init__(code, cause)


class YourCustomError2(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=600, maximum=699)
        super().__init__(code, cause)


class YourCustomError3(BaseModelError):
    def __init__(self, code: int, cause: str) -> None:
        self._validate_code(code=code, minimum=700, maximum=799)
        super().__init__(code, cause)

