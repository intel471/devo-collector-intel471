from enum import Enum


class ObjectStatuses(Enum):
    INITIALIZING: int = 10
    INITIALIZED: int = 20
    RUNNING: int = 30
    PAUSING: int = 40
    PAUSED: int = 50
    FLUSHING: int = 60
    FLUSHED: int = 70
    STOPPING: int = 80
    STOPPED: int = 90
