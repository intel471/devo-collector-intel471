import abc
import json
import logging
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Union

from jsonschema import validate
from jsonschema.exceptions import ValidationError

from devocollectorsdk.commons.obfuscation_utils import ObfuscationUtils
from devocollectorsdk.inputs.collector_puller_abstract import CollectorPullerAbstract
from devocollectorsdk.message.message import Message
from devocollectorsdk.templates.exceptions.exceptions import InitVariablesError
# noinspection PyUnresolvedReferences
from devocollectorsdk.templates.template_1_puller_setup import Template1CollectorPullerSetup

log = logging.getLogger(__name__)


class Template1CollectorPuller(CollectorPullerAbstract):

    def init_variables(self,
                       input_config: dict,
                       input_definition: dict,
                       service_config: dict,
                       service_definition: dict,
                       module_config: dict,
                       module_definition: dict,
                       submodule_config: Any) -> None:
        """Get the internal and user configuration and run an initial generic validation based on JSON Schema

        :param input_config: Input configuration from the user config file
        :param input_definition: Input configuration from the collector definitions file
        :param service_config: Service configuration from the user config file
        :param service_definition: Service configuration from the collector definitions file
        :param module_config: Module configuration from the user config file
        :param module_definition: Module configuration from the collector definitions file
        :param submodule_config: Submodule definition from the user config file
        """

        self.log_info(f'{self.name} Starting the execution of init_variables()')

        self.collector_variables.update(input_config)
        self.collector_variables.update(module_definition["module_properties"].items())
        self.collector_variables.update(service_config.items())

        self.log_info("Validating service metadata")
        if (metadata := module_definition.get("metadata")) is None:
            raise AttributeError("<metadata> config is mandatory in the module_definition but it is not present")
        self.validate_metadata_structure(instance=metadata)
        self.collector_variables['persistence'] = {}
        self.collector_variables['persistence']['version'] = metadata['persistence_version']
        self.collector_variables['persistence']['schema'] = metadata['schemas']['persistence']

        schemas: dict = metadata.get("schemas")
        overriding_rules: dict = metadata.get("allowed_overwrites")

        self.log_info("Validating defined module definition")
        internal_config: dict = deepcopy(module_definition)
        internal_config.pop("metadata")
        self.log_debug("Validating internal rate limiter config")
        if internal_config.get("requests_limits") is None:
            raise AssertionError(
                "Devo Collector SDK rule violation: <rate_limiter> configuration is mandatory for this internal "
                "service config but but it is not defined in the internal or is empty")
        requests_limits: dict = internal_config.pop("requests_limits")
        self.log_debug("Validating internal config without rate limiter")
        self.validate_rate_limiter_config(rate_limiter_config=requests_limits)
        self.validate_internal_configuration(
            instance=internal_config, schema=schemas.get("internal_config"))
        self.collector_variables['store'] = {}
        self.collector_variables['store']['service_definition'] = internal_config

        self.log_info("Validating common input config")
        common_config: dict = deepcopy(input_config)
        common_config.pop("services")
        common_config.pop("persistence")
        self.validate_user_config(
            instance=common_config, schema=schemas.get("common_config"))
        self.collector_variables['store']['input_config'] = common_config

        self.log_info("Validating service input config")
        service_config_: dict = deepcopy(service_config)
        if "requests_limits" in service_config_:
            service_config_.pop("requests_limits")
        self.validate_user_config(
            instance=service_config_, schema=schemas.get("user_config"))
        self.collector_variables['store']['service_config'] = service_config_

        self.log_info("Running overriding rules")
        self.apply_overriding_rules(
            service_config=service_config_,
            service_definition=module_definition,
            rules=overriding_rules
        )

        self.log_info("Validating the rate limiter config given by the user")
        self.validate_rate_limiter_config(rate_limiter_config=service_config.get("requests_limits"))

        self.log_info("Adding raw config to the collector store")
        self.collector_variables['store_raw'] = {
            'input_config': input_config,
            'input_definition': input_definition,
            'service_config': service_config,
            'service_definition': service_definition,
            'module_config': module_config,
            'module_definition': module_definition,
            'submodule_config': submodule_config
        }

        self.log_info("Running custom validation rules")
        self.run_custom_init_variables_validations()

        self.log_info(f'{self.name} Finalizing the execution of init_variables()')

    def validate_metadata_structure(self, instance: dict) -> None:
        """Validates the service metadata config through json-schema

        :param instance: JSON object to be validated
        :raises: AssertionError()
        """
        # Get the json schema to be applied and check that the format is valid
        metadata_schema: dict = {
            "$schema": "http://json-schema.org/draft-06/schema#",
            "$ref": "#/definitions/Welcome3",
            "definitions": {
                "Welcome3": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "schemas": {
                            "$ref": "#/definitions/Schemas"
                        },
                        "persistence_version": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": 99
                        },
                        "allowed_overwrites": {
                            "$ref": "#/definitions/AllowedOverwrites"
                        }
                    },
                    "required": [
                        "allowed_overwrites",
                        "persistence_version",
                        "schemas"
                    ],
                    "title": "Welcome3"
                },
                "AllowedOverwrites": {
                    "type": "object",
                    "patternProperties": {
                        "^override_[a-z0-9_]*$": {
                          "type": "string",
                        }
                      },
                      "additionalProperties": False,
                    "title": "AllowedOverwrites"
                },
                "Schemas": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "common_config": {
                            "type": "string",
                            "pattern": "^[A-Za-z0-9_-]*.json$"
                        },
                        "internal_config": {
                            "type": "string",
                            "pattern": "^[A-Za-z0-9_-]*.json$"
                        },
                        "user_config": {
                            "type": "string",
                            "pattern": "^[A-Za-z0-9_-]*.json$"
                        },
                        "persistence": {
                            "type": "string",
                            "pattern": "^[A-Za-z0-9_-]*.json$"
                        }
                    },
                    "required": [
                        "common_config",
                        "internal_config",
                        "persistence",
                        "user_config"
                    ],
                    "title": "Schemas"
                }
            }
        }

        # Run the json schema validation
        try:
            validate(instance=instance, schema=metadata_schema)
        except ValidationError as e:
            self.log_error(
                f"Invalid content detected in the metadata config: {e.message} | "
                f"Error in JSON-level {len(e.path) + 1} | "
                f"Value of metadata.{'.'.join(e.path) if len(e.path) != 0 else 'None'}"
            )
            raise AssertionError(
                'Devo Collector SDK Rules violation: '
                'Service <metadata> content violates the current JSON schema'
            )

    def validate_internal_configuration(self, instance: dict, schema: str) -> None:
        """Validates the collector definition config through json-schema

        :param instance: JSON object to be validated
        :param schema: file name with the schema to be used
        :raises: InitVariableError(0) and AssertionError()
        """
        # Get the json schema to be applied and check that the format is valid
        config_schema: dict = self.get_schema_from_file(file_name=schema)
        if not isinstance(config_schema, dict):
            raise AssertionError(
                'Devo Collector SDK Rules violation: '
                'The JSON-Schema for the collector definitions should be a dict instance'
            )

        # Run the json schema validation
        try:
            validate(instance=instance, schema=config_schema)
        except ValidationError as e:
            self.log_error(
                f"Invalid content detected in the internal config: {e.message} | "
                f"Error in JSON-level {len(e.path) + 1} | "
                f"Value of {self.service_name}.{'.'.join(e.path) if len(e.path) != 0 else 'None'}"
            )
            raise InitVariablesError(
                code=0,
                cause="The internal config did not pass the format validation. Contact Devo Support."
            )

    def get_schema_from_file(self, file_name: str) -> dict:
        """Returns a json schema from the given file name that should be available in the schemas/ folder

        :param file_name: Name of the file where the schema is available
        :returns: json schema as dict instance
        """
        try:
            with open(f"schemas/{file_name}", "r") as file:
                schema: dict = json.load(file)
        except Exception as e:
            self.log_error(
                f"An error was found when opening a schema file with name {file_name}. "
                f"Details: {e.__class__}({e.__str__})")
            raise

        return schema

    def validate_user_config(self, instance: dict, schema: str) -> None:
        """Validates the collector definition config through json-schema

        :param instance: JSON object to be validated
        :param schema: file name with the schema to be used
        :raises: InitVariablesError(1) & AssertionError()
        """
        # Get the json schema to be applied and check that the format is valid
        config_schema: dict = self.get_schema_from_file(file_name=schema)
        if not isinstance(config_schema, dict):
            raise AssertionError(
                'Devo Collector SDK Rules violation: The JSON-Schema for the collector definitions should be a '
                'dict instance'
            )

        # Run the json schema validation
        try:
            validate(instance=instance, schema=config_schema)
        except ValidationError as e:
            self.log_error(
                f"Invalid content detected in the user config: {e.message} | "
                f"Error in JSON-level {len(e.path) + 1} | "
                f"Value of input_config.{'.'.join(e.path) if len(e.path) != 0 else 'None'}"
            )
            raise InitVariablesError(
                code=1,
                cause="The user config did not pass the format validation. "
                      "Check error traces for details and visit our documentation."
            )

    def validate_rate_limiter_config(self, rate_limiter_config: dict) -> None:
        """Validates the rate limiter settings

        :param rate_limiter_config: dict instance with the content of the requests_limits key of the service
        :returns: None
        :raises: InitVariablesError(2-3)
        """

        # Schema definition
        custom_rate_limiter_schema: dict = {
            "type": "array",
            "additionalProperties": False,
            "required": [
                "period",
                "number_of_requests"
            ],
            "properties": {
                "period": {
                    "type": "string",
                    "pattern": "^\d+[s,m,h,d,w,M,y]$"
                },
                "number_of_requests": {
                    "anyOf": [
                        {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 9999999
                        },
                        {
                            "type": "integer",
                            "const": -1
                        }
                    ]
                }
            }
        }

        # Validation
        if rate_limiter_config is None:
            self.log_info(
                '<requests_limits> setting has not been defined. The generic settings will be used instead.'
            )
        elif not isinstance(rate_limiter_config, list):
            log_message: str = \
                f'<requests_limits> setting has been defined with wrong type. ' \
                f'Expected <list> but received <{type(rate_limiter_config)}>'
            self.log_error(log_message)
            raise InitVariablesError(2, log_message)
        else:
            try:
                validate(rate_limiter_config, custom_rate_limiter_schema)
            except ValidationError as e:
                self.log_error(
                    f"Invalid content detected in the requests_limits config: {e.message} | "
                    f"Error in JSON-level {len(e.path) + 1} | "
                    f"Value of input_config.{'.'.join(e.path) if len(e.path) != 0 else 'None'}"
                )
                raise InitVariablesError(
                    code=3,
                    cause="The user config did not pass the format validation. "
                          "Check error traces for details and visit our documentation."
                )

    def apply_overriding_rules(self, service_config: dict, service_definition: dict, rules: dict) -> None:
        """Reads the overriding rules and populates new keys in the collector_variables based on them

        :param service_config: service config given by the user as dict instance
        :param service_definition: service definition given by the developer has dict instance
        :param rules: dict
        """
        # Loop all available rules
        counter = 0
        for service_key, definition_key in rules.items():
            counter += 1
            service_value: Any = service_config.get(service_key)
            if service_value is not None:
                definition_value: Any = service_definition.get(definition_key)
                self.log_info(f"Overriding rule #{counter} - "
                              f"service key <{service_key}> with value <{service_value}> overrides "
                              f"definition key <{definition_key}> with value <{definition_value}> "
                              f"when the first is not <None>")
                self.collector_variables[definition_key]: Any = service_config.get(
                    service_key,
                    definition_value
                )

    @abc.abstractmethod
    def run_custom_init_variables_validations(self) -> None:
        """Runs here all custom init_variables validations not allowed by the SDK"""
        pass

    def store_retrieving_timestamp(self, retrieving_timestamp: datetime) -> None:
        """Store the current/delayed retrieving_timestamp into the collector_variables

        Takes the retrieving_timestamp as argument and store it into the collector_variables
        as datetime and string (epoch) to be used as time reference and devo_pulling_id. Plus to this,
        it calculates the delayed value when the 'apply_delay_to_retrieving_timestamp' key is
        available in the collector_variables.

        :param retrieving_timestamp: Datetime the pull method was triggered
        """
        # Store the real value in UTC
        self.collector_variables['retrieving_timestamp'] = retrieving_timestamp.replace(tzinfo=timezone.utc)

        # Calculate the delayed value when required in UTC
        if self.collector_variables.get('apply_delay_to_retrieving_timestamp') is not None:
            # Todo
            self.log_warning("Not implemented logic")
            self.collector_variables['retrieving_timestamp_delayed'] = retrieving_timestamp

        # Calculate the pulling_id value
        self.collector_variables['devo_pulling_id'] = str(int(retrieving_timestamp.timestamp() * 1000))

    def pre_pull(self, retrieving_timestamp: datetime) -> None:
        """Execute all required actions that need to be made before the first pulling after start the collector

        This method is in charge of:
        - Override the standard_rate_limiter
        - Initialize the persistence content
        - Upgrade the persistence from previous versions
        - Modify the persistence to comply with the remote business/logic rules such as avoid invalid time range calls
        - Reset the persistence based on the user config changes

        :param retrieving_timestamp: UTC Timestamp pull was triggered
        :raises: AssertionError()
        """

        self.log_info(f'{self.getName()} Starting the execution of pre_pull()')

        # Get persisted content and take an initial snapshot
        self.log_info("Reading persisted data")
        state: dict = self.persistence_object.load_state()
        initial_state = state.__str__()
        self.log_info(f"Data retrieved from the persistence: {initial_state}")

        # Get default value for the state
        default_state: dict = self.prepull_default_state(retrieving_ts=retrieving_timestamp)

        if not isinstance(default_state, dict):
            raise AssertionError(
                "Devo Collector SDK Rules violation: The default state must be a dict instance"
            )
        elif len(default_state) == 0:
            raise AssertionError(
                "Devo Collector SDK Rules violation: The default state cannot be an empty dict instance"
            )

        # Initialize the state when needed
        if state is None:
            self.log_warning("Persistence will be overridden due to the retrieved state is empty")
            state: dict = default_state.copy()

        payload: dict = {
            "default_state": default_state,
            "state": state,
            "retrieving_ts": retrieving_timestamp
        }

        # Here we manage the persistence upgrading from previous versions
        self.log_info('Running the persistence upgrade steps')
        payload['state'] = self.prepull_persistence_upgrade_steps(**payload)

        # Here we manage all compliance rules for the persistence based on today
        self.log_info('Running the persistence corrections steps')
        payload['state'] = self.prepull_persistence_corrections_steps(**payload)

        # Here we manage the user request for resetting the persistence
        self.log_info('Running the persistence corrections steps')
        payload['state'] = self.prepull_persistence_reset_steps(**payload)

        # Here we manage the extra rate limiters required to manage the pulling logic
        self.prepull_build_extra_rate_limiters()

        # Update the persistence when needed
        if self.collector_variables['persistence']['version'] == 0:
            self.log_warning("The persistence version value is <ZERO>, so no persistence will be allocated")
        elif initial_state != payload['state'].__str__():
            self.log_warning(
                f"Some changes have been detected and the persistence needs to be updated. "
                f"Previous content: {initial_state}. New content: { payload['state'].__str__()}"
            )
            self.validate_and_save_persistence(state=payload['state'])
            self.log_warning("Persistence has been updated successfully")
        else:
            self.log_info("No changes were detected in the persistence")

        self.log_info(f'{self.name} Finalizing the execution of pre_pull()')

    def override_standard_rate_limiter(self) -> None:
        """Override the standard rate limiter object if the user defined a new config in the service level"""

        log.debug("Overriding standard rate limiter")
        if 'rate_limiter_config' in self.collector_variables:
            self.rate_limiter.period = self.collector_variables['rate_limiter_config']['period_in_seconds']
            self.rate_limiter.max_calls = self.collector_variables['rate_limiter_config']['requests_limit_in_units']

            log_message = \
                f'The rate_limiter object has been overridden with the following config: ' \
                f'{self.collector_variables["rate_limiter_config"]}'
            self.log_warning(log_message)
        else:
            self.log_debug('No instructions found for overriding the rate_limiter object.')

    def validate_and_save_persistence(self, state: dict) -> None:
        """Validates the new content of the persistence with Json and stores it

        :param state: New value of the persistence as dict instance
        :raises: AssertionError
        """
        self.log_debug(f'Validating the structure of the proposed new persistence: {state}')

        # Get the json schema to be used
        json_schema: dict = self.get_schema_from_file(
            file_name=self.collector_variables['persistence']['schema']
        )
        if not isinstance(json_schema, dict):
            raise AssertionError("Devo Collector SDK Rules violation: The persistence schema must be a dict instance")

        # Get the persistence version to be used and check if it is used
        persistence_version: int = self.collector_variables['persistence']['version']
        persistence_key: str = '@persistence_version'
        if 1 < persistence_version < 100:
            raise AssertionError(
                "Devo Collector SDK Rules violation: The persistence version is out of the allowed range: 1 to 99"
            )

        elif persistence_key not in state:
            state[persistence_key] = persistence_version

        elif state[persistence_key] != persistence_version:
            raise AssertionError(
                "IFC SDK Rules violation: The value of the <@persistence_version> field differs "
                "from the ones defined in the service metadata"
            )

        # Run the json schema validation
        try:
            validate(instance=state, schema=json_schema)
        except ValidationError as e:
            self.log_error(
                f"Invalid content detected in the proposed persistence: {e.message} | "
                f"Error in JSON-level {len(e.path) + 1} | "
                f"Value of state.{'.'.join(e.path) if len(e.path) != 0 else 'None'}"
            )
            raise AssertionError(
                "Devo Collector SDK Rules violation: "
                "The content of the proposed persistence does not meet the given JSON-Schema"
            )

        # Update the persistence
        self.log_info(f'Updating the persistence')
        self.persistence_object.save_state(state)

    @abc.abstractmethod
    def prepull_default_state(self, retrieving_ts: datetime) -> dict:
        """Returns the default value of the state

        This method aims to define an initial value for the
        persistence when it is not yet defined.
        Requirements:
        - Returns the initial value as dict instance.
        - The final dict cannot be empty.
        - The final dict content meets the PERSISTENCE_SCHEMA.
        - Use always log.info() logging level
        - Use PrePullError(200-219) as unique valid exception

        :param retrieving_ts: Date time the pull was triggered
        :returns: default value for the state as dict instance
        """
        return {"retrieving_ts": retrieving_ts}

    @abc.abstractmethod
    def prepull_persistence_upgrade_steps(self, **kwargs) -> dict:
        """Upgrade the persistence when needed

        This method aims to keep all methods used to upgrade and downgrade persistence
        data from previous / legacy versions.
        Requirements:
        - The stated is injected by reference and the final content should to be stored on it.
        - The final dict content meets the PERSISTENCE_SCHEMA.
        - Use log.info() as generic logging level and log.warning() when updating the state content
        - Use PrePullError(220-239) as unique valid exception

        :param kwargs:  -> default_state    dict        Default value for the state
                        -> state            dict        Current content of the state
                        -> retrieving_ts    datetime    Date time puller was triggered
        :returns: The final state object after applying changes.
        """

        return kwargs["state"]

    @abc.abstractmethod
    def prepull_persistence_corrections_steps(self, **kwargs) -> dict:
        """Modify the persistence when needed

        This method aims to keep all methods required to modify the persistence values based on the API
        or functional requirements.
        Requirements:
        - The stated is injected by reference and the final content should to be stored on it.
        - The final dict content meets the PERSISTENCE_SCHEMA.
        - Use log.info() as generic logging level and log.warning() when updating the state content
        - Use PrePullError(240-259) as unique valid exception

        :param kwargs:  -> default_state    dict        Default value for the state
                        -> state            dict        Current content of the state
                        -> retrieving_ts    datetime    Date time puller was triggered
        :returns: The final state object after applying changes.
        """

        return kwargs["state"]

    @abc.abstractmethod
    def prepull_persistence_reset_steps(self, **kwargs) -> dict:
        """Reset the persistence when needed

        This method aims to keep all methods required to reset the persistence based the config changes
        Requirements:
        - The stated is injected by reference and the final content should to be stored on it.
        - The final dict content meets the PERSISTENCE_SCHEMA.
        - Use log.info() as generic logging level and log.warning() when updating the state content
        - Use PrePullError(240-259) as unique valid exception

        :param kwargs:  -> default_state    dict        Default value for the state
                        -> state            dict        Current content of the state
                        -> retrieving_ts    datetime    Date time puller was triggered
        :returns: The final state object after applying changes.
        """

        return kwargs["state"]

    def prepull_build_extra_rate_limiters(self) -> None:
        """Create new extra rate limiters objects when needed

        :param kwargs:  -> default_state    dict        Default value for the state
                        -> state            dict        Current content of the state
                        -> retrieving_ts    datetime    Date time puller was triggered
        """
        pass

    def pull(self, retrieving_timestamp: datetime) -> None:
        """Pulls data and log the results

        This method aims to pull the data taking into consideration the following rules:
        - The events are not lost or duplicated, pay attention when pulling events ts >= or ts > and its implications
            - When ts >, decrement 1 µs/ms/s to the last received timestamp to force receiving duplicates
                and new possible events with the same timestamp that could be available after the previous call.
        - The events are ingested into Devo sorted by creation or update time
        - The pull does not end until the remote data is up-to-date
        - The final events should include the @devo_pulling_id
        - The code is scalable without compromising memory (Soft Limit 2.5 GB / Hard Limit 5 GB)
        - When the events come sorted from the remote:
            - Persist the last event retrieved to be used as base if the collector is restarted to avoid duplicates
        - When the events cannot come sorted from the remote:
            - Allow config the time window used, to fit it to the user infrastructure size
            - Do not persist anything until all time window events are collected and delivered
        - When the pagination is available:
            - A partial report is displayed after a bunch number of pages depending on the number of pages
            - Use temporal and final deduplication buffers in the persistence:
                {
                    'deduplication_buffer_ts: '',           <-- Used to detect duplications
                    'deduplication_buffer_items: [],        <-- Items with in risk of duplication
                    'deduplication_temp_buffer_ts: '',      <-- Temporal buffer of the last timestamp found
                    'deduplication_temp_buffer_items: ''    <-- Temporal buffer of items with the last timestamp
                }
        - A final report always displayed after pulling all pending data

        :param retrieving_timestamp: Timestamp pull was triggered
        """

        self.log_debug('Starting pull()')

        # Store retrieving_timestamp
        self.store_retrieving_timestamp(retrieving_timestamp=retrieving_timestamp)

        self.log_info("Pull Started")

        # Statistics
        statistics: dict = {
            'requests_made': 0,
            'events_received': 0,
            'events_filtered_out': 0,
            'events_sent': 0,
            'start_time': time.time()
        }

        retrieval_interrupted = False
        while not self.is_data_up_to_date():

            self.execute_pull_logic(statistics=statistics)
            self.display_pull_report(statistics, partial_report=True)
            if self.is_command_in_progress():
                self.log_warning(
                    f'Retrieving loop has been interrupted due to a controlled stopping action has been activated'
                )
                retrieval_interrupted = True
                break

        self.display_pull_report(statistics)

        if retrieval_interrupted is False:
            self.log_info("The data is up to date!")

        self.log_debug('Finalizing pull()')

    def display_pull_report(self, statistics: dict, partial_report=False) -> None:
        """Display the pull action statistics to the logging

        :param statistics: Injected statistics as dict instance
        :param partial_report: Defines if it is a full or a partial statistics

        """
        # Calculate elapsed and average of events per second
        elapsed_time: float = time.time() - statistics['start_time']
        if elapsed_time != 0:
            average: float = statistics['events_sent'] / elapsed_time
        else:
            average: float = 0.0

        _ = partial_report

        # Display
        msg: str = f"{'(Partial) ' if partial_report is True else ''}Statistics for this pull cycle " \
                   f"(@devo_pulling_id={self.collector_variables['devo_pulling_id']}):" \
                   f"Number of requests made: {statistics['requests_made']}; " \
                   f"Number of events received: {statistics['events_received']}; " \
                   f"Number of duplicated events filtered out: {statistics['events_filtered_out']}; " \
                   f"Number of events generated and sent: {statistics['events_sent']}; " \
                   f"Average of events per second: {average:.3f}."
        self.log_info(msg)

    @abc.abstractmethod
    def execute_pull_logic(self, statistics: dict) -> None:
        """Executes the pull logic of the collector the service

        :param statistics: Statistics as dict instance
        """

        pass

    @abc.abstractmethod
    def is_data_up_to_date(self) -> bool:
        """Check if when the data is up-to-date or not

        This method helps to determinate if all available remote data has been downloaded and the pull can be marked
        as completed. Sometimes this decision will be based on the retrieving_timestamp value and other times, a
        more complex logic should be implemented based on each API requirements or features.

        :returns:   True    When the data is up-to-date and the pull action can finish
                    False   When there is more data pending to be pulled and a new pulling cycle is needed
        """

        return True

    def deliver_batch_of_messages(
        self,
        msg_date: Union[datetime, str, int, float, None],
        msg_tag: str,
        list_of_messages: Union[list[str], list[dict]],
        skip_devo_pulling_id_verification=False,
    ) -> None:
        """Method that overrides the abstract one to include the devo_pull_id

        Method that send several messages to be consumed by the collector. Only str and dict formats are accepted
        as message payload. This override allows receiving a NULL msg_date and inject the devo_pulling_id by
        default only when msg is JSON.

        :param msg_date: an instance of datetime in UTC
        :param msg_tag: an instance of str with the final devo tag
        :param list_of_messages: a list instance of str and dict instances
        :param skip_devo_pulling_id_verification: a list instance of str and dict instances
        """

        # Force the retrieving_timestamp if no msg_date is provided
        if msg_date is None:
            msg_date: datetime = self.collector_variables['retrieving_timestamp']

        messages_ready_to_send: list[Message] = []

        for msg in list_of_messages:

            if isinstance(msg, dict):
                if self.obfuscation_data:
                    msg = ObfuscationUtils.process_json(msg, self.obfuscation_data)

                if self.environment:
                    msg['@devo_environment'] = self.environment

                msg['@devo_pulling_id'] = self.collector_variables['devo_pulling_id']
                msg_content = json.dumps(msg)

            elif isinstance(msg, str):
                if not skip_devo_pulling_id_verification and self.collector_variables['devo_pulling_id'] not in msg:
                    raise AssertionError(
                        f'Devo Collector SDK Rules violation: The message content should include the devo_pulling_id '
                        f'but it is not available in message: {msg}'
                    )
                msg_content = msg

            else:
                raise AssertionError(
                    f'Devo Collector SDK Rules violation: The message content should be <dict> or <str> '
                    f'type not <{type(msg)}>'
                )

            messages_ready_to_send.append(Message(msg_date, msg_tag, msg_content, is_internal=False))

        # Deliver all messages directly in the queue
        self.output_queue.put(messages_ready_to_send)

    def flatten_dict_key(self, target: dict, key_route: list[str]) -> list[dict]:
        """Returns an array with the flattened data based on the given key

        When the key_route returns an empty array the same event is returned as unique found entity.

        :param target: target data to be flattened as dict instance
        :param key_route: array with the route to the field to be flattened.
            To flatten the key 'events' from {"one": 1, "two": {"three": {"events": []}}} use ["two", "three", "events"]
        """

        self.validate_flattening_payloads(key_route, target)

        common_data: list = []
        flattened_data = []

        # Parse content and get the
        buffer: dict = deepcopy(target)
        array_to_be_flattened = self.parse_target_to_be_flattened(buffer, common_data, key_route)

        # Build the common part object
        common_data_dict = self.build_back_common_object(common_data, key_route)

        # Create prefix
        prefix: str = "_".join(key_route)

        # Create the final array with all flattened data
        if len(array_to_be_flattened) == 0:
            flattened_data = [
                {
                    **common_data_dict,
                    prefix: {},
                    f"{prefix}_found": len(array_to_be_flattened),
                    f"{prefix}_id": 0
                }
            ]
        else:
            counter = 0
            for item in array_to_be_flattened:
                # The item should be a valid dict instance
                if not isinstance(item, dict):
                    raise AssertionError(
                        f"Devo Collector SDK rules violation - "
                        f"Only dict instance are accepted as content of the list to be flattened, not "
                        f"{type(array_to_be_flattened)}. Context: {item}"
                    )
                counter += 1
                flattened_data.append(
                    {
                        **common_data_dict,
                        prefix: {**item},
                        f"{prefix}_found": len(array_to_be_flattened),
                        f"{prefix}_id": counter
                    }
                )

        return flattened_data

    @staticmethod
    def build_back_common_object(common_data: list[dict], key_route: list[str]) -> dict:
        """Builds back the common object from the common_data array content

        :param common_data: Array with the split content of the common object
        :param common_data: Empty array where all common dicts and arrays will be stored to build back the common object
        :param key_route: Pointer with the route to the field to be flattened.
        """
        common_data_dict: dict = {}

        # Build it back
        deep: int = len(key_route) - 1
        for x in key_route[::-1]:
            if deep == len(key_route) - 1:
                # First execution
                common_data_dict = common_data[deep]
            else:
                # Mix objects using the key route
                common_data_dict = {**common_data[deep], x: common_data_dict}
            deep -= 1

        return common_data_dict

    @staticmethod
    def parse_target_to_be_flattened(buffer: dict, common_data: list, key_route: list[str]) -> list[dict]:
        """Parse the target to be flattened and stores the common data based on the key_route pointer

        :param buffer: Initial content to be parsed, the first iteration contains the target payload
        :param common_data: Empty array where all common dicts and arrays will be stored to build back the common object
        :param key_route: Pointer with the route to the field to be flattened.
        """
        # Remove target field
        deep: int = 0
        for x in key_route:
            # Copy all but target key
            common_data.append({})
            for key, value in buffer.items():
                if x != key:
                    common_data[deep][key] = value

            # Get the target key and update deep
            buffer = buffer[x]
            deep += 1

        # The data to be flattened should be an array
        if not isinstance(buffer, list):
            raise AssertionError(
                f"Devo Collector SDK rules violation - "
                f"They field pointed by <key_route> {key_route} to be flattened should be a list not {type(buffer)}. "
                f"Context: {key_route}"
            )

        return buffer

    @staticmethod
    def validate_flattening_payloads(key_route: list[str], target: dict) -> None:
        """Validates the flattening payloads to meet the dev contract

        :param target: target data to be flattened as dict instance
        :param key_route: array with the route to the field to be flattened.
        """
        # Validate target payload
        if not isinstance(target, dict) or len(target) == 0:
            raise AssertionError(
                f"Devo Collector SDK rules violation - "
                f"The <target> to be flattened should be a dict instance and cannot be empty. Context: {target}"
            )
        # Validate key_route pyload
        if not isinstance(key_route, list) or len(key_route) == 0:
            raise AssertionError(
                f"Devo Collector SDK rules violation - "
                f"They <key_route> should be a list instance and cannot be empty. Context: {key_route}"
            )

    @abc.abstractmethod
    def pull_stop(self) -> None:
        """Stop action triggered by the parent thread"""
        pass

    @abc.abstractmethod
    def pull_pause(self, wait: bool = None) -> None:
        """Pause action triggered by the parent thread"""
        pass

