import logging
from multiprocessing import Process, Event

from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.object_statuses import ObjectStatuses
from devocollectorsdk.configuration.configuration import CollectorConfiguration
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue

log = logging.getLogger(__name__)
log_level = logging.INFO


class ManagementMultiprocessingController(Process):
    """
    This thread will be used as a collector manager
    """

    def __init__(self,
                 config: CollectorConfiguration,
                 output_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 main_wait_object: Event):
        """
        This class creates all input services in an isolated multiprocessing process.
        It is in charge of puller and setup instances.
        :param config: a CollectorConfiguration object.
        :param output_queue: an internal multiprocessing queue instance used for sending the standard messages.
        :param lookup_queue: an internal multiprocessing queue instance used for sending the lookup messages.
        :param main_wait_object: multiprocessing.Event() from parent process
        """
        super().__init__()

        self.__object_status = ObjectStatuses.INITIALIZING

        # Get the class and global properties
        self.name = self.__class__.__name__ + f"({CollectorUtils.collector_name})"
        self.log_debug = config.get_globals().get("debug", False)

        # Get the injected objects and create new if necessary
        self.output_queue: CollectorMultiprocessingQueue = output_queue
        self.lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.main_wait_object = main_wait_object

        self.running_flag: bool = True

        self.__object_status = ObjectStatuses.INITIALIZED

    def __activate_logging(self):
        """This method config the logging for this multiprocessing process"""
        global log_level

        if self.log_debug:
            log_level = logging.DEBUG

        logging.basicConfig(
            level=log_level,
            format='%(asctime)s.%(msecs)03d %(levelname)7s %(threadName)s -> %(message)s',
            datefmt='%Y-%m-%dT%H:%M:%S'
        )

    def run(self) -> None:
        """Once run() method is called, we can create objects in the new multiprocessing process"""
        self.__activate_logging()

    def stop_safely(self) -> None:
        """

        :return:
        """
        if log.isEnabledFor(logging.INFO):
            log_message = f'Stopping safely all nested running objects'
            log.info(log_message)

        self.running_flag = False

        if log.isEnabledFor(logging.INFO):
            log_message = f'Stopped safely all nested running objects'
            log.info(log_message)

    def get_status(self):
        return self.__object_status

    def is_ready_to_start(self) -> bool:
        if self.__object_status == ObjectStatuses.INITIALIZED:
            return True
        return False

