from enum import Enum


class Status(Enum):
    INITIALIZING = 0
    INITIALIZED = 1
    RUNNING = 2
    STOPPING_SAFELY = 3
    STOPPED = 4
