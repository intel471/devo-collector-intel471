import json
import logging
import threading
from collections import defaultdict
from typing import Optional

from devocollectorsdk.message.message import Message
from devocollectorsdk.persistence.emergency.exceptions.emergency_persistence_system_exception import \
    EmergencyPersistenceSystemException
from devocollectorsdk.persistence.persistence_service import PersistenceService
from devocollectorsdk.queues.content.collector_queue_item import CollectorQueueItem


log = logging.getLogger(__name__)


class EmergencyPersistenceSystem:

    def __init__(self, output_component_name: str):
        self.__output_component_name: str = output_component_name
        self.__items_persisted: int = 0
        self.__partial_items_persisted: int = 0
        self.__emergency_lock: threading.Lock = threading.Lock()
        self.__was_state_loaded: bool = False
        self.__current_state: Optional[defaultdict] = None

    @property
    def output_component_name(self) -> str:
        """

        :return:
        """
        return self.__output_component_name

    @property
    def items_persisted(self) -> int:
        """

        :return:
        """
        return self.__items_persisted

    def send(self, queue_item: CollectorQueueItem, persistence_object: PersistenceService) -> None:
        """

        :param queue_item:
        :param persistence_object
        :return:
        """

        self.__partial_items_persisted = queue_item.number_of_messages
        self.__items_persisted += self.__partial_items_persisted

        with self.__emergency_lock:

            if self.__was_state_loaded is False:
                state = persistence_object.load_state()

                if state is None:
                    state = defaultdict(list)

                self.__was_state_loaded = True
                self.__current_state = state

            self.__current_state['messages'].append(queue_item.to_dict())

            persistence_object.save_state(self.__current_state, no_log_traces=True, emergency_system_used=True)

    def load(
            self,
            persistence_object: PersistenceService,
            sender_manager_list
    ) -> None:
        """

        :param persistence_object:
        :param sender_manager_list
        :return:
        """

        with self.__emergency_lock:

            messages_retrieved: int = 0
            messages_to_send = []

            try:
                for message in self.__generate_persistence_messages(persistence_object):

                    content = json.loads(message['content'])

                    if isinstance(content, list):
                        item: CollectorQueueItem = CollectorQueueItem([Message(**m) for m in content])
                        messages_retrieved += item.number_of_messages
                        sender_manager_list.add_output_object(item)
                    else:
                        messages_to_send.append(Message(**content))

                if messages_to_send:
                    messages_retrieved += len(messages_to_send)
                    item: CollectorQueueItem = CollectorQueueItem(messages_to_send)
                    sender_manager_list.add_output_object(item)

                if messages_retrieved:
                    log.debug(
                        f'[EMERGENCY PERSISTENCE SYSTEM] '
                        f'{self.__output_component_name} -> retrieved {messages_retrieved} messages from persistence'
                    )

                    persistence_object.clean_state(emergency_system_used=True)

                    log.debug(
                        f'[EMERGENCY PERSISTENCE SYSTEM] '
                        f'{self.__output_component_name} -> persistence cleaned.'
                    )

            except Exception as e:
                raise EmergencyPersistenceSystemException(1, str(e))

    def __generate_persistence_messages(self, po):
        state = po.load_state(no_log_traces=True, emergency_system_used=True)

        if not state:
            log.info(
                f'[EMERGENCY PERSISTENCE SYSTEM] '
                f'{self.__output_component_name} -> Nothing retrieved from the persistence.'
            )
            return

        for message in state['messages']:
            yield message
