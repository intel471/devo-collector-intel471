import inspect
import logging
import threading

from devocollectorsdk.ratelimiter.collector_rate_limiter import CollectorRateLimiter

log = logging.getLogger(__name__)


class CollectorRateLimiterList:

    def __init__(self, rate_limiters: dict = None):

        if rate_limiters is None:
            rate_limiters = {}

        self.__rate_limiters: dict[str, CollectorRateLimiter] = rate_limiters.copy()
        self.__lock: threading.Lock = threading.Lock()

    def add_rate_limiters_from_list(self, rate_limiters: list) -> None:
        """

        :param rate_limiters:
        :return:
        """

        if rate_limiters:
            stack = inspect.stack()
            caller_class_name = stack[1].frame.f_locals['self'].name
            for rate_limit in rate_limiters:
                number_of_requests: int = rate_limit["number_of_requests"]
                if number_of_requests > 0:
                    self.__add_rate_limiter(
                        rate_limit["period"],
                        number_of_requests,
                        caller_class_name=caller_class_name
                    )

    def __add_rate_limiter(self, period: str, number_of_requests: int, caller_class_name: str = None):
        """

        :param period:
        :param number_of_requests:
        :param caller_class_name:
        :return:
        """

        with self.__lock:
            period_in_seconds: int = self.__calculate_period_in_seconds(period)
            new_rate_limiter: CollectorRateLimiter = \
                CollectorRateLimiter(
                    period_in_seconds,
                    number_of_requests,
                    caller_class_name=caller_class_name
                )

            if new_rate_limiter.name in self.__rate_limiters:
                log.warning(
                    f'A previous rate limiter with same "period_in_seconds" and "number_of requests" '
                    f'was already existing: "{period_in_seconds}/{number_of_requests}"'
                )
            else:
                self.__rate_limiters[new_rate_limiter.name] = new_rate_limiter
                if len(self.__rate_limiters) > 1:
                    self.__rate_limiters = {
                        k: v for k, v in sorted(
                            self.__rate_limiters.items(),
                            key=lambda item: (item[1].period_in_seconds, item[1].number_of_requests)
                        )
                    }
                log.debug(f'Added a new rate limiter: {str(new_rate_limiter)}')

    @staticmethod
    def __calculate_period_in_seconds(period: str) -> int:
        """

        :param period:
        :return:
        """

        seconds_per_unit = {
            "s": 1,
            "m": 60,
            "h": 3600,
            "d": 86400,
            "w": 604800,
            "M": 2592000,
            "y": 31536000
        }

        return int(period[:-1]) * seconds_per_unit[period[-1]]

    @property
    def rate_limiters(self):
        return self.__rate_limiters

    def _test_references(self, key: str, value: int):
        self.__rate_limiters[key]._test_reference(value)
