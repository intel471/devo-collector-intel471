"""
Consumes standard messages from the queue and sends them to output_standard_senders
"""
import json
import logging
import threading
from datetime import datetime
from queue import Empty
from threading import Thread
from typing import Optional

from devocollectorsdk.commons.non_active_reasons import NonActiveReasons
from devocollectorsdk.controllers.statuses.component_status import ComponentStatus
from devocollectorsdk.controllers.statuses.status_enum import StatusEnum
from devocollectorsdk.outputs.consumers.consumer_stats import ConsumerStats
from devocollectorsdk.persistence.emergency.exceptions.emergency_persistence_system_exception import \
    EmergencyPersistenceSystemException
from devocollectorsdk.outputs.output_sender_manager_list_standard import OutputSenderManagerListStandard
from devocollectorsdk.persistence.emergency.emergency_persistence_system import EmergencyPersistenceSystem
from devocollectorsdk.persistence.persistence_factory_manager import PersistenceFactoryManager
from devocollectorsdk.persistence.persistence_service import PersistenceService
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.queues.content.collector_queue_item import CollectorQueueItem
from devocollectorsdk.queues.one_to_many_communication_queue import OneToManyCommunicationQueue

log = logging.getLogger(__name__)


class OutputStandardConsumer(Thread):
    def __init__(
            self,
            group_name: str,
            consumer_identification: int,
            content_queue: CollectorMultiprocessingQueue,
            sender_manager_list: OutputSenderManagerListStandard,
            generate_collector_details: bool,
            persistence_factory_manager: PersistenceFactoryManager,
            output_controller_communication_channel: OneToManyCommunicationQueue = None,
            output_controller_instance=None
    ):

        super().__init__()
        self.name = self.__class__.__name__ + f"({group_name}_consumer_{consumer_identification})"

        self.output_controller_communication_channel: OneToManyCommunicationQueue = \
            output_controller_communication_channel
        self.output_controller_instance = output_controller_instance

        self.__content_queue: CollectorMultiprocessingQueue = content_queue
        self.__sender_manager_list: OutputSenderManagerListStandard = sender_manager_list
        self.__generate_collector_details: bool = generate_collector_details

        # Variables related to run/pause/stop statuses
        self.__command_execution_lock: threading.Lock = threading.Lock()

        self.__thread_waiting_object: threading.Event = threading.Event()
        self.__component_status: ComponentStatus = ComponentStatus(self.name)
        self.__non_active_reason: Optional[str] = None

        self.__pause_thread: bool = False
        self.__wait_object_for_pause_run: threading.Event = threading.Event()
        self.__wait_object_for_pause_method: threading.Event = threading.Event()
        self.__wait_object_for_unpause_method: threading.Event = threading.Event()
        self.__thread_is_paused: bool = False

        self.__stop_thread: bool = False
        self.__wait_object_for_stop_method: threading.Event = threading.Event()
        self.__thread_is_stopped: bool = False

        self.__flush_to_persistence_system: bool = False
        self.__wait_object_for_flush_method: threading.Event = threading.Event()
        self.__consumer_has_been_flushed: bool = False

        self.__emergency_persistence_system: EmergencyPersistenceSystem = EmergencyPersistenceSystem(self.name)
        self.persistence_manager: PersistenceFactoryManager = persistence_factory_manager
        self.persistence_object: PersistenceService = self.__create_persistence_service()

        self.__last_stats_shown_timestamp: Optional[datetime] = None
        self.__stats: ConsumerStats = ConsumerStats()

        self.__check_last_execution_messages: bool = True
        self.__is_consumer_able_to_consume: bool = False

        self.__running_flag: bool = True

    SUPPORTED_QUEUE_ITEMS: [str] = ['standard', 'batch']

    def run(self) -> None:
        """

        :return:
        """

        self.__last_stats_shown_timestamp = datetime.utcnow()
        self.__component_status.status = StatusEnum.RUNNING

        while self.__running_flag is True:

            if self.__check_last_execution_messages is True:
                self.__send_messages_from_last_execution()

            self.__wait_doing_nothing()

            if self.__is_consumer_able_to_consume is True:
                self.__consume_and_send_to_sender_manager_list()

            self.__check_if_pause()

            self.__check_if_flush()

            self.__check_if_stop()

        log.debug('Finalizing thread')

        self.__thread_is_stopped = True
        self.__component_status.status = StatusEnum.STOPPED

        if self.__wait_object_for_stop_method.is_set() is False:
            self.__wait_object_for_stop_method.set()

    def __send_messages_from_last_execution(self):
        with self.__command_execution_lock:

            try:
                self.__emergency_persistence_system.load(self.persistence_object, self.__sender_manager_list)
            except EmergencyPersistenceSystemException as e:
                log.error(f"{str(e)}")

            self.__check_last_execution_messages = False
            self.__is_consumer_able_to_consume = True

    def __wait_doing_nothing(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is False \
                and self.__stop_thread is False \
                and self.__flush_to_persistence_system is False \
                and self.__consumer_has_been_flushed is True:

            log.debug("Entering in wait status (doing_nothing)")
            called: bool = self.__thread_waiting_object.wait(timeout=60)
            if called is True:
                self.__thread_waiting_object.clear()
            log.debug("Waking up from wait status (doing_nothing)")

    def __consume_and_send_to_sender_manager_list(self) -> None:
        """

        :return:
        """

        if self.__consumer_has_been_flushed is False:
            start_time_local: Optional[datetime] = None
            try:

                queue_item: CollectorQueueItem = self.__content_queue.get(timeout=5)

                if queue_item:

                    self.__stats.increase_message_counter(size_in_bytes=queue_item.size_in_bytes)

                    if queue_item.type not in self.SUPPORTED_QUEUE_ITEMS:
                        # Don't process events from not supported queue item types
                        log.warning(
                            f'A queue item has been ignored due to the type {queue_item.type} is not '
                            f'supported by this consumer/queue -> {queue_item}'
                        )
                    else:

                        if self.__generate_collector_details:
                            start_time_local = datetime.utcnow()

                        sender_statuses = self.__sender_manager_list.add_output_object(queue_item)

                        # Forcing the deleting object once it has been used
                        del queue_item

                        if self.__generate_collector_details and sender_statuses:
                            elapsed_seconds_adding_to_sender = \
                                (datetime.utcnow() - start_time_local).total_seconds()
                            if elapsed_seconds_adding_to_sender > 1:
                                log.debug(
                                    f"elapsed_seconds_adding_to_sender: {elapsed_seconds_adding_to_sender}, "
                                    f"{sender_statuses}"
                                )
                else:
                    log.error("'NoneType' object received when retrieving data from the queue")

                self.__content_queue.task_done()

                now = datetime.utcnow()
                last_stats_shown_difference_in_seconds = (now - self.__last_stats_shown_timestamp).total_seconds()
                if last_stats_shown_difference_in_seconds > 60:
                    self.__last_stats_shown_timestamp = now
                    message_counters, messages_size_in_bytes = self.__stats.get_stats()
                    log.info(
                        f'Consumed messages: {message_counters}, '
                        f'total_bytes: {messages_size_in_bytes} '
                        f'({last_stats_shown_difference_in_seconds} seconds)'
                    )

            except Empty:
                # This exception will be raised when no new message arrives in "timeout" value
                # log.debug(f'It seems that the queue is empty')
                pass

    def __check_if_flush(self) -> None:
        """

        :return:
        """

        if self.__flush_to_persistence_system is True:
            self.__component_status.status = StatusEnum.FLUSHING
            log.info('Flushing thread')

            self.__flush_to_persistence_system = False

            start_time = datetime.utcnow()
            while self.__content_queue.is_closed_and_empty() is False:
                try:
                    queue_item: CollectorQueueItem = self.__content_queue.get(timeout=1)
                    if queue_item:
                        self.__emergency_persistence_system.send(queue_item, self.persistence_object)
                    self.__content_queue.task_done()
                except Empty:
                    log.debug(f'It seems that queue is empty')

            self.__consumer_has_been_flushed = True
            self.__component_status.status = StatusEnum.FLUSHED

            elapsed_time_in_seconds: float = (datetime.utcnow() - start_time).total_seconds()
            log.debug(
                f'[EMERGENCY PERSISTENCE SYSTEM] '
                f'{self.__emergency_persistence_system.output_component_name} '
                f'Persisted {self.__emergency_persistence_system.items_persisted} items '
                f'(elapsed_seconds: {elapsed_time_in_seconds:.3f})'
            )

            if self.__wait_object_for_flush_method.is_set() is False:
                self.__wait_object_for_flush_method.set()

            log.info(
                f'Thread has been totally flushed '
                f'({self.__emergency_persistence_system.items_persisted})'
            )

    def __create_persistence_service(self):
        """

        :param submodule_name:
        :return:
        """

        persistence_address: str = f"{self.name}"
        persistence_service = self.persistence_manager.get_instance_for_unique_id(persistence_address)
        return persistence_service

    def __check_if_pause(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is True:
            self.__component_status.status = StatusEnum.PAUSING

            log.debug(f'Pausing consumer')

            self.__thread_is_paused = True
            self.__pause_thread = False

            if self.__non_active_reason == NonActiveReasons.FINAL_SENDER_IS_NOT_WORKING:
                self.__component_status.status = StatusEnum.PAUSED_FAILING
            else:
                self.__component_status.status = StatusEnum.PAUSED

            log.info(
                f'Consumer has been put in pause status, '
                f'reason: "{self.__non_active_reason}", '
                f'status: {self.__component_status.status}'
            )

            self.__wait_in_pause_status()

            self.__thread_is_paused = False

            log.info("Consumer has exited from pause status")

    def __wait_in_pause_status(self) -> None:
        """

        :return:
        """

        if self.__wait_object_for_pause_method.is_set() is False:
            self.__wait_object_for_pause_method.set()

        if self.__wait_object_for_pause_run.is_set() is True:
            self.__wait_object_for_pause_run.clear()
        called: bool = self.__wait_object_for_pause_run.wait()
        if called is True:
            self.__wait_object_for_pause_run.clear()

    def __check_if_stop(self) -> None:
        """

        :return:
        """

        if self.__stop_thread is True:
            self.__component_status.status = StatusEnum.STOPPING

            log.debug(f'Stopping consumer')

            self.__running_flag = False
            self.__stop_thread = False

    def start(self) -> None:
        """

        :return:
        """
        super().start()

    def stop(self) -> None:
        """

        :return:
        """

        with self.__command_execution_lock:

            if self.__consumer_has_been_flushed is False:

                log.warning(f"{self.name} -> Has not been totally flushed, waiting until it finish")

                while self.__consumer_has_been_flushed is False:

                    log.debug(f'{self.name} -> Waiting to be flushed')

                    called: bool = self.__wait_object_for_flush_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_flush_method.clear()

                log.debug(f'{self.name} -> Flushed')

            log.debug(f'{self.name} -> Stopping')

            self.__non_active_reason = NonActiveReasons.STOP_COMMAND_RECEIVED
            self.__stop_thread = True

            if self.__thread_waiting_object.is_set() is False:
                self.__thread_waiting_object.set()

            if self.__wait_object_for_pause_run.is_set() is False:
                self.__wait_object_for_pause_run.set()

            if self.__wait_object_for_stop_method.is_set() is True:
                self.__wait_object_for_stop_method.clear()

            while self.__thread_is_stopped is False:

                log.debug(f'{self.name} -> Waiting to be stopped')

                called: bool = self.__wait_object_for_stop_method.wait(timeout=10)
                if called is True:
                    self.__wait_object_for_stop_method.clear()

            log.debug(f'{self.name} -> Thread has been stopped')

    def pause(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_execution_lock:

            log.info(f'{self.name} -> Pausing current thread (wait={wait})')

            if self.__thread_is_paused is True:
                log.info(f'Thread is already in pause status')
                return

            self.__non_active_reason = NonActiveReasons.PAUSE_COMMAND_RECEIVED
            self.__pause_thread = True

            log.debug(f'{self.name} -> Current object status:{str(self)}')

            if wait is True:

                if self.__wait_object_for_pause_method.is_set() is True:
                    self.__wait_object_for_pause_method.clear()

                while self.__thread_is_paused is False:

                    log.debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_pause_method.clear()

                log.debug(f'{self.name} -> Thread has been paused after waiting (sync)')

            else:

                log.debug(f'{self.name} -> Thread has been paused without waiting phase (async)')

    def flush_to_emergency_persistence_system(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_execution_lock:

            if self.__thread_is_paused is False:

                log.warning(f"{self.name} -> Is not in pause status, waiting first to be paused")
                log.debug(f'{self.name} -> Current object status:{str(self)}')

                while self.__thread_is_paused is False:

                    log.debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        log.debug(
                            f'flush_to_emergency_persistence_system::__wait_object_for_pause_method has been called'
                        )
                        self.__wait_object_for_pause_method.clear()

            self.__flush_to_persistence_system = True

            log.info(f'{self.name} -> Enabling flushing mechanism (wait={wait})')

            self.__non_active_reason = NonActiveReasons.FLUSH_COMMAND_RECEIVED
            # self.__pause_thread = False

            if self.__wait_object_for_pause_run.is_set() is False:
                self.__wait_object_for_pause_run.set()

            # while self.__thread_is_paused is True:
            #     log.debug(f'{self.name} -> Waiting to be un-paused')
            #     called: bool = self.__wait_object_for_unpause_method.wait(timeout=10)
            #     if called is True:
            #         self.__wait_object_for_unpause_method.clear()

            log.debug(f'{self.name} -> Starting to flush the queue')

            if wait is True:

                while self.__consumer_has_been_flushed is False:

                    log.debug(f'{self.name} -> Waiting to be flushed')

                    called: bool = self.__wait_object_for_flush_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_flush_method.clear()

                log.info(f'{self.name} -> Thread has been flushed (sync)')

            else:

                log.debug(f'{self.name} -> Thread has been put in flushing mode without waiting phase (async)')

    def wake_up(self) -> None:
        """

        :return:
        """

        if self.__thread_waiting_object.is_set() is False:
            self.__thread_waiting_object.set()

    def __str__(self) -> str:
        """

        :return:
        """

        return json.dumps(self.get_summary_status())

    def get_summary_status(self) -> dict:
        """

        :return:
        """

        status: dict = {
            "name": self.name,
            "status": str(self.__component_status.status),
            "non_active_reason": self.__non_active_reason,
            "is_pausing": self.__pause_thread,
            "is_paused": self.__thread_is_paused,
            "is_flushing": self.__flush_to_persistence_system,
            "is_flushed": self.__consumer_has_been_flushed,
            "is_stopping": self.__stop_thread,
            "is_stopped": self.__thread_is_stopped
        }
        return status
