from typing import Any, Optional

from devocollectorsdk.commons.collector_exceptions import SdkSyslogSenderManagerError
from devocollectorsdk.outputs.senders.abstracts.senders_abstract import SendersAbstract, SenderType
from devocollectorsdk.outputs.senders.syslog_sender import SyslogSender


class SyslogSenders(SendersAbstract):
    """ Senders Abstraction for Syslog """

    def __init__(self, **kwargs: Optional[Any]):
        """
        Builder
        :param kwargs:  -> group_name   (str)   Group name
                        -> output_name  (str)   Name of the related output
        """
        super().__init__(**kwargs)

    def get_next_sender(self, **kwargs: Optional[Any]) -> SenderType:
        """
        Method that returns the next sender to be used by the manager.
        :param kwargs: Arguments compatibility with all abstractions.
        :return: An instance of a sender.
        :raise: SdkSyslogSenderManagerError when there is no sender available.
        """
        if len(self._senders) > 0:

            # Get the next sender
            sender: SyslogSender = self._senders[self._next_sender_index]

            # Update the next sender id
            self._next_sender_index += 1
            if self._next_sender_index == len(self._senders):
                self._next_sender_index = 0

            return sender

        raise SdkSyslogSenderManagerError(1001, 'No <sender> instances available on this obj repository')
