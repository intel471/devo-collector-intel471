import ctypes
import logging
import multiprocessing
from multiprocessing.connection import Connection
from threading import Thread
from typing import Optional

import psutil

from devocollectorsdk.collectordefinitions.collector_definitions import CollectorDefinitions
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.configuration.configuration import CollectorConfiguration
from devocollectorsdk.controllers.multiprocessing.output_controller_process import OutputMultiprocessingController
from devocollectorsdk.controllers.statuses.component_status import ComponentStatus
from devocollectorsdk.controllers.statuses.status_enum import StatusEnum
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.queues.communication_queue import CommunicationQueue
from devocollectorsdk.queues.content.collector_notification import CollectorNotification
from devocollectorsdk.queues.content.communication_queue_order import CommunicationQueueOrder

log = logging.getLogger(__name__)


class OutputControllerThread(Thread):
    """
    This controller would act as a wrapper of the system process that is behind the real output
    """

    def __init__(self,
                 collector_thread_instance,
                 production_mode: bool,
                 config: CollectorConfiguration,
                 definitions: CollectorDefinitions,
                 standard_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 internal_queue: CollectorMultiprocessingQueue,
                 collector_command_queue: CommunicationQueue):
        """

        :param collector_thread_instance:
        :param config:
        :param standard_queue:
        :param lookup_queue:
        :param internal_queue:
        :param collector_command_queue:
        """
        super().__init__()

        self.name = self.__class__.__name__

        wait_object: multiprocessing.Event = multiprocessing.Event()
        self.__stop_controller_thread: multiprocessing.Value = multiprocessing.Value(ctypes.c_bool, False)

        # Object to be used as communication channel between Output process and Output thread
        communication_channel_with_output_process, controller_commands_remote = multiprocessing.Pipe()
        communication_channel_with_output_process: Connection
        controller_commands_remote: Connection

        # Output Controller
        output_controller_process: OutputMultiprocessingController = \
            OutputMultiprocessingController(
                config,
                definitions,
                standard_queue,
                lookup_queue,
                internal_queue,
                controller_thread_wait_object=wait_object,
                controller_commands_connection=controller_commands_remote
            )

        self.__collector_instance = collector_thread_instance
        self.__collector_command_queue: CommunicationQueue = collector_command_queue

        self.__controller_thread_wait_object: multiprocessing.Event() = wait_object
        self.__output_controller_process: OutputMultiprocessingController = output_controller_process
        self.__controller_commands_local: Connection = communication_channel_with_output_process

        # This variable, most probably, will not be used
        self.__controller_commands_remote: Connection = controller_commands_remote

        self.__running_flag: bool = True

        self.__component_status: ComponentStatus = ComponentStatus(self.name)

    def start(self) -> None:
        """

        :return:
        """
        self.__output_controller_process.start()
        super().start()

    def stop(self) -> None:
        """

        :return:
        """
        self.__running_flag = False
        self.wake_up()

    def run(self) -> None:
        """

        :return:
        """
        while self.__running_flag:

            self.__component_status.status = StatusEnum.RUNNING

            log.debug("Entering in wait status")
            called: bool = self.__controller_thread_wait_object.wait()
            if called:
                self.__controller_thread_wait_object.clear()
            log.debug("Waking up from wait status")

            if self.__stop_controller_thread.value is True:
                self.__running_flag = False
                continue

            self.__check_pending_orders()

            self.__check_pending_notifications()

        log.info(f'Finalizing thread, waiting to dependent process to die')
        self.__output_controller_process.join()

        log.info(f'[EXIT] Process "{self.__output_controller_process.name}" completely terminated')

        self.__collector_instance.wake_up()
        log.info("Thread finalized")

    def __check_pending_notifications(self) -> None:
        """

        :return:
        """

        notification_sent: bool = False
        while self.__controller_commands_local.poll():
            notification: CollectorNotification = self.__controller_commands_local.recv()
            log.debug(
                f'Notification received from OutputProcess, '
                f'it will be sent to the CollectorThread: {notification}')
            self.__collector_command_queue.send_notification(notification)
            notification_sent = True

        if notification_sent is True:
            self.__collector_instance.wake_up()

    def __check_pending_orders(self) -> None:
        """

        :return:
        """

        order_sent: bool = False
        while self.__collector_command_queue.has_pending_orders():
            collector_order: CommunicationQueueOrder = self.__collector_command_queue.get_order()
            log.debug(
                f'Order received from CollectorThread, '
                f'it will be sent to the OutputProcess: {collector_order}'
            )
            self.__controller_commands_local.send(collector_order)
            order_sent = True

        if order_sent is True:
            self.__output_controller_process.wake_up()

    def wake_up(self) -> None:
        """

        :return:
        """
        if self.__controller_thread_wait_object.is_set() is False:
            self.__controller_thread_wait_object.set()

    def get_status(self) -> ComponentStatus:
        """

        :return:
        """
        return self.__component_status

    def get_summary_status(self) -> dict:
        """

        :return:
        """

        output_pid = self.__output_controller_process.pid
        process_status: str = "Does not exists"
        process_num_threads: Optional[int] = None
        process_memory_info: Optional[list] = None
        if psutil.pid_exists(output_pid):
            process = psutil.Process(pid=output_pid)
            with process.oneshot():
                process_status = process.status()
                process_num_threads = process.num_threads()
                process_memory_info = process.memory_info()

        status: dict = {
            "running_flag": self.__running_flag,
            "status": str(self.__component_status.status),
            "underlying_process": {
                "process_id": output_pid,
                "process_status": process_status,
                "num_threads": process_num_threads,
                "memory_info": CollectorUtils.memory_info_to_human_dict(process_memory_info),
                "exit_code": self.__output_controller_process.exitcode
            }
        }
        return status
