import copy
import json
import re
from typing import Union, List, Dict, Optional

from glom import assign, glom, PathAccessError, PathAssignError

from devocollectorsdk.commons.collector_exceptions import SdkObfuscationError


class ObfuscationUtils:

    _default_mask_values = {
        'boolean': False,
        'string': '****SANITIZED****',
        'integer': -1,
        'float': -1.0,
        'string_pattern': None
    }

    @classmethod
    def process_json(
            cls,
            data_to_process: Union[str, dict],
            keys: List[Dict],
            as_str: bool = False,
            custom_mask_values: dict =None,
            check_types: bool = True
    ) -> Union[str, dict]:

        """This method is in charge of obfuscate sensitive data inside a json object given a list of keys.

        :param data_to_process: original data, could be a dict or a str
        :param keys: a list of keys to build the path where we can find the data to obfuscate
        :param as_str: indicates format of the return value. By default, dict
        :param custom_mask_values: values given by the user to be used in the obfuscation process.
        :param check_types: Check the type of the value to be used.
        :return: dict or str
        """

        mask_values: dict = cls.get_default_mask_values()

        if custom_mask_values is not None:
            mask_values.update(custom_mask_values)

        if isinstance(data_to_process, str):
            try:
                data_to_process: dict = json.loads(data_to_process)
            except Exception as e:
                raise SdkObfuscationError(
                    1205,
                    f'An error occurred trying to convert str to json. Error {e}.'
                )

        for list_of_keys in keys:

            keys_name: list = list_of_keys['name']
            string_patterns: Optional[list] = list_of_keys.get('string_patterns')
            value: Union[int, float, str, bool, None] = list_of_keys.get('value')

            iterations: int = keys_name.count('*')

            paths: list = []

            if iterations == 0:

                cls.get_obfuscation_type_and_assign(
                    data_to_process,
                    '.'.join(keys_name),
                    mask_values,
                    check_types,
                    string_patterns,
                    value
                )
                continue

            elif keys_name[0] == '*':

                iterations -= 1

                for key in data_to_process.keys():
                    current_path: str = '.'.join(keys_name).replace('*', key, 1)

                    if '*' not in current_path:
                        cls.get_obfuscation_type_and_assign(data_to_process, current_path, mask_values, check_types,
                                                            string_patterns, value)
                    else:
                        paths.append(current_path)

                if not paths:
                    continue

            else:
                initial_path: str = '.'.join(keys_name).split('.*')[0]
                last_key: str = '.'.join(keys_name).split('.*')[1].replace('.', '')

            for key in range(iterations):

                if not paths:

                    first_level: dict = cls.get_dict_from_path(data_to_process, initial_path)

                    if isinstance(first_level, list):
                        for i, data in enumerate(first_level):
                            for k in data.keys():
                                if last_key:
                                    if k == last_key:
                                        cls.get_obfuscation_type_and_assign(
                                            data_to_process,
                                            f'{initial_path}.{i}.{k}',
                                            mask_values,
                                            check_types,
                                            user_value=value
                                        )
                                else:
                                    cls.get_obfuscation_type_and_assign(
                                        data_to_process,
                                        f'{initial_path}.{i}.{k}',
                                        mask_values,
                                        check_types,
                                        user_value=value
                                    )
                        continue

                    for item in first_level.keys():
                        path: str = '.'.join(keys_name).replace('*', item, 1)

                        if '*' not in path:
                            cls.get_obfuscation_type_and_assign(data_to_process, path, mask_values, check_types,
                                                                string_patterns, value)

                        elif path not in paths:
                            paths.append(path)
                else:

                    aux: list = []

                    for path in paths[:]:
                        index: int = path.find('.*')
                        new_path: str = path[:index]

                        current_level: dict = cls.get_dict_from_path(data_to_process, new_path)

                        for current_key in current_level.keys():
                            new_path: str = path.replace('*', current_key, 1)

                            if '*' not in new_path:
                                cls.get_obfuscation_type_and_assign(data_to_process, new_path, mask_values, check_types,
                                                                    string_patterns, value)
                            elif new_path not in paths:
                                aux.append(new_path)

                    paths: list = copy.deepcopy(aux)

        if as_str:
            return json.dumps(data_to_process)

        return data_to_process

    @classmethod
    def get_default_mask_values(cls) -> dict:
        return cls._default_mask_values

    @classmethod
    def get_obfuscation_type_and_assign(
            cls,
            data: dict,
            path: str,
            mask: dict,
            check_types: bool,
            patterns: Optional[list] = None,
            user_value: Union[int, float, str, bool, None] = None):
        try:
            value = glom(data, path)
        except PathAccessError as e:
            raise SdkObfuscationError(
                1200,
                f'Error accessing to path: {path}. Error: {str(e)}'
            )

        if isinstance(value, str):

            final_value = user_value if user_value else mask['string']

            cls.check_type_and_throw_exception(value, final_value, check_types)

            if not mask.get('string_pattern') and not patterns:
                cls.assign_value_to_dict(data, path, final_value)

            else:
                regex_pattern = patterns if patterns else mask['string_pattern']

                for string_pattern in regex_pattern:
                    result: list = re.findall(string_pattern, value)

                    if result:
                        value = re.sub(''.join(result), final_value, value)

                cls.assign_value_to_dict(data, path, value)

        elif type(value) is int:

            final_value = user_value if user_value else mask['integer']

            cls.check_type_and_throw_exception(value, final_value, check_types)
            cls.assign_value_to_dict(data, path, final_value)

        elif isinstance(value, float):

            final_value = user_value if user_value else mask['float']

            cls.check_type_and_throw_exception(value, final_value, check_types)
            cls.assign_value_to_dict(data, path, final_value)

        elif type(value) is bool:

            final_value = user_value if user_value else mask['boolean']

            cls.check_type_and_throw_exception(value, final_value, check_types)
            cls.assign_value_to_dict(data, path, final_value)

        else:
            raise SdkObfuscationError(
                1202,
                f'Invalid type: {type(value)}. {value} should be one of these types: str, int, float, bool.'
            )

    @staticmethod
    def check_type_and_throw_exception(value, given_value, check_types):
        if check_types:
            if type(given_value) != type(value):
                raise SdkObfuscationError(
                    1201,
                    f'<{given_value}> should be of same type as <{value}>. {type(given_value)} != {type(value)}'
                )

    @staticmethod
    def get_dict_from_path(data: dict, path: str) -> dict:
        try:
            result_dict: dict = glom(data, path)
        except PathAccessError as e:
            raise SdkObfuscationError(
                1203,
                f'Error accessing to path: {path}. Error: {str(e)}'
            )

        return result_dict

    @staticmethod
    def assign_value_to_dict(data_dict, data_path, value):
        try:
            assign(data_dict, data_path, value)
        except PathAssignError as e:
            raise SdkObfuscationError(
                1204,
                f'Error assigning value: {value} to path: {data_path}. Error: {str(e)}'
            )
