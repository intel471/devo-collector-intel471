import hashlib
import json
import logging
import os
import pickle
from datetime import datetime

from devocollectorsdk.persistence.persistence_service import PersistenceService
from devocollectorsdk.commons.collector_exceptions import SdkPersistenceFactoryError, SdkPersistenceServiceError

log = logging.getLogger(__name__)


class FilesystemPersistenceService(PersistenceService):

    def __init__(self, directory_base: str, collector_id: str, unique_identifier: str) -> None:
        super().__init__(collector_id, unique_identifier)
        if directory_base is None:
            raise SdkPersistenceFactoryError(
                1,
                f"Directory name property is not valid, value: {directory_base}"
            )

        self.credentials_filename_absolute_path = directory_base
        if os.path.isabs(self.credentials_filename_absolute_path) is False:
            self.credentials_filename_absolute_path = \
                os.path.join(os.getcwd(), self.credentials_filename_absolute_path)

        if self.use_old_format:
            filename_hash = hashlib.md5(unique_identifier.encode("utf-8"))
            self.filename_path = \
                os.path.abspath(os.path.join(self.credentials_filename_absolute_path, filename_hash.hexdigest()))
        else:
            filename_hash = unique_identifier + ".json"
            self.filename_path = \
                os.path.abspath(os.path.join(self.credentials_filename_absolute_path, collector_id, filename_hash))

        if not os.path.isdir(os.path.dirname(self.filename_path)):
            os.makedirs(os.path.dirname(self.filename_path))
        try:
            open(self.filename_path, 'a').close()
        except Exception as ex:
            raise SdkPersistenceFactoryError(
                2,
                f'Problems with persistence file "{self.filename_path}", details: {ex}'
            )
        self.last_known_state = None
        self.__show_save_logs: bool = True

    def _save_state(self, object_to_save: dict, no_log_traces: bool, emergency_system_used: bool):
        file_mode = "w"
        if self.use_old_format:
            file_mode = "wb"
        file_object = open(self.filename_path, mode=file_mode)
        try:
            if self.use_old_format:
                pickle.dump(object_to_save, file_object, pickle.HIGHEST_PROTOCOL)
            else:
                json.dump(object_to_save, file_object)
            file_object.close()
            self.last_known_state = object_to_save
            self._last_persisted_timestamp = datetime.now()
            if no_log_traces is False:
                log.debug("{} -> State saved: {}".format(type(self).__name__, self.last_known_state))

            if emergency_system_used:
                if self.__show_save_logs:
                    log.debug("[EMERGENCY PERSISTENCE SYSTEM] {} -> Saving state".format(type(self).__name__))
                    self.__show_save_logs = False

                self._emergency_system_save_timestamp = datetime.now()

        except Exception as ex:
            if no_log_traces is False or (
                    emergency_system_used is True and self._emergency_system_save_timestamp is None
            ):
                log.debug(f"{type(self).__name__} -> Nothing saved to persistence state object")
            raise SdkPersistenceServiceError(
                1, str(ex)
            )

    def _load_state(self, no_log_traces: bool, emergency_system_used: bool) -> dict:
        file_mode = "r"
        if self.use_old_format:
            file_mode = "rb"
        file_object = open(self.filename_path, mode=file_mode)
        try:
            if self.use_old_format:
                object_loaded = pickle.load(file_object)
            else:
                object_loaded = json.load(file_object)
            file_object.close()
            self.last_known_state = object_loaded
            if no_log_traces is False:
                log.debug("{} -> State loaded: {}".format(type(self).__name__, self.last_known_state))
            if emergency_system_used:
                log.debug("[EMERGENCY PERSISTENCE SYSTEM] {} -> State loaded".format(type(self).__name__))
                self._emergency_system_load_timestamp = datetime.now()
            return object_loaded
        except Exception:
            if no_log_traces is False and (
                    emergency_system_used is False or self._emergency_system_load_timestamp is None
            ):
                log.debug(f"{type(self).__name__} -> Nothing read from persistence state object")

    def _load_state_old_format(self, no_log_traces: bool, unique_identifier, emergency_system_used: bool) -> dict:
        if unique_identifier:
            filename_hash = hashlib.md5(unique_identifier.encode("utf-8"))
            filename_path = \
                os.path.abspath(os.path.join(self.credentials_filename_absolute_path, filename_hash.hexdigest()))
        else:
            filename_path = self.filename_path

        file_object = open(filename_path, mode="rb")
        try:
            object_loaded = pickle.load(file_object)
            file_object.close()
            self.last_known_state = object_loaded
            if no_log_traces is False:
                log.debug("{} -> State loaded: {}".format(type(self).__name__, self.last_known_state))
            if emergency_system_used:
                log.debug("[EMERGENCY PERSISTENCE SYSTEM] {} -> State loaded".format(type(self).__name__))
                self._emergency_system_load_timestamp = datetime.now()
            return object_loaded
        except Exception:
            if no_log_traces is False and (
                    emergency_system_used is False or self._emergency_system_load_timestamp is None
            ):
                log.debug(f"{type(self).__name__} -> Nothing read from persistence state object")

    def _is_ok(self) -> bool:
        if os.path.exists(self.filename_path) and os.path.isfile(self.filename_path):
            return os.access(self.filename_path, os.W_OK)
        return False

    def __str__(self):
        return \
            f'{{' \
            f'"unique_identifier": {self.unique_identifier}, ' \
            f'"class": "{type(self).__name__}", ' \
            f'"filename_path": {self.filename_path}, ' \
            f'"last_known_state": {self.last_known_state}, ' \
            f'"emergency_system_save_timestamp": {self._emergency_system_save_timestamp}, ' \
            f'"emergency_system_load_timestamp": {self._emergency_system_load_timestamp}, ' \
            f'"emergency_system_clean_timestamp": {self._emergency_system_clean_timestamp}, ' \
            f'}}'

    def _clean_state(self, no_log_traces: bool, emergency_system_used: bool):
        file_mode = "w"
        if self.use_old_format:
            file_mode = "wb"
        try:
            state_file = open(self.filename_path, file_mode)
            state_file.close()

            if no_log_traces is False:
                log.debug("{} -> State cleaned".format(type(self).__name__))
            if emergency_system_used:
                self._emergency_system_clean_timestamp = datetime.now()
        except Exception as ex:
            if no_log_traces is False or (
                    emergency_system_used is True and self._emergency_system_clean_timestamp is None
            ):
                log.debug(f"{type(self).__name__} -> Nothing deleted from persistence state object")
            raise SdkPersistenceServiceError(
                4, str(ex)
            )
