from enum import Enum


class StatusEnum(Enum):
    UNKNOWN = 0
    RUNNING = 10
    PAUSING = 20
    PAUSED_FAILING = 30
    PAUSED = 40
    FLUSHING = 50
    FLUSHED = 60
    STOPPING = 70
    STOPPED = 80

    def __str__(self) -> str:
        return f'{self.name}({self.value})'
