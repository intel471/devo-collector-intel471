import json
import logging
import sys
import threading
import time
from abc import abstractmethod, ABC
from datetime import datetime, timedelta
from threading import Thread
from typing import Optional, Union, List, Any

import pytz as pytz

from devocollectorsdk.commons.collector_exceptions import SdkPullerAbstractError
from devocollectorsdk.commons.collector_utils import CollectorUtils
from devocollectorsdk.commons.constants import Constants
from devocollectorsdk.commons.non_active_reasons import NonActiveReasons
from devocollectorsdk.commons.obfuscation_utils import ObfuscationUtils
from devocollectorsdk.commons.object_statuses import ObjectStatuses
from devocollectorsdk.inputs.collector_puller_setup_abstract import CollectorPullerSetupAbstract
from devocollectorsdk.message.lookup_job_factory import LookupJobFactory, LookupJob
from devocollectorsdk.message.message import Message
# noinspection PyUnresolvedReferences
from agent.modules import *

from devocollectorsdk.persistence.persistence_service import PersistenceService
from devocollectorsdk.persistence.persistence_factory_manager import PersistenceFactoryManager, \
    create_persistence_address, create_deprecated_persistence_address
from devocollectorsdk.queues.collector_multiprocessing_queue import CollectorMultiprocessingQueue
from devocollectorsdk.ratelimiter.collector_rate_limiter_controller import CollectorRateLimiterController
from devocollectorsdk.ratelimiter.collector_rate_limiter_list import CollectorRateLimiterList

log = logging.getLogger(__name__)


class CollectorPullerAbstract(Thread, ABC):

    def __init__(self,
                 parent_thread,
                 production_mode: bool,
                 execute_only_setup_and_exit: bool,
                 definition_globals: dict,
                 input_id: str,
                 input_name: str,
                 input_config: dict,
                 input_definition: dict,
                 service_name: str,
                 service_type: str,
                 service_config: dict,
                 service_definition: dict,
                 module_class_name: str,
                 module_config: dict,
                 module_definition: dict,
                 persistence_factory_manager: PersistenceFactoryManager,
                 output_queue: CollectorMultiprocessingQueue,
                 lookup_queue: CollectorMultiprocessingQueue,
                 internal_queue: CollectorMultiprocessingQueue,
                 rate_limiters_from_service: CollectorRateLimiterList,
                 submodule_name: str = None,
                 submodule_config: Any = None) -> None:
        """

        :param parent_thread:
        :param production_mode:
        :param execute_only_setup_and_exit:
        :param definition_globals:
        :param input_id:
        :param input_name:
        :param input_config:
        :param input_definition:
        :param service_name:
        :param service_type:
        :param service_config:
        :param service_definition:
        :param module_class_name:
        :param module_config:
        :param module_definition:
        :param persistence_factory_manager:
        :param output_queue:
        :param lookup_queue:
        :param internal_queue:
        :param submodule_name:
        :param submodule_config:
        """

        self.__object_status = ObjectStatuses.INITIALIZING

        creation_timestamp_start = datetime.now()
        super().__init__()

        submodule_id = ""
        if submodule_name:
            submodule_id = f",{submodule_name}"
        self.name = \
            self.__class__.__name__ \
            + f'({input_name},{input_id},' \
              f'{service_name},{service_type}{submodule_id})'

        self.parent_thread = parent_thread

        self.production_mode: bool = production_mode
        self.execute_only_setup_and_exit: bool = execute_only_setup_and_exit
        self.definition_globals: dict = definition_globals
        self.input_id: str = input_id
        self.input_name: str = input_name
        self.input_config: dict = input_config
        self.input_definition: dict = input_definition

        self.service_name: str = service_name
        self.service_type: str = service_type
        self.service_config: dict = service_config
        self.service_definition: dict = service_definition

        self.module_name: str = module_class_name
        self.module_config: dict = module_config
        self.module_definition: dict = module_definition

        self.submodule_name: str = submodule_name
        self.submodule_config: Any = submodule_config

        self.output_queue: CollectorMultiprocessingQueue = output_queue
        self.lookup_queue: CollectorMultiprocessingQueue = lookup_queue
        self.internal_queue: CollectorMultiprocessingQueue = internal_queue

        # Persistence
        self.persistence_manager: PersistenceFactoryManager = persistence_factory_manager
        self.persistence_object: PersistenceService = self.__create_persistence_service(submodule_name)

        self.log_debug(f'{self.name} - Persistence instance: {self.persistence_object}')

        # Default values for variables
        self.self_monitoring_tag = f'{Constants.INTERNAL_MESSAGE_TAGGING_BASE}.{self.input_name}.{self.service_name}'
        self.retrieval_offset_in_seconds: float = 0
        self._pre_pull_executed = False
        self.pull_retries_max_in_iterations: int = -1
        self.pull_retries_initial_wait_time_in_sec: int = 5
        self.pull_retries_maximum_wait_time_in_sec: int = 1800
        self.pull_retries_creation_timeout_in_second: float = 60
        self.setup_creation_timeout_in_second: float = 60
        self.setup_should_exit: bool = False
        self.last_execution_timestamp = None
        self._first_waiting_message = True
        self.first_try_of_data_recovery = True
        self.collector_variables: dict = {}
        self.initialized_variables: bool = False
        self.no_wait_next_loop: bool = False
        self.autosetup_enabled: bool = False
        self.show_puller_loop_flag: bool = True

        # Variables related to run/pause/stop statuses
        self.__command_lock: threading.Lock = threading.Lock()

        self.__thread_wait_object: threading.Event = threading.Event()
        self.__non_active_reason: Optional[str] = None

        self.__stop_thread: bool = False
        self.__wait_object_for_stop_method: threading.Event = threading.Event()
        self.__thread_is_stopped: bool = False

        self.__pause_thread: bool = False
        self.__wait_object_for_pause_run: threading.Event = threading.Event()
        self.__wait_object_for_pause_method: threading.Event = threading.Event()
        self.__thread_is_paused: bool = False

        self.running_flag: bool = True

        self.use_time_slots_for_retrievals = False
        self.request_period_in_seconds: int = 300

        self.__rate_limiters: CollectorRateLimiterList = \
            CollectorRateLimiterList(rate_limiters_from_service.rate_limiters)

        self.__requests_limits = self.module_definition.get("requests_limits")
        if self.__requests_limits:
            self.__rate_limiters.add_rate_limiters_from_list(self.__requests_limits)

        self.obfuscation_data: Optional[list] = None
        self.__service_config_obfuscation_data: Optional[list] = None
        self.__module_definition_obfuscation_data: Optional[list] = None

        self.environment: Optional[str] = None

        # First load the global definitions that could be overwritten by other definition levels
        self.module_globals = input_definition.get("module_globals")
        if self.module_globals:

            # Setting a value for "use_time_slots_for_retrievals" function from global section
            if "use_time_slots_for_retrievals" in self.module_globals:
                self.use_time_slots_for_retrievals = self.module_globals["use_time_slots_for_retrievals"]

            # Setting a value for "request_period_in_seconds" function from global section
            request_period_in_seconds_from_globals: Union[int, float] = \
                self.module_globals.get("request_period_in_seconds")
            if request_period_in_seconds_from_globals is not None:
                if isinstance(request_period_in_seconds_from_globals, float):
                    request_period_in_seconds_from_globals = int(request_period_in_seconds_from_globals)
                if not isinstance(request_period_in_seconds_from_globals, int):
                    raise Exception(f'request_period_in_seconds must be an integer')
                if request_period_in_seconds_from_globals <= 0:
                    raise Exception(f'request_period_in_seconds must be greater than 0')
                self.request_period_in_seconds = request_period_in_seconds_from_globals

        if self.input_config:
            # Establish values from configuration file
            requests_per_second_from_config: int = self.input_config.get("requests_per_second")
            if requests_per_second_from_config is not None:
                if not isinstance(requests_per_second_from_config, int):
                    raise Exception(f'requests_per_second must be an integer')
                if requests_per_second_from_config <= 0:
                    raise Exception(f'requests_per_second must be greater than 0')
                self.collector_variables["requests_per_second"]: float = requests_per_second_from_config

            # Setting a value for "Use time slots for retrievals" function from input section
            if "use_time_slots_for_retrievals" in self.input_config:
                self.use_time_slots_for_retrievals = self.input_config["use_time_slots_for_retrievals"]

            autosetup_section = self.input_config.get("autoconfig")
            if autosetup_section:
                self.autosetup_enabled = autosetup_section.get("enabled", False)

            if 'environment' in self.input_config:
                self.environment = self.input_config['environment']

        if self.module_definition:

            # Setting a value for "request_period_in_seconds" function from module definition section
            request_period_in_seconds_from_module: Union[int, float] = \
                self.module_definition.get("request_period_in_seconds")
            if request_period_in_seconds_from_module is not None:
                if isinstance(request_period_in_seconds_from_module, float):
                    request_period_in_seconds_from_module = int(request_period_in_seconds_from_module)
                if not isinstance(request_period_in_seconds_from_module, int):
                    raise Exception(f'request_period_in_seconds must be an integer')
                if request_period_in_seconds_from_module <= 0:
                    raise Exception(f'request_period_in_seconds must be greater than 0')

                self.request_period_in_seconds = request_period_in_seconds_from_module

            if "setup_class" in self.module_definition and \
                    self.module_definition["setup_class"] is not None \
                    and len(self.module_definition["setup_class"]) > 0:
                self.setup_should_exit = True

            module_properties = self.module_definition.get('module_properties')
            if module_properties:
                self.show_puller_loop_flag = module_properties.get('show_puller_loop_flag')
                if self.show_puller_loop_flag is not False:
                    self.show_puller_loop_flag = True

                requests_per_second: float = module_properties.get("requests_per_second")
                if requests_per_second and requests_per_second > 0:
                    self.collector_variables["requests_per_second"]: float = requests_per_second

            if 'obfuscation_data' in self.module_definition:
                self.__module_definition_obfuscation_data = self.module_definition['obfuscation_data']

        if self.service_config:

            requests_per_second_from_config: int = self.service_config.get("requests_per_second")
            if requests_per_second_from_config is not None:
                if not isinstance(requests_per_second_from_config, int):
                    raise Exception(f'requests_per_second must be an integer')
                if requests_per_second_from_config <= 0:
                    raise Exception(f'requests_per_second must be greater than 0')
                self.collector_variables["requests_per_second"]: float = requests_per_second_from_config

            request_period_in_seconds_from_config: Union[int, float] = \
                self.service_config.get("request_period_in_seconds")
            if request_period_in_seconds_from_config is not None:
                if isinstance(request_period_in_seconds_from_config, float):
                    request_period_in_seconds_from_config = int(request_period_in_seconds_from_config)
                if not isinstance(request_period_in_seconds_from_config, int):
                    raise Exception(f'request_period_in_seconds must be an integer')
                if request_period_in_seconds_from_config <= 0:
                    raise Exception(f'request_period_in_seconds must be greater than 0')
                self.request_period_in_seconds: int = request_period_in_seconds_from_config

            if "retries" in self.service_config:
                self.log_warning(
                    '<retries> configuration has been found for <service config>, but it will be ignored '
                    'after IFC SDK 1.3.0 because functional requirements.'
                )

            service_requests_limits: list = self.service_config.get("requests_limits")
            if service_requests_limits is not None:
                self.__rate_limiters.add_rate_limiters_from_list(service_requests_limits)

            # Setting a value for "Use time slots for retrievals" function from service specific section
            use_time_slots_for_retrievals_from_config: bool = self.service_config.get("use_time_slots_for_retrievals")
            if use_time_slots_for_retrievals_from_config is not None:
                self.use_time_slots_for_retrievals = use_time_slots_for_retrievals_from_config

            if 'obfuscation_data' in self.service_config:
                self.__service_config_obfuscation_data = self.service_config['obfuscation_data']

        if self.module_config:
            requests_per_second_from_config: int = self.module_config.get("requests_per_second")
            if requests_per_second_from_config is not None:
                if not isinstance(requests_per_second_from_config, int):
                    raise Exception(f'requests_per_second must be an integer')
                if requests_per_second_from_config <= 0:
                    raise Exception(f'requests_per_second must be greater than 0')
                self.collector_variables["requests_per_second"]: int = requests_per_second_from_config

            # Setting a value for "request_period_in_seconds" function from module config section
            request_period_in_seconds_from_config: Union[int, float] = \
                self.module_config.get("request_period_in_seconds")
            if request_period_in_seconds_from_config is not None:
                if isinstance(request_period_in_seconds_from_config, float):
                    request_period_in_seconds_from_config = int(request_period_in_seconds_from_config)
                if not isinstance(request_period_in_seconds_from_config, int):
                    raise Exception(f'request_period_in_seconds must be an integer')
                if request_period_in_seconds_from_config <= 0:
                    raise Exception(f'request_period_in_seconds must be greater than 0')
                self.request_period_in_seconds: int = request_period_in_seconds_from_config

        self.rate_limiter = CollectorRateLimiterController(self.rate_limiters)

        if self.__module_definition_obfuscation_data:
            self.obfuscation_data = self.__module_definition_obfuscation_data

        if self.__service_config_obfuscation_data and self.obfuscation_data:
            for obfuscation_item in self.obfuscation_data[:]:
                for service_config_obfuscation_item in self.__service_config_obfuscation_data:
                    if obfuscation_item['name'] == service_config_obfuscation_item['name']:
                        if service_config_obfuscation_item.get('value'):
                            obfuscation_item['value'] = service_config_obfuscation_item['value']
                        elif not service_config_obfuscation_item.get('value') and obfuscation_item.get('value'):
                            obfuscation_item.pop('value')
                    elif service_config_obfuscation_item['name'] not in [
                        obf_item['name'] for obf_item in self.obfuscation_data
                    ]:
                        self.obfuscation_data.append(service_config_obfuscation_item)

        elif self.__service_config_obfuscation_data and not self.obfuscation_data:
            self.obfuscation_data = self.__service_config_obfuscation_data

        # This method will extract the values for required custom properties from configuration and also
        # from service definitions
        try:

            self.init_variables(
                self.input_config,
                self.input_definition,
                self.service_config,
                self.service_definition,
                self.module_config,
                self.module_definition,
                self.submodule_config
            )
            self.initialized_variables = True

            self.log_debug(f'{self.name} -> All variables have been initialized')

        except Exception as ex:

            self.log_error(
                f'{self.name} -> Error when initializing the variables, details: {ex} | {ex.__class__}'
            )

            self.running_flag = False

        self.setup_instance = self.__create_setup_instance(self.module_definition)
        if self.setup_should_exit and self.setup_instance is None:
            raise Exception("Setup instance should exist but it does not exist")
        # if (datetime.now() - creation_timestamp_start).total_seconds() > self.setup_creation_timeout_in_second:
        #     raise

        self.__object_status = ObjectStatuses.INITIALIZED

    @property
    def rate_limiters(self):
        return self.__rate_limiters.rate_limiters

    def __create_setup_instance(self, module_definition: dict) -> CollectorPullerSetupAbstract:
        """

        :param module_definition:
        :return:
        """

        setup_instance: Optional[CollectorPullerSetupAbstract] = None
        if "setup_class" in module_definition and module_definition["setup_class"]:
            setup_class_name = module_definition.get("setup_class")
            if setup_class_name:
                if self.initialized_variables:
                    try:
                        setup_instance = \
                            self.__instantiate_setup_class(
                                setup_class_name,
                                self.autosetup_enabled,
                                self.collector_variables
                            )

                        self.log_debug(
                            f'{self.name} -> {setup_instance.name} - Instance created'
                        )

                    except Exception as ex:

                        self.log_error(
                            f'{self.name} - Error when creating class, '
                            f'module_name: {self.module_name}, '
                            f'module_definition: {module_definition}, '
                            f'details: {ex}'
                        )

                else:

                    log_message = \
                        f"[SETUP] - Setup instance will not be created due there exists " \
                        f"some errors when initializing main variables"
                    self.log_error(log_message)

        return setup_instance

    def __instantiate_setup_class(
            self,
            setup_class_name: str,
            autosetup_enabled: bool,
            collector_variables: dict) -> CollectorPullerSetupAbstract:
        """

        :param setup_class_name:
        :param autosetup_enabled:
        :param collector_variables:
        :return:
        """

        agent_modules = sys.modules['agent.modules']
        setup_class = getattr(agent_modules, setup_class_name)

        return setup_class(
            self,
            collector_variables,
            autosetup_enabled,
            self.input_id,
            self.input_name,
            self.input_config,
            self.input_definition,
            self.service_name,
            self.service_type,
            self.service_config,
            self.service_definition,
            self.module_name,
            self.module_config,
            self.module_definition,
            self.persistence_object,
            self.output_queue,
            self.submodule_name,
            self.submodule_config
        )

    def __create_persistence_service(self, submodule_name):
        """

        :param submodule_name:
        :return:
        """

        persistence_address: str = create_deprecated_persistence_address(
            self.input_name,
            self.input_id,
            self.service_name,
            submodule_name
        )
        persistence_service = self.persistence_manager.get_instance_for_unique_id(persistence_address)
        return persistence_service

    # Debugging timing request
    def _limited(self, until):
        """

        :param until:
        :return:
        """

        duration = until - time.time()
        threading.current_thread().name = f"{self.getName()} -> Ratelimiter"

        log_message = F"Sleeping for {duration:.5f} seconds"
        self.log_debug(log_message)

    def run(self) -> None:
        """Execute the run method

        :return:
        :raises: SdkPullerAbstractError (50-99)
        """

        self.__object_status = ObjectStatuses.RUNNING

        retry_counter: int = 0
        retrieving_timestamp_slot = None

        while self.running_flag:

            if self.__pause_thread is False \
                    and self.__stop_thread is False:

                has_waited_for_configurator_to_be_ready = self.__wait_to_setup_instance_to_be_ready()

                if self.setup_should_exit \
                        and (self.setup_instance is None or self.setup_instance.running_flag is False):
                    self.running_flag = False
                    break

                if self.setup_instance is None or self.setup_instance.is_paused() is False:

                    retrieving_timestamp: datetime = datetime.utcnow().replace(tzinfo=pytz.utc)
                    if self._pre_pull_executed is False:
                        try:
                            self.pre_pull(retrieving_timestamp)
                            self._pre_pull_executed = True
                        except Exception as e:
                            exception = CollectorUtils.create_exception_msg_for_exception(e)
                            self.log_error(json.dumps(exception))

                            self.log_warning('Sleeping 60 sec before retry pre-pull')

                            time.sleep(60)
                            continue

                    # Calculate if the pull requires time slots and wait if required
                    if self.use_time_slots_for_retrievals is True:
                        retrieving_timestamp = self.__calculate_time_slot_for_retrievals(retrieving_timestamp_slot)

                    if has_waited_for_configurator_to_be_ready is True or \
                            self.first_try_of_data_recovery is True:

                        self.log_info(f'Starting data collection every {self.request_period_in_seconds} seconds')

                        self.first_try_of_data_recovery = False

                    try:

                        self.log_debug(
                            f'Messages in queues (standard/lookup): '
                            f'{self.output_queue.qsize()}/{self.lookup_queue.qsize()}'
                        )

                        self.pull(retrieving_timestamp)

                        # Restart the retries counter after one successfully setup
                        retry_counter: int = 0
                        self._loop_wait(retrieving_timestamp)

                        self.log_debug(f'Waking up from wait status')

                    except Exception as e:
                        exception = CollectorUtils.create_exception_msg_for_exception(e)
                        self.log_error(json.dumps(exception))

                        if self.setup_instance:
                            # Trigger setup instance and retry
                            self.setup_instance.ready_to_collect = False

                            self.log_warning(f'Waiting until setup thread will execute again')

                            self.setup_instance.wake_up()
                        else:
                            # When not setup is defined retry the puller
                            # Retry only when we have credit, or we have infinite iterations allowed
                            if retry_counter != self.pull_retries_max_in_iterations:
                                retry_counter += 1

                                max_retries_allowed: [int, str] = \
                                    "∞" if self.pull_retries_max_in_iterations == -1 else retry_counter

                                self.log_warning(
                                    f'Retrying collector puller: {retry_counter}/{max_retries_allowed}'
                                )

                                self._sleep_before_retry(retry_counter)

                            else:

                                self.log_error(
                                    f'Max number retries allowed hit: '
                                    f'{retry_counter}/{retry_counter}. '
                                    f'Aborting execution.'
                                )

                                self.running_flag: bool = False

            self.__check_if_pause()

            self.__check_if_stop()

        self.log_debug("Finalizing thread")

        self.__thread_is_stopped = True
        if self.__wait_object_for_stop_method.is_set() is False:
            self.__wait_object_for_stop_method.set()

    def __calculate_time_slot_for_retrievals(self, retrieving_timestamp_slot) -> datetime:
        """Calculate the next retrieving_timestamp when retrieving_timestamp_slot property is True

        :param retrieving_timestamp_slot:
        :return: Timestamp of the next time slot.
        """
        if retrieving_timestamp_slot is None:
            now_raw: datetime = datetime.utcnow().replace(tzinfo=pytz.utc)
            next_retrieval: datetime = \
                now_raw.replace(microsecond=0) + timedelta(seconds=self.request_period_in_seconds)
            next_retrieval_epoch: int = int(next_retrieval.timestamp())
            next_retrieval_epoch = \
                int(next_retrieval_epoch - (next_retrieval_epoch % self.request_period_in_seconds))
            wait = next_retrieval_epoch - now_raw.timestamp()

            self.log_info(f'Waiting {wait:0.3f} seconds before start pulling')

            time.sleep(wait)
            retrieving_timestamp_slot = datetime.utcfromtimestamp(next_retrieval_epoch).replace(tzinfo=pytz.utc)
        else:
            retrieving_timestamp_slot = retrieving_timestamp_slot + timedelta(seconds=self.request_period_in_seconds)
        retrieving_timestamp = retrieving_timestamp_slot
        return retrieving_timestamp

    def __wait_to_setup_instance_to_be_ready(self) -> bool:
        """

        :return:
        """

        # Wait to the setup instance to be ready (if needed)
        has_waited_for_configurator_to_be_ready = False
        setup_wait_loop_counter = 0
        while self.setup_instance \
                and self.setup_instance.ready_to_collect is False:

            if self.setup_instance.is_paused() is True:
                self.log_info(f'The setup instance has been put on pause status')
                break

            setup_wait_loop_counter += 1
            if self.setup_instance.running_flag is True:
                if self._first_waiting_message is True:

                    self.log_warning("Waiting until setup will be executed")

                    self._first_waiting_message = False

                has_waited_for_configurator_to_be_ready = True

                if setup_wait_loop_counter % 15 == 0:

                    self.log_warning("Waiting until setup will be executed")

                time.sleep(1)
            else:
                break

        return has_waited_for_configurator_to_be_ready

    def _loop_wait(self, retrieving_timestamp: datetime) -> None:
        """

        :param retrieving_timestamp:
        :return:
        """

        elapsed_time = (datetime.utcnow().replace(tzinfo=pytz.utc) - retrieving_timestamp).total_seconds()

        # Request frequency
        wait_in_seconds = self.request_period_in_seconds

        if retrieving_timestamp:
            wait_in_seconds -= (datetime.utcnow().replace(tzinfo=pytz.utc) - retrieving_timestamp).total_seconds()

        if self.retrieval_offset_in_seconds != 0:
            wait_in_seconds += self.retrieval_offset_in_seconds

            self.log_info(
                f'Applied an offset to wait, retrieval_offset: {self.retrieval_offset_in_seconds} seconds'
            )

            self.retrieval_offset_in_seconds = 0

        if self.no_wait_next_loop is True:

            log_message = \
                f"Elapsed time: {elapsed_time:0.3f} seconds. " \
                f"It has been activated the flag for no waiting until the next loop"
            self.log_info(log_message)

            self.no_wait_next_loop = False
        else:
            if wait_in_seconds > 0:
                # Show show_puller_loop_flag
                if self.show_puller_loop_flag:

                    self.log_info(
                        f'Data collection completed. Elapsed time: {elapsed_time:0.3f} seconds. '
                        f'Waiting for {wait_in_seconds:0.3f} second(s) until the next one'
                    )

                called: bool = self.__thread_wait_object.wait(timeout=wait_in_seconds)
                if called is True:
                    self.__thread_wait_object.clear()
            else:
                # Show show_puller_loop_flag
                if self.show_puller_loop_flag:

                    log_message = \
                        f"Elapsed time: {elapsed_time:0.3f} seconds. " \
                        f"Last retrieval took too much time, no wait will be applied in this loop"
                    self.log_info(log_message)

    def __check_if_pause(self) -> None:
        """

        :return:
        """

        if self.__pause_thread is True:

            self.log_warning(f'Thread has been put in pause status, reason: "{self.__non_active_reason}')

            self.__thread_is_paused = True
            self.__pause_thread = False

            self.__object_status = ObjectStatuses.PAUSED

            if self.__wait_object_for_pause_method.is_set() is False:
                self.__wait_object_for_pause_method.set()

            called: bool = self.__wait_object_for_pause_run.wait()
            if called is True:
                self.__wait_object_for_pause_run.clear()

            self.__thread_is_paused = False

            self.log_info(f'Thread has exited from pause status')

    def __check_if_stop(self) -> None:
        """

        :return:
        """

        if self.__stop_thread is True:
            self.running_flag = False

    def wake_up(self) -> None:
        """Force to the wait object to exit from waiting status

        :return:
        """

        if self.__thread_wait_object.is_set() is False:
            self.__thread_wait_object.set()

    def start(self) -> None:
        """

        :return:
        """

        if self.setup_instance:
            self.setup_instance.start()

        self.log_info(
            f'{self.name} - Starting thread'
        )

        super().start()

    def is_pausing(self) -> bool:
        return self.__pause_thread

    def pause(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        with self.__command_lock:

            if self.__object_status == ObjectStatuses.PAUSED:
                self.log_info(f'{self.name} -> Current thread was already in pause status')
                return

            self.log_info(f'{self.name} -> Pausing current thread (wait={wait})')

            self.__pause_dependencies(wait=wait)

            self.pull_pause(wait=wait)

            self.__non_active_reason = NonActiveReasons.PAUSE_COMMAND_RECEIVED
            self.__pause_thread = True

            if self.__thread_wait_object.is_set() is False:
                self.__thread_wait_object.set()

            # Preparing the waiting object for the waiting loop
            if self.__wait_object_for_pause_method.is_set() is True:
                self.__wait_object_for_pause_method.clear()

            if wait is True:

                while self.__thread_is_paused is False:

                    self.log_debug(f'{self.name} -> Waiting to be paused')

                    called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                    if called is True:
                        self.__wait_object_for_pause_method.clear()

                self.log_info(f'{self.name} -> Thread has been paused after waiting (sync)')

            else:

                self.log_info(f'{self.name} -> Thread has been paused without waiting phase (async)')

    def __pause_dependencies(self, wait: bool = None) -> None:
        """

        :return:
        """

        if wait is None:
            raise Exception('The parameter "wait" is mandatory')

        self.log_info(f'{self.name} -> Pausing all dependent threads')

        if self.setup_instance and self.setup_instance.is_running():
            self.setup_instance.pause(wait=True)

        self.log_info(f'{self.name} -> All dependent threads have been paused')

    def unpause(self) -> None:
        """

        :return:
        """
        self.__pause_thread = False

    def stop(self) -> None:
        """

        :return:
        """

        if self.__thread_is_paused is False:

            self.log_warning(f"{self.name} -> Is not in pause status, waiting first to be paused")

            while self.__thread_is_paused is False:

                self.log_debug(f'{self.name} -> Waiting to be paused')

                called: bool = self.__wait_object_for_pause_method.wait(timeout=10)
                if called is True:
                    self.__wait_object_for_pause_method.clear()

        self.log_info(f'{self.name} -> Stopping thread')

        self.__non_active_reason = NonActiveReasons.STOP_COMMAND_RECEIVED
        self.__stop_thread = True

        self.__stop_dependencies()

        self.pull_stop()

        if self.__thread_wait_object.is_set() is False:
            self.__thread_wait_object.set()

        if self.__wait_object_for_pause_run.is_set() is False:
            self.__wait_object_for_pause_run.set()

        if self.__wait_object_for_stop_method.is_set() is True:
            self.__wait_object_for_stop_method.clear()

        while self.__thread_is_stopped is False:

            log.debug(f'{self.name} -> Waiting to be stopped')

            called: bool = self.__wait_object_for_stop_method.wait(timeout=10)
            if called is True:
                self.__wait_object_for_stop_method.clear()

        self.log_info(f'{self.name} -> Thread has been stopped')

    def __stop_dependencies(self) -> None:
        """

        :return:
        """

        self.log_info(f'{self.name} -> Stopping all dependent threads')

        if self.setup_instance and self.setup_instance.is_running():
            self.setup_instance.stop()

        self.log_info(f'{self.name} -> All dependent threads have been stopped')

    def __send_standard_message(self, message: Union[Message, List[Message]]) -> None:
        """

        :param message:
        :return:
        """

        self.output_queue.put(message)

    def send_standard_message(self,
                              msg_date: Union[datetime, str, int, float],
                              msg_tag: str,
                              msg_content: Union[dict, str]):
        """
        Method that send an unique message to be consumed by the collector. Only str and dict formats
        are accepted as message payload.
        :param msg_content: an instance of dict or str with the message content
        :param msg_tag: an instance of str with the final devo tag
        :param msg_date: an instance of datetime in UTC
        """

        if isinstance(msg_content, dict):

            if self.obfuscation_data:
                msg_content = ObfuscationUtils.process_json(
                    msg_content,
                    self.obfuscation_data
                )

            if self.environment:
                msg_content['@devo_environment'] = self.environment

            msg_content_str = json.dumps(msg_content)
        elif isinstance(msg_content, str):
            msg_content_str = msg_content
        else:
            raise SdkPullerAbstractError(
                sub_code=200,
                cause=f'The message content should be an instance of <dict> or <str> types not <{type(msg_content)}>'
            )

        self.__send_standard_message(Message(msg_date, msg_tag, msg_content_str, is_internal=False))

    def send_standard_messages(self,
                               msg_date: Union[datetime, str, int, float],
                               msg_tag: str,
                               list_of_messages: Union[List[str], List[dict]]) -> None:
        """
        Method that send several messages to be consumed by the collector. Only str and dict formats
        are accepted as message payload.

        :param list_of_messages: a list instance of str and dict instances
        :param msg_tag: an instance of str with the final devo tag
        :param msg_date: an instance of datetime in UTC
        """

        messages_ready_to_send: List[Optional[Message]] = [None] * len(list_of_messages)

        for index, msg in enumerate(list_of_messages):
            if isinstance(msg, dict):

                if self.obfuscation_data:
                    msg = ObfuscationUtils.process_json(msg, self.obfuscation_data)

                if self.environment:
                    msg['@devo_environment'] = self.environment

                msg_content = json.dumps(msg)
            elif isinstance(msg, str):
                msg_content = msg
            else:
                raise SdkPullerAbstractError(
                    sub_code=250,
                    cause=f'The message content should be an instance of <dict> or <str> types not <{type(msg)}>'
                )

            messages_ready_to_send[index] = Message(msg_date, msg_tag, msg_content, is_internal=False)

        self.__send_standard_message(messages_ready_to_send)

    def send_lookup_messages(self, lookup_job_factory: LookupJobFactory, start: bool, end: bool, buffer: str) -> None:
        """
        Method that creates a lookup_job and sends it to the lookup_queue

        :param lookup_job_factory: A populated lookup_job_factory object.
        :param start: True if the start control should be sent. False if not.
        :param end: True if the start control should be sent. False if not.
        :param buffer: String with the name of the buffer that should be sent to Devo.
            One of these 'Create', 'Modify', 'Remove'.
        """

        buffers = ['Create', 'Modify', 'Remove']

        # Validations
        if not isinstance(lookup_job_factory, LookupJobFactory):
            raise SdkPullerAbstractError(
                sub_code=300,
                cause=f'<lookup_job_factory> should be a <LookupJobFactory> instance not <{type(lookup_job_factory)}>'
            )
        if not isinstance(start, bool):
            raise SdkPullerAbstractError(
                sub_code=301,
                cause=f'<start> param should be a <bool> instance not <{type(start)}>'
            )
        if not isinstance(end, bool):
            raise SdkPullerAbstractError(
                sub_code=302,
                cause=f'<end> param should be a <bool> instance not <{type(end)}>'
            )
        if buffer not in buffers:
            raise SdkPullerAbstractError(
                sub_code=303,
                cause=f'<buffer> param should be one of these <{buffers}> not <{buffer}>'
            )

        # LookupJob creation
        if buffer == 'Create':
            lookup_job: LookupJob = lookup_job_factory.create_job_to_initialize_items(send_start=start, send_end=end)
        elif buffer == 'Modify':
            lookup_job: LookupJob = lookup_job_factory.create_job_to_modify_items(send_start=start, send_end=end)
        else:
            lookup_job: LookupJob = lookup_job_factory.create_job_to_remove_items(send_start=start, send_end=end)

        # Send lookup job
        self.__send_lookup_job(lookup_job)

    def __send_lookup_job(self, lookup_job: LookupJob) -> None:
        """
        Method that puts a lookup_job into lookup_queue.
        :param lookup_job: a LookupJob instance.
        """

        self.lookup_queue.put(lookup_job)

    def send_internal_collector_message(self,
                                        message_content: Union[str, dict],
                                        level: str = None,
                                        shared_domain: bool = False):
        """

        :param message_content:
        :param level:
        :param shared_domain:
        :return:
        """

        CollectorUtils.send_internal_collector_message(
            self.internal_queue,
            message_content,
            input_name=self.input_name,
            service_name=self.service_name,
            module_name=self.module_name,
            level=level,
            shared_domain=shared_domain
        )

    def log_error(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.ERROR):
            log.error(message)
            self.send_internal_collector_message(message, level="error")

    def log_warning(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.WARNING):
            log.warning(message)
            self.send_internal_collector_message(message, level="warning")

    def log_info(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.INFO):
            log.info(message)
            self.send_internal_collector_message(message, level="info")

    def log_debug(self, message: str) -> None:
        """

        :param message:
        :return:
        """

        if log.isEnabledFor(logging.DEBUG):
            log.debug(message)
            self.send_internal_collector_message(message, level="debug")

    def _sleep_before_retry(self, retries: int):
        """Sleep based on the current failed retries number

        :param retries: Number of current retries
        """

        # Calculate the number of seconds to sleep
        seconds_base: int = self.pull_retries_initial_wait_time_in_sec
        time_to_sleep: int = seconds_base ** retries

        # Never sleep more than the given limit
        if time_to_sleep > self.pull_retries_maximum_wait_time_in_sec:
            time_to_sleep: int = self.pull_retries_maximum_wait_time_in_sec

        # Report and sleep!
        self.log_info(f'Sleeping <{time_to_sleep}> seconds before next retry')
        time.sleep(time_to_sleep)

    def is_command_in_progress(self) -> bool:
        """

        :return:
        """

        return self.__pause_thread is True \
            or self.__thread_is_paused is True \
            or self.__stop_thread is True \
            or self.__thread_is_stopped is True

    @abstractmethod
    def init_variables(
            self,
            input_config: dict,
            input_definition: dict,
            service_config: dict,
            service_definition: dict,
            module_config: dict,
            module_definition: dict,
            submodule_config: Any) -> None:
        """

        :param input_config:
        :param input_definition:
        :param service_config:
        :param service_definition:
        :param module_config:
        :param module_definition:
        :param submodule_config:
        :return:
        """

        pass

    @abstractmethod
    def pre_pull(self, retrieving_timestamp: datetime) -> None:
        """

        :param retrieving_timestamp:
        :return:
        """

        pass

    @abstractmethod
    def pull(self, retrieving_timestamp: datetime) -> None:
        """

        :param retrieving_timestamp:
        :return:
        """

        pass

    @abstractmethod
    def pull_pause(self, wait: bool = None) -> None:
        """

        :return:
        """

        pass

    @abstractmethod
    def pull_stop(self) -> None:
        """

        :return:
        """

        pass
