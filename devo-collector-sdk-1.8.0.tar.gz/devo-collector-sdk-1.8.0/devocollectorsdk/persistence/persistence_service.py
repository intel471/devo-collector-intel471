import json
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from devocollectorsdk.commons.collector_exceptions import SdkPersistenceServiceError


class PersistenceService(ABC):

    def __init__(self, collector_id: str, unique_identifier: str):
        self.__collector_id: str = collector_id
        self.__unique_identifier: str = unique_identifier
        self._last_persisted_timestamp: Optional[datetime] = None
        self._emergency_system_save_timestamp: Optional[datetime] = None
        self._emergency_system_load_timestamp: Optional[datetime] = None
        self._emergency_system_clean_timestamp: Optional[datetime] = None
        self.use_old_format = True

    @property
    def collector_id(self) -> str:
        return self.__collector_id

    @property
    def unique_identifier(self) -> str:
        return self.__unique_identifier

    def save_state(self, object_to_save: dict, no_log_traces: bool = False, emergency_system_used: bool = False):
        try:
            json.dumps(object_to_save)
        except TypeError as type_error:
            raise SdkPersistenceServiceError(
                sub_code=1300,
                cause=str(type_error)
            )
        except Exception as ex:
            raise SdkPersistenceServiceError(
                sub_code=1301,
                cause=f'Unexpected error: {str(ex)}'
            )
        self._save_state(object_to_save, no_log_traces, emergency_system_used)

    def load_state(self, no_log_traces: bool = False, emergency_system_used: bool = False) -> dict:
        return self._load_state(no_log_traces, emergency_system_used)

    def load_state_old_format(
            self, no_log_traces: bool = False, unique_identifier: str = None, emergency_system_used: bool = False
    ) -> dict:
        return self._load_state_old_format(no_log_traces, unique_identifier, emergency_system_used)

    def clean_state(self, no_log_traces: bool = False, emergency_system_used: bool = False):
        return self._clean_state(no_log_traces, emergency_system_used)

    def is_ok(self) -> bool:
        return self._is_ok()

    @abstractmethod
    def _save_state(self, object_to_save: dict, no_log_traces: bool,  emergency_system_used: bool):
        pass

    @abstractmethod
    def _load_state(self, no_log_traces: bool,  emergency_system_used: bool) -> dict:
        pass

    @abstractmethod
    def _load_state_old_format(self, no_log_traces: bool, unique_identifier: str,  emergency_system_used: bool) -> dict:
        pass

    @abstractmethod
    def _is_ok(self) -> bool:
        pass

    @abstractmethod
    def _clean_state(self, no_log_traces: bool,  emergency_system_used: bool):
        pass
